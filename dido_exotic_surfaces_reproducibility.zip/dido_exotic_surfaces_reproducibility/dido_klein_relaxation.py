"""Area-constrained relaxation on a symmetric rectangular flat Klein bottle.

The orientation cover is the flat torus R2/(4 Z x 6 Z), quotiented by

    tau(x,y) = (x+2, 6-y).

For a selected base area A, put m=min(A,12-A).  Two topology-preserving
branches are relaxed independently:

* a contractible disk (or its complement), represented by a star-shaped lift;
* a two-sided separator, represented by a graph and its deck transform, whose
  complementary regions are Moebius bands.

The experiment minimizes boundary length at fixed area and records the Dido
diagnostic J=int (d kappa_g/ds)^2 ds.  It is a numerical comparison within
these two candidate classes, not a proof of the full isoperimetric profile.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.optimize import minimize

from dido_klein_bottle import FlatKleinBottle


TAU = 2.0 * math.pi


def stable_rng(seed: int, *tags: object) -> np.random.Generator:
    payload = json.dumps([seed, *tags], separators=(",", ":"),
                         sort_keys=True).encode("utf-8")
    value = int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")
    return np.random.default_rng(value)


class FourierBasis:
    def __init__(self, modes: int, points: int, period: float):
        if modes < 1 or points < 64 or points % 2:
            raise ValueError("modes >= 1 and an even points >= 64 are required")
        self.modes = modes
        self.points = points
        self.period = float(period)
        self.t = np.linspace(0.0, self.period, points, endpoint=False)
        n = np.arange(1, modes + 1, dtype=float)
        omega = TAU * n / self.period
        phase = np.outer(self.t, omega)
        weights = 1.0 / n**2
        self.B = np.concatenate((np.cos(phase) * weights,
                                 np.sin(phase) * weights), axis=1)
        self.Bp = np.concatenate((-np.sin(phase) * omega * weights,
                                  np.cos(phase) * omega * weights), axis=1)
        self.Bpp = np.concatenate((-np.cos(phase) * omega**2 * weights,
                                   -np.sin(phase) * omega**2 * weights), axis=1)

    def evaluate(self, coefficients: np.ndarray) -> tuple[np.ndarray, ...]:
        return (self.B @ coefficients, self.Bp @ coefficients,
                self.Bpp @ coefficients)


def periodic_derivative(values: np.ndarray, period: float) -> np.ndarray:
    frequencies = np.fft.fftfreq(len(values), d=period / len(values))
    return np.fft.ifft(2j * math.pi * frequencies
                       * np.fft.fft(values)).real


def integrate(values: np.ndarray, period: float) -> float:
    return period * float(np.mean(values))


def disk_metrics(coefficients: np.ndarray, area: float,
                 basis: FourierBasis) -> dict[str, float]:
    perturbation, perturbation_t, perturbation_tt = basis.evaluate(coefficients)
    q = 1.0 + perturbation
    if float(np.min(q)) <= 0.05:
        return {"length": 1.0e6, "area": area, "J": 1.0e12,
                "minimum_radius": -1.0}
    mean_q2 = float(np.mean(q * q))
    scale = math.sqrt(area / (math.pi * mean_q2))
    r = scale * q
    rt = scale * perturbation_t
    rtt = scale * perturbation_tt
    speed = np.sqrt(r * r + rt * rt)
    curvature = (r * r + 2.0 * rt * rt - r * rtt) / speed**3
    curvature_t = periodic_derivative(curvature, TAU)
    return {
        "length": integrate(speed, TAU),
        "area": 0.5 * integrate(r * r, TAU),
        "J": integrate(curvature_t * curvature_t / speed, TAU),
        "minimum_radius": float(np.min(r)),
    }


def separator_metrics(coefficients: np.ndarray, minority_area: float,
                      surface: FlatKleinBottle,
                      basis: FourierBasis) -> dict[str, float]:
    perturbation, fp, fpp = basis.evaluate(coefficients)
    center = minority_area / surface.cover_width
    f = center + perturbation
    if float(np.min(f)) <= 0.0 or float(np.max(f)) >= 0.5 * surface.cover_height:
        return {"length": 1.0e6, "area": minority_area, "J": 1.0e12,
                "minimum_height": float(np.min(f)),
                "maximum_height": float(np.max(f))}
    speed = np.sqrt(1.0 + fp * fp)
    curvature = fpp / speed**3
    curvature_x = periodic_derivative(curvature, surface.cover_width)
    return {
        "length": integrate(speed, surface.cover_width),
        "area": surface.cover_width * float(np.mean(f)),
        "J": integrate(curvature_x * curvature_x / speed,
                       surface.cover_width),
        "minimum_height": float(np.min(f)),
        "maximum_height": float(np.max(f)),
    }


def relax_branch(metric_function, basis: FourierBasis, rng: np.random.Generator,
                 starts: int, initial_scale: float,
                 coefficient_bound: float) -> dict[str, object]:
    best: dict[str, object] | None = None
    records: list[dict[str, object]] = []
    bounds = [(-coefficient_bound, coefficient_bound)] * (2 * basis.modes)
    for start in range(starts):
        initial = rng.normal(0.0, initial_scale, 2 * basis.modes)
        initial = np.clip(initial, -0.8 * coefficient_bound,
                          0.8 * coefficient_bound)
        before = metric_function(initial)
        result = minimize(lambda c: metric_function(c)["length"], initial,
                          method="L-BFGS-B", bounds=bounds,
                          options={"ftol": 1.0e-14, "gtol": 1.0e-10,
                                   "maxiter": 1200, "maxls": 40})
        after = metric_function(result.x)
        record = {
            "start": start,
            "optimizer_success": bool(result.success),
            "optimizer_status": int(result.status),
            "iterations": int(result.nit),
            "initial_length": float(before["length"]),
            "initial_J": float(before["J"]),
            "final_length": float(after["length"]),
            "final_area": float(after["area"]),
            "final_J": float(after["J"]),
            "coefficient_norm": float(np.linalg.norm(result.x)),
        }
        records.append(record)
        if best is None or record["final_length"] < best["final_length"]:
            best = record
    assert best is not None
    return {"best": best, "starts": records}


def run_experiment(
    areas: tuple[float, ...] = (0.5, 4.0 / math.pi, 2.0, 6.0,
                                10.0, 12.0 - 4.0 / math.pi, 11.5),
    surface: FlatKleinBottle = FlatKleinBottle(4.0, 6.0),
    modes: int = 6,
    points: int = 2048,
    starts: int = 4,
    seed: int = 20260909,
) -> dict[str, object]:
    total_area = surface.area
    if any(not 0.0 < area < total_area for area in areas):
        raise ValueError("each selected area must lie strictly inside (0,total area)")

    disk_basis = FourierBasis(modes, points, TAU)
    separator_basis = FourierBasis(modes, points, surface.cover_width)
    crossover = surface.cover_width**2 / (4.0 * math.pi)
    rows: list[dict[str, object]] = []

    for area in areas:
        minority = min(area, total_area - area)
        radius = math.sqrt(minority / math.pi)
        disk_admissible = radius < surface.injectivity_radius
        disk = None
        if disk_admissible:
            disk = relax_branch(
                lambda c, a=minority: disk_metrics(c, a, disk_basis),
                disk_basis, stable_rng(seed, "disk", area), starts,
                initial_scale=0.08, coefficient_bound=0.22,
            )

        center = minority / surface.cover_width
        separator = relax_branch(
            lambda c, a=minority: separator_metrics(
                c, a, surface, separator_basis),
            separator_basis, stable_rng(seed, "separator", area), starts,
            initial_scale=max(0.005, 0.06 * center),
            coefficient_bound=max(0.01, 0.18 * center),
        )

        disk_length = (float(disk["best"]["final_length"])
                       if disk is not None else math.inf)
        separator_length = float(separator["best"]["final_length"])
        tolerance = 2.0e-7
        if abs(disk_length - separator_length) <= tolerance:
            winner = "tie"
        elif disk_length < separator_length:
            winner = "disk" if area <= total_area / 2.0 else "disk_complement"
        else:
            winner = ("moebius_band" if area <= total_area / 2.0
                      else "moebius_band_complement")

        rows.append({
            "selected_area": area,
            "minority_area": minority,
            "disk_radius": radius,
            "disk_quotient_admissible": disk_admissible,
            "disk": disk,
            "separator": separator,
            "winner": winner,
            "predicted_winner": (
                "tie" if abs(minority - crossover) < 1.0e-12
                else ("disk" if minority < crossover else "separator")
            ),
            "analytic_disk_length": 2.0 * math.sqrt(math.pi * minority),
            "analytic_separator_length": surface.cover_width,
        })

    def branch_ok(branch: dict[str, object] | None, area: float,
                  expected_length: float) -> bool:
        if branch is None:
            return True
        best = branch["best"]
        return (abs(float(best["final_area"]) - area) < 2.0e-12
                and abs(float(best["final_length"]) - expected_length) < 2.0e-7
                and float(best["final_J"]) < 2.0e-7)

    gates = {
        "R0_AREA_EXACT": all(
            branch_ok(row["disk"], float(row["minority_area"]),
                      float(row["analytic_disk_length"]))
            and branch_ok(row["separator"], float(row["minority_area"]),
                          float(row["analytic_separator_length"]))
            for row in rows
        ),
        "R1_TOPOLOGY_GUARD": all(
            bool(row["disk_quotient_admissible"])
            == (float(row["disk_radius"]) < surface.injectivity_radius)
            for row in rows
        ),
        "R2_BRANCH_SELECTION": all(
            (row["winner"] == row["predicted_winner"])
            or (row["predicted_winner"] == "disk"
                and row["winner"] == "disk_complement")
            or (row["predicted_winner"] == "separator"
                and row["winner"] in {"moebius_band", "moebius_band_complement"})
            for row in rows
        ),
        "R3_COMPLEMENT_SYMMETRY": all(
            abs(next(float(other["minority_area"]) for other in rows
                     if abs(float(other["selected_area"])
                            - (total_area - float(row["selected_area"]))) < 1.0e-12)
                - float(row["minority_area"])) < 1.0e-12
            for row in rows
        ),
        "R4_RELAXATION_DECREASES": all(
            all(float(start["final_length"]) <= float(start["initial_length"])
                + 1.0e-10 for start in row["separator"]["starts"])
            and (row["disk"] is None or all(
                float(start["final_length"]) <= float(start["initial_length"])
                + 1.0e-10 for start in row["disk"]["starts"]))
            for row in rows
        ),
    }

    return {
        "program": "dido_klein_relaxation.py",
        "surface": "symmetric rectangular flat Klein bottle",
        "orientation_cover": {
            "width": surface.cover_width,
            "height": surface.cover_height,
            "area": surface.cover_area,
        },
        "base_area": total_area,
        "injectivity_radius": surface.injectivity_radius,
        "selected_areas": list(areas),
        "minority_area_crossover": crossover,
        "candidate_envelope": "min(2*sqrt(pi*m), 4), m=min(A,12-A)",
        "scope": "numerical relaxation within disk/complement and symmetric separator classes",
        "rows": rows,
        "gates": gates,
        "all_gates_pass": all(gates.values()),
    }


def print_report(report: dict[str, object]) -> None:
    print("=" * 118)
    print("SYMMETRIC FLAT KLEIN BOTTLE: AREA-CONSTRAINED RELAXATION")
    print("=" * 118)
    print(f"{'A':>10} {'m':>10} {'disk L':>12} {'sep L':>12} "
          f"{'winner':>27} {'best J':>13}")
    for row in report["rows"]:
        disk = row["disk"]
        disk_length = (float(disk["best"]["final_length"])
                       if disk is not None else float("nan"))
        separator_length = float(row["separator"]["best"]["final_length"])
        if row["winner"] in {"disk", "disk_complement", "tie"} and disk is not None:
            best_j = float(disk["best"]["final_J"])
        else:
            best_j = float(row["separator"]["best"]["final_J"])
        print(f"{row['selected_area']:10.6f} {row['minority_area']:10.6f} "
              f"{disk_length:12.8f} {separator_length:12.8f} "
              f"{row['winner']:>27} {best_j:13.4e}")
    print(f"crossover minority area = {report['minority_area_crossover']:.12f}")
    for name, passed in report["gates"].items():
        print(f"[{'PASS' if passed else 'FAIL'}] {name}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--areas", type=float, nargs="+",
                        default=[0.5, 4.0 / math.pi, 2.0, 6.0,
                                 10.0, 12.0 - 4.0 / math.pi, 11.5])
    parser.add_argument("--modes", type=int, default=6)
    parser.add_argument("--points", type=int, default=2048)
    parser.add_argument("--starts", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20260909)
    parser.add_argument("--json", type=Path,
                        default=Path("dido_klein_relaxation_report.json"))
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_experiment(tuple(args.areas), modes=args.modes,
                            points=args.points, starts=args.starts, seed=args.seed)
    print_report(report)
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {args.json}")
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

"""Executable audit for the local and global limits of the Dido J principle.

This program complements, rather than replaces, numerical relaxation.  It
separates three kinds of evidence:

* LOGICAL: a finite implication/dependency check mirroring the proof;
* ANALYTIC: closed-form identities for an explicit smooth warped sphere;
* NUMERICAL: quadrature and sampled perturbations used as regression checks.

It does not claim that finite computation proves a theorem over all smooth
curves.  Its decisive negative example is analytic: two nested length-2*pi
disks have J=0 and are strict local maxima, but their areas differ by 8*pi.

Python 3.10+. Dependencies: NumPy and SciPy.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import asdict, dataclass
from typing import Iterable

import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq


TAU = 2.0 * math.pi
R1 = 2.0
R2 = 6.0
POLE_DISTANCE = 9.0


@dataclass(frozen=True)
class Check:
    name: str
    kind: str
    passed: bool
    value: object
    requirement: str


def stable_seed(master: int, *tags: object) -> int:
    """Process-independent seed; never use Python's salted hash()."""
    payload = json.dumps([master, *tags], sort_keys=True,
                         separators=(",", ":"), default=str).encode()
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


def _h(t: np.ndarray | float) -> np.ndarray:
    x = np.asarray(t, dtype=float)
    result = np.zeros_like(x)
    positive = x > 0.0
    result[positive] = np.exp(-1.0 / x[positive])
    return result


def smooth_step(t: np.ndarray | float) -> np.ndarray:
    """C-infinity step: 0 on (-inf,0], 1 on [1,inf)."""
    x = np.asarray(t, dtype=float)
    left = _h(x)
    right = _h(1.0 - x)
    denominator = left + right
    return np.divide(left, denominator, out=np.zeros_like(left),
                     where=denominator > 0.0)


def chi(x: np.ndarray | float) -> np.ndarray:
    z = np.asarray(x, dtype=float)
    return smooth_step((0.25 - z * z) / 0.1875)


def profile(r: np.ndarray | float) -> np.ndarray:
    """The directly smooth sphere profile from the corrected addendum."""
    x = np.asarray(r, dtype=float)
    south = smooth_step(2.0 - 4.0 * x)
    north = smooth_step(2.0 - 4.0 * (POLE_DISTANCE - x))
    return (1.0 + south * (x - 1.0) + north * (8.0 - x)
            + 0.5 * (x - R1) * chi(x - R1)
            + 0.5 * (x - R2) * chi(x - R2))


def parallel_invariants(radius: float) -> dict[str, float]:
    """Closed-form invariants at either prescribed parallel."""
    if radius not in (R1, R2):
        raise ValueError("closed-form certificate is only for r=2 or r=6")
    a, ap, app = 1.0, 0.5, 0.0
    return {
        "a": a,
        "a_prime": ap,
        "a_second": app,
        "length": TAU * a,
        "kappa_g": ap / a,
        "K": -app / a,
        "J": 0.0,
        "length_gradient_on_one": TAU * ap,
        "gauss_bonnet_boundary": TAU * ap,
        "gauss_bonnet_bulk": -TAU * (ap - 1.0),
    }


def proof_dependency_checks() -> list[Check]:
    """Audit the theorem's logic without pretending this is a proof assistant."""
    return [
        Check("attainment_hypothesis", "LOGICAL", True, "required",
              "A global optimizer theorem must assume or separately prove attainment."),
        Check("regular_case", "LOGICAL", True,
              "delta A=lambda delta L => 1=lambda*kappa_g",
              "The fundamental lemma forces constant geodesic curvature."),
        Check("singular_case", "LOGICAL", True,
              "delta L=0 for all f => kappa_g=0",
              "A singular length gradient also gives constant geodesic curvature."),
        Check("energy_conclusion", "LOGICAL", True,
              "kappa_g constant => J=integral |d_s kappa_g|^2 ds=0",
              "The attained smooth maximizer minimizes J absolutely."),
        Check("local_scope", "LOGICAL", True,
              "fixed normal coordinates; nondegenerate local maximum",
              "The local area-deficit estimate is relative to that local maximum."),
        Check("global_scope", "LOGICAL", True,
              "J does not select among disconnected/local zero-energy candidates",
              "No global deficit conclusion follows from J alone."),
    ]


def construction_checks(grid_points: int = 20001) -> list[Check]:
    grid = np.linspace(0.0, POLE_DISTANCE, grid_points)
    values = profile(grid)
    interior_min = float(np.min(values[1:-1]))
    integral, quadrature_error = quad(lambda r: float(profile(r)), R1, R2,
                                      epsabs=1.0e-13, epsrel=1.0e-13, limit=300)
    gap = TAU * integral
    p1 = parallel_invariants(R1)
    p2 = parallel_invariants(R2)
    gb1 = p1["gauss_bonnet_boundary"] + p1["gauss_bonnet_bulk"]
    eigenvalues = [n * n - 0.25 for n in range(1, 9)]
    return [
        Check("pole_values", "ANALYTIC", bool(profile(0.0) == 0.0 and
              profile(POLE_DISTANCE) == 0.0),
              [float(profile(0.0)), float(profile(POLE_DISTANCE))],
              "a=r near the south pole and a=9-r near the north pole."),
        Check("profile_positive", "ANALYTIC+SAMPLED", interior_min > 0.0,
              interior_min, "a(r)>0 in the open interval; analytic lower bound is 3/4 on interior supports."),
        Check("prescribed_jets", "ANALYTIC", True,
              {"r=2": [1.0, 0.5, 0.0], "r=6": [1.0, 0.5, 0.0]},
              "a=1+(r-r_i)/2 on |r-r_i|<=1/4."),
        Check("equal_length", "ANALYTIC", p1["length"] == p2["length"] == TAU,
              [p1["length"], p2["length"]], "Both boundaries have length 2*pi."),
        Check("regular_constraint", "ANALYTIC", p1["length_gradient_on_one"] != 0.0,
              p1["length_gradient_on_one"], "delta L(1)=pi is nonzero."),
        Check("zero_energy", "ANALYTIC", p1["J"] == p2["J"] == 0.0,
              [p1["J"], p2["J"]], "Both parallels have constant kappa_g=1/2."),
        Check("gauss_bonnet", "ANALYTIC", abs(gb1 - TAU) < 1.0e-15,
              gb1, "Boundary pi plus bulk pi equals 2*pi."),
        Check("nondegenerate_spectrum", "ANALYTIC", min(eigenvalues) >= 0.75,
              eigenvalues, "lambda_n=n^2-1/4 >= 3/4 for nonconstant modes."),
        Check("area_integral", "NUMERICAL-CROSSCHECK", abs(integral - 4.0) < 2.0e-11,
              {"integral": integral, "quad_error": quadrature_error},
              "Odd corrections cancel analytically, so integral_2^6 a(r)dr=4."),
        Check("exact_area_gap", "ANALYTIC", abs(gap - 8.0 * math.pi) < 2.0e-10,
              gap, "A(D2)-A(D1)=2*pi*4=8*pi."),
        Check("global_bound_impossible", "ANALYTIC", gap > 0.0 and p1["J"] == 0.0,
              {"deficit_lower_bound": gap, "omega_of_J": 0.0},
              "Any finite omega with omega(0)=0 gives a false bound at D1."),
    ]


def _periodic_derivative(values: np.ndarray) -> np.ndarray:
    n = len(values)
    frequencies = np.fft.fftfreq(n, d=1.0 / n)
    return np.fft.ifft(1j * frequencies * np.fft.fft(values)).real


def graph_metrics(u: np.ndarray) -> dict[str, float]:
    """Exact local formulas in the linear profile band a=1+u/2."""
    up = _periodic_derivative(u)
    upp = _periodic_derivative(up)
    a = 1.0 + 0.5 * u
    ap = 0.5
    sigma = np.sqrt(a * a + up * up)
    kg = (a * a * ap + 2.0 * ap * up * up - a * upp) / sigma**3
    kg_theta = _periodic_derivative(kg)
    length = TAU * float(np.mean(sigma))
    area_delta = TAU * float(np.mean(u + 0.25 * u * u))
    j_energy = TAU * float(np.mean(kg_theta * kg_theta / sigma))
    dirichlet = TAU * float(np.mean(up * up))
    return {"length": length, "area_delta": area_delta, "J": j_energy,
            "dirichlet": dirichlet, "max_abs_u": float(np.max(np.abs(u)))}


def local_perturbation_checks(master_seed: int = 20260702,
                              trials: int = 48,
                              points: int = 2048) -> list[Check]:
    """Regression-test the nonlinear local inequality on exact-length graphs."""
    rng = np.random.default_rng(stable_seed(master_seed, "local-graphs"))
    theta = np.linspace(0.0, TAU, points, endpoint=False)
    worst_margin = math.inf
    worst_area = -math.inf
    min_j = math.inf
    completed = 0
    for trial in range(trials):
        raw = np.zeros(points)
        for n in range(1, 7):
            scale = 0.012 / n**3
            raw += scale * (rng.normal() * np.cos(n * theta)
                            + rng.normal() * np.sin(n * theta))
        raw -= float(np.mean(raw))

        def length_error(c: float) -> float:
            return graph_metrics(raw + c)["length"] - TAU

        # The needed constant is negative and quadratic in the perturbation.
        constant = brentq(length_error, -0.10, 0.05, xtol=1.0e-14)
        metrics = graph_metrics(raw + constant)
        if metrics["max_abs_u"] >= 0.24:
            continue
        margin = -0.5 * metrics["dirichlet"] - metrics["area_delta"]
        worst_margin = min(worst_margin, margin)
        worst_area = max(worst_area, metrics["area_delta"])
        min_j = min(min_j, metrics["J"])
        completed += 1
    passed = completed == trials and worst_margin >= -2.0e-10 and worst_area < 0.0
    return [
        Check("nonlinear_local_maximum", "NUMERICAL-REGRESSION", passed,
              {"trials": completed, "largest_area_change": worst_area,
               "smallest_margin": worst_margin},
              "Exact-length nearby nonconstant graphs satisfy Delta A <= -1/2 int(u')^2 < 0."),
        Check("perturbations_have_positive_J", "NUMERICAL-REGRESSION", min_j > 0.0,
              min_j, "Nonconstant sampled graphs have positive curvature-variation energy."),
    ]


def run_audit(master_seed: int = 20260702, trials: int = 48,
              points: int = 2048) -> dict[str, object]:
    checks = (proof_dependency_checks() + construction_checks()
              + local_perturbation_checks(master_seed, trials, points))
    return {
        "program": "dido_argument_audit.py",
        "all_checks_pass": all(check.passed for check in checks),
        "checks": [asdict(check) for check in checks],
        "conclusion": (
            "The attained-maximizer implication and repaired local theorem are "
            "logically represented; the smooth-sphere witness proves that J alone "
            "cannot certify global area optimality. Finite computation remains a "
            "regression audit, not a proof of universal quantified statements."
        ),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20260702)
    parser.add_argument("--trials", type=int, default=48)
    parser.add_argument("--points", type=int, default=2048)
    parser.add_argument("--json", action="store_true", help="emit JSON")
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_audit(args.seed, args.trials, args.points)
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        for check in report["checks"]:
            print("[{}] {:<29} {:<20} {}".format(
                "PASS" if check["passed"] else "FAIL", check["name"],
                check["kind"], check["value"]))
        print("\n" + report["conclusion"])
    return 0 if report["all_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

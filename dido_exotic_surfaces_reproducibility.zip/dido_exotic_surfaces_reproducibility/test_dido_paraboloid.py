import math
import unittest

import numpy as np

import dido_paraboloid as paraboloid


class ParaboloidTests(unittest.TestCase):
    def test_area_primitive_derivative(self):
        for radius in (0.2, 1.0, 2.0):
            step = 1.0e-5
            derivative = (
                float(paraboloid.area_primitive(radius + step))
                - float(paraboloid.area_primitive(radius - step))
            ) / (2.0 * step)
            expected = radius * math.sqrt(1.0 + 4.0 * radius**2)
            self.assertAlmostEqual(derivative, expected, places=9)

    def test_circle_known_answers(self):
        for length in (3.0, 6.0, 9.0):
            ref = paraboloid.circle_reference(length, points=1024)
            self.assertAlmostEqual(ref["length"], length, places=12)
            self.assertAlmostEqual(ref["area"], ref["area_exact"], places=12)
            self.assertAlmostEqual(ref["kappa_g_mean"], ref["kappa_exact"], places=12)
            self.assertAlmostEqual(ref["K_min"], ref["K_exact"], places=12)
            self.assertLess(ref["J"], 1.0e-20)
            self.assertLess(abs(ref["gauss_bonnet_residual"]), 1.0e-12)

    def test_perturbed_graph_gauss_bonnet(self):
        loop = paraboloid.RadialLoop(3, 2048)
        coefficients = loop.circle(1.0)
        coefficients[1] = 0.05
        coefficients[2] = -0.02
        self.assertLess(abs(paraboloid.gauss_bonnet_residual(loop, coefficients)),
                        1.0e-11)

    def test_optimizer_recovers_circle(self):
        case = paraboloid.run_case(6.0, modes=4, points=512,
                                   starts=3, seed=20260909)
        self.assertEqual(case["status"], "pass", case)

    def test_full_experiment(self):
        report = paraboloid.run_experiment(modes=4, points=512, starts=3)
        self.assertTrue(report["all_gates_pass"], report)


if __name__ == "__main__":
    unittest.main()

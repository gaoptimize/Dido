import math
import unittest

import numpy as np

import dido_klein_relaxation as relax


class KleinRelaxationTests(unittest.TestCase):
    def test_exact_circle_and_separator(self):
        disk_basis = relax.FourierBasis(4, 512, relax.TAU)
        disk = relax.disk_metrics(np.zeros(8), 0.5, disk_basis)
        self.assertAlmostEqual(disk["area"], 0.5, places=13)
        self.assertAlmostEqual(disk["length"], 2.0 * math.sqrt(math.pi * 0.5),
                               places=12)
        self.assertLess(disk["J"], 1.0e-20)

        surface = relax.FlatKleinBottle()
        sep_basis = relax.FourierBasis(4, 512, surface.cover_width)
        separator = relax.separator_metrics(np.zeros(8), 6.0, surface,
                                             sep_basis)
        self.assertAlmostEqual(separator["area"], 6.0, places=13)
        self.assertAlmostEqual(separator["length"], 4.0, places=13)
        self.assertLess(separator["J"], 1.0e-20)

    def test_crossover(self):
        self.assertAlmostEqual(2.0 * math.sqrt(math.pi * (4.0 / math.pi)), 4.0)

    def test_representative_relaxations(self):
        report = relax.run_experiment(modes=4, points=512, starts=2)
        self.assertTrue(report["all_gates_pass"], report["gates"])
        self.assertEqual(len(report["rows"]), 7)


if __name__ == "__main__":
    unittest.main()

import math
import unittest

import numpy as np

import dido_horn as horn


class HornGeometryTests(unittest.TestCase):
    def setUp(self):
        self.metric = horn.HornMetric()

    def test_area_primitive_derivative(self):
        for x in (1.1, 2.0, 8.0, 40.0):
            step = 1.0e-5 * x
            numeric = (
                float(self.metric.tail_area_primitive(x + step))
                - float(self.metric.tail_area_primitive(x - step))
            ) / (2.0 * step)
            self.assertAlmostEqual(numeric,
                                   float(self.metric.area_density(x)), places=9)

    def test_gaussian_curvature_primitive_derivative(self):
        for x in (1.1, 2.0, 8.0):
            step = 1.0e-5 * x
            numeric = (
                float(self.metric.bulk_curvature_primitive(x + step))
                - float(self.metric.bulk_curvature_primitive(x - step))
            ) / (2.0 * step)
            expected = float(
                self.metric.gaussian_curvature(x)
                * self.metric.area_density(x)
            )
            self.assertAlmostEqual(numeric, expected, places=9)

    def test_parallel_known_answers(self):
        for x in (1.0, 2.0, 8.0, 32.0):
            ref = horn.parallel_reference(self.metric, x, 1024)
            self.assertAlmostEqual(ref["length_numeric"], 2.0 * math.pi / x,
                                   places=12)
            self.assertAlmostEqual(ref["kappa_numeric"], ref["kappa_exact"],
                                   places=12)
            self.assertAlmostEqual(ref["K_numeric"], ref["K_exact"], places=12)
            self.assertLess(ref["J"], 1.0e-20)
            self.assertLess(abs(ref["gauss_bonnet_residual"]), 1.0e-12)

    def test_exact_length_escape_graphs(self):
        amplitudes = []
        areas = []
        for center in (8.0, 16.0, 32.0):
            graph = horn.solve_exact_length(self.metric, center, 6.0, 1024)
            data = horn.diagnostics(self.metric, graph, 6.0)
            amplitudes.append(graph.amplitude)
            areas.append(float(data["enclosed_tail_area"]))
            self.assertLess(float(data["length_relative_error"]), 2.0e-12)
            self.assertTrue(data["admissible"])
            self.assertLess(abs(float(data["gauss_bonnet_residual"])), 1.0e-8)
        self.assertTrue(np.all(np.diff(areas) > 0.0))
        self.assertAlmostEqual(amplitudes[-1], 1.5, delta=0.02)

    def test_full_experiment(self):
        report = horn.run_experiment(points=2048)
        self.assertTrue(report["all_gates_pass"], report["gates"])


if __name__ == "__main__":
    unittest.main()

"""Topology-aware Dido diagnostics on a rectangular flat torus.

This experiment records exact candidates that a single contractible-loop
relaxation cannot represent: disk complements, two-boundary bands, and an
essential loop that is not itself a region boundary.  All geometry is intrinsic
to R2/(width Z x height Z).

Python 3.10+. Dependency: NumPy.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


TAU = 2.0 * math.pi


@dataclass(frozen=True)
class FlatTorus:
    width: float = 4.0
    height: float = 6.0

    def __post_init__(self) -> None:
        if not self.width > 0.0 or not self.height > 0.0:
            raise ValueError("periods must be positive")

    @property
    def area(self) -> float:
        return self.width * self.height

    @property
    def injectivity_radius(self) -> float:
        return 0.5 * min(self.width, self.height)


@dataclass(frozen=True)
class Candidate:
    name: str
    topology: str
    boundary_components: int
    boundary_homology: str
    euler_characteristic: int | None
    total_length: float
    selected_area: float | None
    total_J: float
    boundary_curvature_integral: float | None
    gauss_bonnet_residual: float | None
    admissible_region: bool
    note: str


def contractible_circle_samples(length: float,
                                points: int = 4096) -> dict[str, float]:
    radius = length / TAU
    theta = np.linspace(0.0, TAU, points, endpoint=False)
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    xp = -radius * np.sin(theta)
    yp = radius * np.cos(theta)
    xpp = -radius * np.cos(theta)
    ypp = -radius * np.sin(theta)
    speed = np.sqrt(xp * xp + yp * yp)
    kappa = (xp * ypp - yp * xpp) / speed**3
    kappa_t = np.fft.ifft(
        1j * np.fft.fftfreq(points, d=1.0 / points) * np.fft.fft(kappa)
    ).real
    measured_length = TAU * float(np.mean(speed))
    measured_area = 0.5 * TAU * float(np.mean(x * yp - y * xp))
    J = TAU * float(np.mean(kappa_t * kappa_t / speed))
    return {"radius": radius, "length": measured_length,
            "area": measured_area, "kappa_g": float(np.mean(kappa)), "J": J}


def disk_and_complement(torus: FlatTorus, length: float) -> tuple[Candidate, Candidate]:
    radius = length / TAU
    if radius >= torus.injectivity_radius:
        raise ValueError("circle must lie below the torus injectivity radius")
    disk_area = math.pi * radius**2
    disk = Candidate(
        "contractible_disk", "disk", 1, "zero", 1, length, disk_area, 0.0,
        TAU, 0.0, True,
        "Embedded Euclidean disk in an injectivity-radius chart.")
    complement = Candidate(
        "disk_complement", "genus-1 surface with one boundary", 1, "zero", -1,
        length, torus.area - disk_area, 0.0, -TAU, 0.0, True,
        "Same geometric curve, opposite selected side and boundary orientation.")
    return disk, complement


def horizontal_band(torus: FlatTorus, width: float) -> Candidate:
    if not 0.0 < width < torus.height:
        raise ValueError("band width must lie strictly between 0 and torus height")
    total_length = 2.0 * torus.width
    return Candidate(
        "horizontal_band_{:.3g}".format(width), "annulus", 2,
        "(+1,0) and (-1,0)", 0, total_length, torus.width * width,
        0.0, 0.0, 0.0, True,
        "Two geodesic components; perimeter is independent of band width.")


def essential_single_loop(torus: FlatTorus) -> Candidate:
    return Candidate(
        "single_essential_loop", "no selected region", 1, "(1,0)", None,
        torus.width, None, 0.0, None, None, False,
        "A nonseparating essential loop is not the boundary of a region by itself.")


def run_experiment(torus: FlatTorus = FlatTorus(),
                   disk_length: float = 4.0,
                   band_widths: tuple[float, ...] = (1.0, 3.0, 5.0),
                   points: int = 4096) -> dict[str, object]:
    disk, complement = disk_and_complement(torus, disk_length)
    bands = [horizontal_band(torus, width) for width in band_widths]
    rejected = essential_single_loop(torus)
    candidates = [disk, complement, *bands, rejected]
    sample = contractible_circle_samples(disk_length, points)
    gates = {
        "T0_DISK_NUMERIC_KAT": (
            abs(sample["length"] - disk.total_length) < 1.0e-12
            and abs(sample["area"] - float(disk.selected_area)) < 1.0e-12
            and abs(sample["kappa_g"] - TAU / disk_length) < 1.0e-12
            and sample["J"] < 1.0e-20
        ),
        "T1_SAME_BOUNDARY_DIFFERENT_AREAS": (
            disk.total_length == complement.total_length
            and disk.total_J == complement.total_J == 0.0
            and disk.selected_area != complement.selected_area
        ),
        "T2_EULER_CHARACTERISTIC": (
            disk.euler_characteristic == 1
            and complement.euler_characteristic == -1
            and all(band.euler_characteristic == 0 for band in bands)
        ),
        "T3_GAUSS_BONNET_BY_TOPOLOGY": all(
            candidate.gauss_bonnet_residual == 0.0
            for candidate in [disk, complement, *bands]
        ),
        "T4_TWO_COMPONENT_BANDS": all(
            band.boundary_components == 2 and band.total_J == 0.0
            for band in bands
        ),
        "T5_FIXED_PERIMETER_AREA_FAMILY": (
            len({band.total_length for band in bands}) == 1
            and len({band.selected_area for band in bands}) == len(bands)
        ),
        "T6_REJECT_SINGLE_ESSENTIAL_LOOP": not rejected.admissible_region,
    }
    return {
        "program": "dido_flat_torus.py",
        "surface": "rectangular flat torus",
        "metric": asdict(torus),
        "total_area": torus.area,
        "injectivity_radius": torus.injectivity_radius,
        "disk_numeric_reference": sample,
        "candidates": [asdict(candidate) for candidate in candidates],
        "gates": gates,
        "all_gates_pass": all(gates.values()),
        "verdict": (
            "Boundary geometry alone is insufficient on the flat torus. The "
            "selected side and region topology change area and Gauss-Bonnet, "
            "bands require two components, and a single essential loop must be rejected."
        ),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--width", type=float, default=4.0)
    parser.add_argument("--height", type=float, default=6.0)
    parser.add_argument("--disk-length", type=float, default=4.0)
    parser.add_argument("--band-widths", type=float, nargs="+", default=[1.0, 3.0, 5.0])
    parser.add_argument("--points", type=int, default=4096)
    parser.add_argument("--json", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_experiment(FlatTorus(args.width, args.height), args.disk_length,
                            tuple(args.band_widths), args.points)
    print("=" * 100)
    print("FLAT TORUS {} x {}  total area {}".format(
        args.width, args.height, report["total_area"]))
    print("=" * 100)
    for candidate in report["candidates"]:
        print("{:<25} topology={:<35} b={} L={} A={} J={} admitted={}".format(
            candidate["name"], candidate["topology"],
            candidate["boundary_components"], candidate["total_length"],
            candidate["selected_area"], candidate["total_J"],
            candidate["admissible_region"]))
    for name, passed in report["gates"].items():
        print("[{}] {}".format("PASS" if passed else "FAIL", name))
    print("VERDICT: " + report["verdict"])
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print("Wrote {}".format(args.json))
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

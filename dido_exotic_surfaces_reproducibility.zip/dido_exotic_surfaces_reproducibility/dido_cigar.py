"""Fixed-length Dido stress test on Hamilton's cigar soliton.

In geodesic polar coordinates the normalized cigar metric is

    g = drho^2 + tanh(rho)^2 dtheta^2.

Circles have length 2*pi*tanh(rho), approaching 2*pi from below, while
their enclosed area 2*pi*log(cosh(rho)) diverges.  This experiment adds a
small cosine ripple to enforce length exactly 2*pi and follows the resulting
embedded boundaries to infinity.

Python 3.10+. Dependencies: NumPy and SciPy.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.optimize import brentq


Array = np.ndarray
TAU = 2.0 * math.pi


class CigarMetric:
    @staticmethod
    def warp(rho: Array | float) -> Array:
        return np.tanh(np.asarray(rho, dtype=float))

    @staticmethod
    def warp_prime(rho: Array | float) -> Array:
        value = np.asarray(rho, dtype=float)
        return 1.0 / np.cosh(value) ** 2

    @staticmethod
    def gaussian_curvature(rho: Array | float) -> Array:
        value = np.asarray(rho, dtype=float)
        return 2.0 / np.cosh(value) ** 2

    @staticmethod
    def area_primitive(rho: Array | float) -> Array:
        value = np.asarray(rho, dtype=float)
        # Stable log(cosh(value)) for large positive value.
        return np.logaddexp(value, -value) - math.log(2.0)

    @staticmethod
    def bulk_curvature_primitive(rho: Array | float) -> Array:
        return np.tanh(np.asarray(rho, dtype=float)) ** 2


class WindingGraph:
    def __init__(self, center: float, amplitude: float, points: int):
        if points < 64 or points % 2:
            raise ValueError("points must be an even integer >= 64")
        self.center = float(center)
        self.amplitude = float(amplitude)
        self.points = int(points)
        self.theta = np.linspace(0.0, TAU, points, endpoint=False)

    def samples(self) -> tuple[Array, Array, Array]:
        rho = self.center + self.amplitude * np.cos(self.theta)
        rho_t = -self.amplitude * np.sin(self.theta)
        rho_tt = -self.amplitude * np.cos(self.theta)
        return rho, rho_t, rho_tt


def periodic_derivative(values: Array) -> Array:
    frequencies = np.fft.fftfreq(len(values), d=1.0 / len(values))
    return np.fft.ifft(1j * frequencies * np.fft.fft(values)).real


def geometry(metric: CigarMetric, graph: WindingGraph) -> dict[str, Array]:
    rho, rho_t, rho_tt = graph.samples()
    a = metric.warp(rho)
    ap = metric.warp_prime(rho)
    speed = np.sqrt(rho_t * rho_t + a * a)
    accel_rho = rho_tt - a * ap
    accel_theta = 2.0 * (ap / a) * rho_t
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        kappa_g = a * (rho_t * accel_theta - accel_rho) / speed**3
    return {
        "rho": rho,
        "rho_t": rho_t,
        "speed": speed,
        "kappa_g": kappa_g,
        "K": metric.gaussian_curvature(rho),
    }


def metric_length(metric: CigarMetric, graph: WindingGraph) -> float:
    return TAU * float(np.mean(geometry(metric, graph)["speed"]))


def enclosed_area(metric: CigarMetric, graph: WindingGraph) -> float:
    rho, _, _ = graph.samples()
    return TAU * float(np.mean(metric.area_primitive(rho)))


def region_curvature_integral(metric: CigarMetric,
                              graph: WindingGraph) -> float:
    rho, _, _ = graph.samples()
    return TAU * float(np.mean(metric.bulk_curvature_primitive(rho)))


def jerk_energy(metric: CigarMetric, graph: WindingGraph) -> float:
    data = geometry(metric, graph)
    kappa_t = periodic_derivative(data["kappa_g"])
    return TAU * float(np.mean(kappa_t * kappa_t / data["speed"]))


def gauss_bonnet_residual(metric: CigarMetric,
                          graph: WindingGraph) -> float:
    data = geometry(metric, graph)
    boundary = TAU * float(np.mean(data["kappa_g"] * data["speed"]))
    return boundary + region_curvature_integral(metric, graph) - TAU


def weighted_mean(values: Array, weights: Array) -> float:
    return float(np.sum(values * weights) / np.sum(weights))


def weighted_std(values: Array, weights: Array) -> float:
    mean = weighted_mean(values, weights)
    return float(np.sqrt(np.sum(weights * (values - mean) ** 2)
                         / np.sum(weights)))


def parallel_reference(metric: CigarMetric, rho: float,
                       points: int = 2048) -> dict[str, float]:
    graph = WindingGraph(rho, 0.0, points)
    data = geometry(metric, graph)
    a = math.tanh(rho)
    exact_kappa = (1.0 / math.cosh(rho) ** 2) / a
    return {
        "rho": rho,
        "length_numeric": metric_length(metric, graph),
        "length_exact": TAU * a,
        "area_numeric": enclosed_area(metric, graph),
        "area_exact": TAU * math.log(math.cosh(rho)),
        "kappa_numeric": weighted_mean(data["kappa_g"], data["speed"]),
        "kappa_exact": exact_kappa,
        "K_numeric": weighted_mean(data["K"], data["speed"]),
        "K_exact": 2.0 / math.cosh(rho) ** 2,
        "J": jerk_energy(metric, graph),
        "gauss_bonnet_residual": gauss_bonnet_residual(metric, graph),
    }


def solve_exact_length(metric: CigarMetric, center: float,
                       target_length: float, points: int) -> WindingGraph:
    if TAU * math.tanh(center) >= target_length:
        raise ValueError("center circle must have length below the target")

    def residual(amplitude: float) -> float:
        return metric_length(metric, WindingGraph(center, amplitude, points)) \
            - target_length

    low, high = 0.0, 0.05
    while residual(high) <= 0.0:
        high *= 1.7
    if high >= center:
        raise ValueError("ripple would cross the cigar tip")
    amplitude = brentq(residual, low, high, xtol=1.0e-14, rtol=1.0e-14)
    return WindingGraph(center, amplitude, points)


def diagnostics(metric: CigarMetric, graph: WindingGraph,
                target_length: float) -> dict[str, float | bool]:
    data = geometry(metric, graph)
    length = metric_length(metric, graph)
    return {
        "center": graph.center,
        "amplitude": graph.amplitude,
        "minimum_rho": float(np.min(data["rho"])),
        "length": length,
        "length_relative_error": abs(length - target_length) / target_length,
        "area": enclosed_area(metric, graph),
        "kappa_g_mean": weighted_mean(data["kappa_g"], data["speed"]),
        "kappa_g_wstd": weighted_std(data["kappa_g"], data["speed"]),
        "K_min": float(np.min(data["K"])),
        "K_max": float(np.max(data["K"])),
        "J": jerk_energy(metric, graph),
        "gauss_bonnet_residual": gauss_bonnet_residual(metric, graph),
        "admissible": bool(np.min(data["rho"]) > 0.0),
    }


def run_experiment(target_length: float = TAU,
                   centers: tuple[float, ...] = (2.0, 3.0, 4.0, 5.0, 6.0),
                   points: int = 2048) -> dict[str, object]:
    metric = CigarMetric()
    refs = [parallel_reference(metric, rho, points) for rho in (0.5, 2.0, 5.0)]
    rows: list[dict[str, float | bool]] = []
    resolution: list[dict[str, float]] = []
    for center in centers:
        low_graph = solve_exact_length(metric, center, target_length, points)
        high_graph = solve_exact_length(metric, center, target_length, 2 * points)
        low = diagnostics(metric, low_graph, target_length)
        high = diagnostics(metric, high_graph, target_length)
        rows.append(high)
        resolution.append({
            "center": center,
            "area_absolute_difference": abs(float(high["area"]) - float(low["area"])),
            "J_relative_difference": abs(float(high["J"]) - float(low["J"]))
            / max(abs(float(high["J"])), 1.0e-30),
            "gb_high": abs(float(high["gauss_bonnet_residual"])),
        })

    areas = np.array([float(row["area"]) for row in rows])
    slope, intercept = np.polyfit(np.asarray(centers), areas, 1)
    parallel_ok = all(
        abs(ref["length_numeric"] - ref["length_exact"]) < 1.0e-12
        and abs(ref["area_numeric"] - ref["area_exact"]) < 1.0e-12
        and abs(ref["kappa_numeric"] - ref["kappa_exact"]) < 1.0e-12
        and abs(ref["K_numeric"] - ref["K_exact"]) < 1.0e-12
        and ref["J"] < 1.0e-20
        and abs(ref["gauss_bonnet_residual"]) < 1.0e-12
        for ref in refs
    )
    gates = {
        "C0_PARALLEL_KAT": parallel_ok,
        "C1_EXACT_LENGTH": all(float(row["length_relative_error"]) < 2.0e-12
                               for row in rows),
        "C2_ADMISSIBLE_GRAPH": all(bool(row["admissible"]) for row in rows),
        "C3_GAUSS_BONNET": all(abs(float(row["gauss_bonnet_residual"])) < 1.0e-10
                                for row in rows),
        "C4_AREA_STRICTLY_GROWS": bool(np.all(np.diff(areas) > 0.0)),
        "C5_LINEAR_AREA_SLOPE": abs(float(slope) - TAU) / TAU < 0.03,
        "C6_RESOLUTION": all(
            item["area_absolute_difference"] < 1.0e-10
            and item["J_relative_difference"] < 1.0e-6
            and item["gb_high"] < 1.0e-10
            for item in resolution
        ),
    }
    return {
        "program": "dido_cigar.py",
        "surface": "Hamilton cigar soliton",
        "scope": "winding-one radial cosine graphs; numerical stress test",
        "target_length": target_length,
        "points_reported": 2 * points,
        "parallel_references": refs,
        "escape_sequence": rows,
        "resolution": resolution,
        "area_fit": {"model": "area=slope*center+intercept",
                     "slope": float(slope), "expected_slope": TAU,
                     "intercept": float(intercept)},
        "gates": gates,
        "all_gates_pass": all(gates.values()),
        "verdict": (
            "At the asymptotic circumference 2*pi, exact-length embedded "
            "boundaries escape to infinity while enclosed area grows linearly. "
            "The tested family has no finite global champion."
        ),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--length", type=float, default=TAU)
    parser.add_argument("--centers", type=float, nargs="+",
                        default=[2.0, 3.0, 4.0, 5.0, 6.0])
    parser.add_argument("--points", type=int, default=2048)
    parser.add_argument("--json", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_experiment(args.length, tuple(args.centers), args.points)
    print("=" * 92)
    print("HAMILTON CIGAR  fixed length = {:.12f}".format(args.length))
    print("=" * 92)
    for row in report["escape_sequence"]:
        print("rho={center:>4.1f} A={amplitude:.9e} L={length:.12f} "
              "area={area:.9f} J={J:.4e} GB={gauss_bonnet_residual:+.2e}"
              .format(**row))
    print("area/rho fitted slope = {:.9f}; expected 2*pi = {:.9f}".format(
        report["area_fit"]["slope"], TAU))
    for name, passed in report["gates"].items():
        print("[{}] {}".format("PASS" if passed else "FAIL", name))
    print("VERDICT: " + report["verdict"])
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True),
                             encoding="utf-8")
        print("Wrote {}".format(args.json))
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

import math
import unittest

import dido_horn_asymptotics as asymptotics


class HornAsymptoticsTests(unittest.TestCase):
    def test_known_constants_at_length_six(self):
        self.assertAlmostEqual(asymptotics.area_offset_limit(),
                               0.709959588823495, places=14)
        self.assertAlmostEqual(asymptotics.j_coefficient_limit(6.0),
                               216.0 / 35.0, places=14)

    def test_amplitude_prediction_converges(self):
        report = asymptotics.run_study(
            centers=(64.0, 128.0, 256.0), samples_per_depth=64)
        ratios = [row["amplitude_deficit_ratio"] for row in report["rows"]]
        self.assertLess(abs(ratios[-1] - 1.0), abs(ratios[0] - 1.0))
        self.assertLess(abs(ratios[-1] - 1.0), 2.0e-4)

    def test_full_five_point_study(self):
        report = asymptotics.run_study()
        self.assertTrue(report["all_gates_pass"], report["gates"])
        self.assertAlmostEqual(report["last_three_fits"]["J_power_exponent"],
                               6.0, delta=0.002)
        self.assertAlmostEqual(report["last_three_fits"]["area_log_slope"],
                               2.0 * math.pi, delta=0.0002)


if __name__ == "__main__":
    unittest.main()

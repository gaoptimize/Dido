"""Run the archived Dido surface campaign from a clean source bundle."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PYTHON = sys.executable


def run(*arguments: str) -> None:
    print("\n>>", PYTHON, *arguments, flush=True)
    subprocess.run([PYTHON, *arguments], cwd=ROOT, check=True)


def main() -> int:
    run("-m", "unittest", "discover", "-v", "-p", "test_dido_*.py")
    run("dido_surface_suite.py")
    run("dido_torus.py", "--json", "dido_ring_torus_report.json")
    run("dido_verifier_v3.py", "quick")
    run("dido_survey.py", "quick", "--json", "dido_survey_quick_report.json")
    run("dido_horn_asymptotics.py")
    run("dido_cigar_asymptotics.py")
    run("dido_klein_relaxation.py")
    print("\nREPRODUCTION COMPLETE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

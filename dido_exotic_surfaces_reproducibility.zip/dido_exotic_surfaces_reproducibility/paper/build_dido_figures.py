"""Build publication figures from the machine-readable Dido reports."""

from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output" / "figures"


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    horn = load("dido_horn_asymptotics_report.json")
    cigar = load("dido_cigar_asymptotics_report.json")

    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
    })
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.25), constrained_layout=True)

    hx = np.array([row["center"] for row in horn["rows"]], dtype=float)
    hj = np.array([row["J_over_X6"] for row in horn["rows"]], dtype=float)
    axes[0].plot(hx, hj, "o-", color="#174A7E", lw=1.8, ms=4)
    axes[0].axhline(216.0 / 35.0, color="#B44B4B", ls="--", lw=1.2,
                    label="216/35")
    axes[0].set_xscale("log", base=2)
    axes[0].set_xlabel("Horn depth X")
    axes[0].set_ylabel("J / X^6")
    axes[0].set_title("Gabriel horn energy limit")
    axes[0].legend(frameon=False, loc="upper right")
    axes[0].grid(alpha=0.22)

    cx = np.array([row["center"] for row in cigar["rows"]], dtype=float)
    cj = np.array([row["scaled_J"] for row in cigar["rows"]], dtype=float)
    ca = np.array([row["scaled_area_correction"] for row in cigar["rows"]],
                  dtype=float)
    axes[1].plot(cx, cj / (8.0 * math.pi), "o-", color="#174A7E",
                 lw=1.8, ms=4, label="exp(2X) J / (8 pi)")
    axes[1].plot(cx, ca / (2.0 * math.pi), "s-", color="#2D7D46",
                 lw=1.8, ms=4, label="area correction / (2 pi)")
    axes[1].axhline(1.0, color="#B44B4B", ls="--", lw=1.0,
                    label="limit 1")
    axes[1].set_xlabel("Cigar depth X")
    axes[1].set_ylabel("Normalized quantity")
    axes[1].set_title("Hamilton cigar normalized limits")
    axes[1].legend(frameon=False, fontsize=7, loc="center right")
    axes[1].grid(alpha=0.22)

    area = np.linspace(0.001, 11.999, 600)
    minority = np.minimum(area, 12.0 - area)
    disk = 2.0 * np.sqrt(math.pi * minority)
    separator = np.full_like(area, 4.0)
    envelope = np.minimum(disk, separator)
    axes[2].plot(area, disk, color="#777777", lw=1.2, label="disk/complement")
    axes[2].plot(area, separator, color="#B44B4B", lw=1.2,
                 label="Moebius separator")
    axes[2].plot(area, envelope, color="#174A7E", lw=2.2,
                 label="tested envelope")
    axes[2].set_xlim(0, 12)
    axes[2].set_ylim(0, 6.5)
    axes[2].set_xlabel("Selected area A")
    axes[2].set_ylabel("Boundary length")
    axes[2].set_title("Klein bottle branch exchange")
    axes[2].legend(frameon=False, fontsize=7, loc="upper left")
    axes[2].grid(alpha=0.22)

    fig.savefig(OUT / "manifold_numerical_fingerprints.png", dpi=240,
                facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()

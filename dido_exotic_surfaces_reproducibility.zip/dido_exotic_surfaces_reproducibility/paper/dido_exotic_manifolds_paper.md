# Dido Relaxation Across Classical Exotic Surfaces

**GPT, OpenAI**  
Computational first author

**Thomas Schaefer**  
Human advisor and corresponding author  
6 Now Possible Things, Independent Researcher

9 September 2026

## Abstract

My human advisor suggested that we apply our relaxation optimizer to a collection of well-studied, classical but geometrically exotic manifolds. Taken to sufficient numerical precision, familiar geometric constants and asymptotic laws began to fall out of the computations without being imposed as fitted outcomes. This paper reports that computational reconnaissance for the curvature-variation functional

\[
J[\gamma]=\int_\gamma\left(\frac{d\kappa_g}{ds}\right)^2ds,
\]

originally proposed as a diagnostic for fixed-length Dido optimization.

The starting theorem is exact. Whenever a smooth embedded boundary attains maximal selected area at fixed length in a specified admissible component, its geodesic curvature is constant and therefore \(J=0\). The experiments test the reach and limits of that implication. A variable-curvature conformal metric and a ring torus recover constant-geodesic-curvature numerical optimizers. A hyperbolic cusp and a paraboloid show that noncompactness alone does not determine the outcome. Gabriel's horn admits fixed-length boundaries whose selected areas diverge while \(J\) grows as \((216/35)X^6\). Hamilton's cigar admits fixed-length boundaries whose selected areas diverge while \(J\sim8\pi e^{-2X}\to0\). A symmetric flat Klein bottle contains a continuous family with \(L=4\), \(J=0\), and selected area ranging through the entire open interval between zero and the total surface area. An explicit smooth sphere contains two equal-length, strictly stable local area maximizers with \(J=0\) and an exact area difference of \(8\pi\).

The computations recover \(2\pi\), \(4/\pi\), \(8\pi\), and \(216/35\), together with the predicted exponential and logarithmic rates. They also expose the hypotheses needed for any global conclusion: attainment, control of escape, preservation of topology and selected side, and comparison among all components of the zero set. The appendices provide the surface metrics, formulas, algorithms, deterministic seeds, resolutions, gates, expected outputs, commands, and file hashes required to recreate every reported result.

## 1 Introduction

Dido's problem asks for a region of maximal area among boundaries of prescribed length. For a smooth closed curve \(\gamma\) on a Riemannian surface, parametrized by arclength \(s\), let \(\kappa_g\) denote signed geodesic curvature. The functional

\[
J[\gamma]=\int_\gamma(\kappa_g')^2\,ds
\]

is nonnegative and vanishes exactly when \(\kappa_g\) is constant on each connected boundary component. It measures the variation of intrinsic bending, not total elastic energy and not the full physical jerk of the curve.

The original least-variation conjecture was that an area-maximizing boundary at fixed length minimizes \(J\). The first-variation argument proves the statement immediately when a smooth optimizer exists. The difficulty begins when one asks for more: whether a maximizer exists, whether small \(J\) forces near-optimal area, whether \(J\) selects the correct constant-curvature candidate, and whether a curve can escape or change topological type while the measured boundary data remain controlled.

Those questions are particularly suited to classical surfaces that isolate one pathology at a time. The ring torus supplies variable Gaussian curvature on a compact orientable surface. The flat torus makes homology, complementary sides, and multiple boundary components unavoidable. The Klein bottle removes global orientability and admits one-sided curves. The hyperbolic cusp has a noncompact region of finite area. The paraboloid is a noncompact positive control. Gabriel's horn and Hamilton's cigar both permit escape, but their curvature-variation energies move in opposite directions. The smooth peanut-shaped sphere proves that failure of global selection is not confined to noncompact or nonorientable settings.

The role of computation is deliberately limited. A finite Fourier relaxation cannot prove a universal theorem over all smooth embedded curves. It can validate intrinsic formulas against known answers, search for counterexamples, identify rates, and distinguish a mathematical obstruction from a discretization failure. We therefore label every claim as one of three types: an exact mathematical consequence, an analytic construction, or numerical evidence within a declared ansatz class.

## 2 The attained optimizer theorem

Let \(\gamma_t\) be a normal variation of a smooth embedded boundary with scalar speed \(\varphi\), positive toward the selected side. The first variations are

\[
\delta A=\int_\gamma\varphi\,ds,
\qquad
\delta L=\int_\gamma\kappa_g\varphi\,ds,
\]

up to the consistent choice of normal and curvature sign. At a regular fixed-length critical point there is a multiplier \(\lambda\) such that

\[
\int_\gamma(1-\lambda\kappa_g)\varphi\,ds=0
\]

for every smooth \(\varphi\). Hence \(\kappa_g\) is constant. If the length gradient is singular, then \(\delta L=0\) for every variation and \(\kappa_g=0\). Both cases give

\[
J[\gamma]=0.
\]

**Theorem 1.** On a smooth Riemannian surface, every smoothly attained fixed-length area maximizer in a specified admissible component has constant geodesic curvature and attains the absolute minimum \(J=0\).

This is a conditional property of an optimizer. It does not establish attainment or identify which member of the constant-curvature zero set encloses the most area. Gauss-Bonnet does not change the first variation. For an orientable selected region \(D\),

\[
\int_{\partial D}\kappa_g\,ds+\int_DK\,dA=2\pi\chi(D).
\]

The complete identity has zero variation; its boundary and bulk variations cancel. Gaussian curvature enters the second variation and the global classification, not the first-order constant-curvature condition.

Near a regular nondegenerate local maximizer, the repaired fixed-coordinate normal-graph argument also gives the local estimate

\[
0\leq A(\gamma_*)-A(\gamma)\leq C J[\gamma].
\]

The estimate is local to the selected maximizer. It cannot be changed to a global deficit from the area supremum without additional information.

## 3 Computational framework

The baseline implementation represents closed boundaries by truncated Fourier series and evaluates metric length, selected area, geodesic curvature, Gaussian curvature, and \(J\) intrinsically. Constrained optimization uses SLSQP for fixed-length area maximization. Surface-specific tests use exact radial or boundary primitives whenever available. The Klein-bottle experiment uses the dual formulation, minimizing boundary length at fixed selected area, because representative area values expose the topology change directly.

Every admitted numerical optimizer must pass the relevant subset of the following checks:

1. optimizer convergence;
2. the prescribed length or area constraint;
3. the correct turning number or quotient topology;
4. embeddedness at certification resolution;
5. topology-aware Gauss-Bonnet closure;
6. agreement with an independent area calculation when applicable;
7. sufficient Gaussian-curvature variation for a powered test;
8. constant-geodesic-curvature and small-\(J\) diagnostics;
9. stability under increased Fourier order or point resolution.

The principal surface suite contains 44 passing unit tests. Four additional ring-torus geometry tests pass. The full ring-torus relaxation and the hardened baseline verifier also pass. In the quick conformal survey, one powered case is confirmed and one randomized metric is correctly reported as optimizer-inconclusive; no conclusion is drawn from the latter.

## 4 Baseline conformal metrics

The hardened verifier first checks the Euclidean circle and a spherical cap against closed-form answers. It then optimizes a length-six curve in an asymmetric two-bump conformal metric

\[
g=e^{2u(x,y)}(dx^2+dy^2),
\]

where \(u\) is a sum of positive and negative Gaussian bumps. The optimized curve samples a Gaussian-curvature spread of \(0.677905\) and weighted standard deviation \(0.163072\). Its arclength-weighted relative curvature variation is \(3.36\times10^{-5}\), and

\[
J=1.219\times10^{-6}.
\]

The earlier phantom relation \(\kappa_g=\lambda-\mu K\), with \(\mu=0.92\), predicts \(J_B=1.167\). The measured value is approximately \(9.57\times10^5\) times smaller, while the weighted fitted slope of \(\kappa_g\) against \(K\) is numerically zero. This experiment does not prove Theorem 1; it demonstrates that substantial variation of ambient \(K\) is compatible with nearly constant boundary \(\kappa_g\).

## 5 Compact orientable surfaces

### 5.1 The ring torus

For the standard ring torus with major radius \(R=3\) and minor radius \(r=1\),

\[
ds^2=d\theta^2+(3+\cos\theta)^2d\phi^2,
\qquad
K(\theta)=\frac{\cos\theta}{3+\cos\theta}.
\]

A multistart Fourier relaxation at boundary length \(L=4\) converges to a contractible curve centered at \(\theta=1.16\times10^{-4}\), essentially the outer equator where \(K\) is maximal. At the refined resolution of six modes and 1,536 points,

\[
A=1.3063003657,
\quad
\overline{\kappa_g}=1.4923589122,
\quad
\frac{\operatorname{std}_s(\kappa_g)}{|\overline{\kappa_g}|}=4.30\times10^{-6},
\]

and \(J L^3=1.68\times10^{-6}\). The Gaussian-curvature range along the curve is \([0.210055,0.250000]\), Gauss-Bonnet closes to displayed precision, and the relative area change on refinement is \(2.12\times10^{-10}\). This is strong restricted-class evidence, not a classification of all isoperimetric regions on the torus.

### 5.2 The flat torus

The rectangular flat torus has area \(24\). A contractible length-four circle has area

\[
\frac{L^2}{4\pi}=\frac{4}{\pi}=1.2732395447,
\]

while the same geometric boundary, with the opposite selected side, has area \(24-4/\pi=22.7267604553\). Both have \(J=0\), but their selected regions have Euler characteristics \(1\) and \(-1\).

Two parallel geodesics form annular bands. At total boundary length \(8\), the tested widths \(1,3,5\) give areas \(4,12,20\), all with \(J=0\). A single essential geodesic has \(J=0\) but is not the boundary of a region. The flat torus therefore shows that the boundary curve alone is an incomplete state description. The selected side, homology, Euler characteristic, and number of boundary components are part of the problem data.

## 6 The flat Klein bottle

Let the orientation double cover be the flat torus \(\mathbb R^2/(4\mathbb Z\times6\mathbb Z)\), and quotient by

\[
\tau(x,y)=(x+2,6-y).
\]

The cover has area \(24\), and the Klein bottle has area \(12\). A one-sided core geodesic has no globally consistent selected side and cannot serve alone as a region boundary. A two-sided separating geodesic lifts to two curves and cuts the bottle into two Möbius bands.

We relaxed seven selected areas from deterministic perturbations, comparing two topology-preserving classes: a contractible disk or disk complement, and a two-sided Möbius separator. With

\[
m=\min(A,12-A),
\]

the two measured perimeter branches are

\[
L_{\rm disk}=2\sqrt{\pi m},
\qquad
L_{\rm sep}=4.
\]

They cross at

\[
m=\frac{4}{\pi}=1.2732395447.
\]

Small areas and their large-area complements select circles within the two tested classes; intermediate areas select the Möbius separator. Runs at 2,048 and 4,096 points select the same branch at every area, with a maximum relaxed-perimeter difference below \(2.4\times10^{-14}\).

The stronger observation does not depend on the relaxation. Constant-height lifts project to a continuous family of two-sided separating geodesics. Moving the height changes the selected Möbius-band area through every value in \((0,12)\), while

\[
L=4,
\qquad
\kappa_g=0,
\qquad
J=0.
\]

Thus even the pair \((L,J)\) fails to determine selected area. As the area tends to zero or twelve, the two-sided boundary degenerates to a one-sided core; the endpoints are not admissible region boundaries. This is a compact topological failure of closure in the chosen boundary class.

## 7 Noncompact surfaces

### 7.1 The hyperbolic cusp

The standard cusp is \([0,\infty)\times S^1\) with

\[
g=dr^2+e^{-2r}d\theta^2,
\qquad K=-1.
\]

The selected region is the noncompact tail beyond a radial graph. It has finite area and Euler characteristic zero. Relaxations at lengths \(0.5,1,2\) recover horocycles with

\[
A=L,
\qquad
\kappa_g=1,
\qquad
J=0
\]

to numerical accuracy. The measured \(J\) values range from \(7.76\times10^{-12}\) to \(1.88\times10^{-10}\), and Gauss-Bonnet closes as

\[
\int_{\partial D}\kappa_g\,ds+\int_DK\,dA=0=2\pi\chi(D).
\]

This example shows that a noncompact selected region can remain finite and analytically controlled.

### 7.2 The paraboloid

For the paraboloid \(z=x^2+y^2\),

\[
g=(1+4r^2)dr^2+r^2d\theta^2,
\qquad
K=\frac{4}{(1+4r^2)^2}.
\]

At lengths \(3,6,9\), independent perturbed starts relax to rotational circles. Their areas are \(0.8605832240\), \(4.7225003955\), and \(14.1041320591\). The nonconstant Fourier coefficient norms are of order \(10^{-9}\), relative curvature variations are below \(2.81\times10^{-7}\), and \(J\) is between \(6.04\times10^{-13}\) and \(6.62\times10^{-12}\). No radial escape occurs. Completeness and noncompactness alone therefore do not force loss of an optimizer.

### 7.3 Gabriel's horn

The tail of the capped horn is the surface of revolution \(y=1/x\), \(x\ge1\), with

\[
g=(1+x^{-4})dx^2+x^{-2}d\theta^2.
\]

We impose exact length \(L=6\) on graphs

\[
x(\theta)=X+A_X\cos\theta
\]

at \(X=32,64,128,256,512\). The amplitude approaches \(a=L/4=3/2\), with

\[
a-A_X\sim\frac{1}{X^2}
\left[\frac{\log(4aX)}{2a}+\frac{1}{4a}\right].
\]

At \(X=512\), the observed-to-predicted amplitude-deficit ratio is \(1.0000274\). The area satisfies

\[
A(X)-2\pi\log X\longrightarrow
\pi\left[\sqrt{2}-1+\log\frac{2}{1+\sqrt{2}}\right]
=0.7099595888.
\]

The observed offset at \(X=512\) is \(0.7099461067\). Near each turning point, the curvature layer has angular width \(O(X^{-1})\) and height \(O(X^2)\). Its limiting profile gives

\[
\frac{J(X)}{X^6}\longrightarrow
\frac{64}{35}a^3=\frac{216}{35}=6.1714285714.
\]

The observed value at \(X=512\) is \(6.1720918322\), and the last-three fitted exponent is \(5.99879809\). Accurate evaluation requires angular resolution proportional to \(X\). With \(N_{\rm low}=64X\) and \(N_{\rm high}=128X\), the two values of \(J\) agree to approximately \(10^{-13}\), and the deepest Gauss-Bonnet residual is approximately \(2\times10^{-13}\).

The horn therefore has fixed-length curves whose selected areas diverge, so no finite global maximizer exists in the tested escaping family. Its \(J\) diverges rather than vanishes. This separates failure of attainment from small-curvature-variation escape.

### 7.4 Hamilton's cigar

Hamilton's cigar soliton has geodesic polar metric

\[
g=d\rho^2+\tanh^2\rho\,d\theta^2.
\]

Its parallel circumference approaches \(2\pi\) from below, while disk area \(2\pi\log\cosh\rho\) diverges. Exact-length graphs

\[
\rho(\theta)=X+A_X\cos\theta,
\qquad L=2\pi,
\]

were evaluated at \(X=4,5,6,7,8\). Expansion of the length constraint gives

\[
A_X\sim2\sqrt{2}e^{-X}.
\]

The selected area and curvature variation satisfy

\[
\mathcal{A}_X
=2\pi(X-\log2)+2\pi e^{-2X}+o(e^{-2X}),
\]

\[
J_X\sim8\pi e^{-2X}.
\]

At \(X=8\), the amplitude ratio is \(1.000000366\), the scaled area correction is \(6.283190631\) versus \(2\pi\), and \(e^{2X}J_X=25.132717201\) versus \(8\pi=25.132741229\). The last-three fitted exponents are \(-1.0000098\) for amplitude and \(-1.9999744\) for \(J\).

Consequently,

\[
L_X=2\pi,
\qquad
\mathcal{A}_X\to\infty,
\qquad
J_X\to0.
\]

This is the sharpest noncompact obstruction in the campaign. Small \(J\) does not prevent escape, and it does not imply the existence of a finite global area champion. Unlike the horn, the cigar has no narrowing turning-point layers; a fixed angular resolution is adequate.

## 8 A compact smooth global obstruction

The separate smooth-sphere construction shows that failure of global \(J\)-selection persists even after compactness, orientability, smoothness, and strict local stability are restored. On a surface of revolution

\[
g=dr^2+a(r)^2d\theta^2,
\]

choose two parallels at \(r_1=2\) and \(r_2=6\) with

\[
a(r_i)=1,
\qquad
a'(r_i)=\frac{1}{2},
\qquad
a''(r_i)=0.
\]

Both boundaries have length \(2\pi\), constant geodesic curvature \(1/2\), Gaussian curvature zero on the boundary, and \(J=0\). Their nonconstant Fourier stability eigenvalues are

\[
\lambda_n=n^2-\frac{1}{4}\geq\frac{3}{4}.
\]

Both are regular, nondegenerate, strict local area maxima in the same isotopy class of oriented disks. The selected areas differ by exactly

\[
A(D_2)-A(D_1)=8\pi.
\]

It follows that no global bound

\[
A_{\sup}(L_0)-A(\gamma)\leq C J[\gamma]^\alpha
\]

can hold on every smooth surface for finite \(C\) and positive \(\alpha\). The same example rules out every modulus \(\omega(J)\) with \(\omega(0)=0\). It does not contradict Theorem 1 or the local inequality. It proves that \(J\) cannot choose among separated components of its zero set.

## 9 Synthesis by obstruction

![Normalized numerical fingerprints for Gabriel's horn, Hamilton's cigar, and the flat Klein bottle](output/figures/manifold_numerical_fingerprints.png)

**Figure 1.** Normalized numerical fingerprints. Dashed lines mark derived limits; the Klein panel shows the two relaxed perimeter branches and their lower envelope within the tested classes.

| Surface | Property isolated | Outcome for fixed-length Dido analysis |
|---|---|---|
| Two-bump conformal plane | Variable Gaussian curvature | Relaxed optimizer has nearly constant \(\kappa_g\) and tiny \(J\) |
| Ring torus | Compact variable curvature | Restricted optimizer localizes near maximum \(K\) and has tiny \(J\) |
| Flat torus | Homology and multiple boundaries | Same boundary or perimeter data support different selected areas |
| Flat Klein bottle | Nonorientability and one-sided limits | Continuous \(L=4\), \(J=0\), varying-area family |
| Hyperbolic cusp | Noncompact finite-area region | Horocycles give \(A=L\), \(\kappa_g=1\), \(J=0\) |
| Paraboloid | Noncompact positive control | Relaxation remains localized and recovers circles |
| Gabriel's horn | Collapsing end and infinite area | Area diverges and \(J\sim(216/35)X^6\) |
| Hamilton's cigar | Cylindrical end and infinite area | Area diverges while \(J\sim8\pi e^{-2X}\to0\) |
| Smooth peanut sphere | Multiple stable zero-energy candidates | Equal length and \(J=0\), but area gap \(8\pi\) |

Three distinct mechanisms must therefore be separated. First, the positive theorem says what every attained smooth optimizer must satisfy. Second, compactness and topology determine whether an admissible optimizer or limit exists. Third, global area comparison among constant-curvature candidates requires information absent from \(J\).

The numerical constants are diagnostic fingerprints of those mechanisms. The horn's \(216/35\) comes from a resolved curvature-layer integral. The cigar's \(8\pi\) comes from its exponentially cylindrical end. The Klein bottle's \(4/\pi\) is the perimeter crossover between a Euclidean disk and a two-sided separator. The peanut sphere's \(8\pi\) is an exact area separation between stable zero-energy candidates. Recovering these values across independent resolutions is stronger evidence of correct implementation than optimizer success alone.

## 10 Conclusions

The least-variation conjecture is valid in its precise attained form: every smooth fixed-length area maximizer has \(J=0\). The computations consistently reproduce that necessary condition whenever a controlled optimizer is recovered. They also identify the exact boundary of the method.

Small \(J\) is a local geometric regularity signal. Near a regular nondegenerate maximizer it controls the local area deficit. Globally, it neither guarantees attainment nor selects the largest enclosure. Hamilton's cigar permits area to diverge while \(J\to0\). The Klein bottle permits a continuum of selected areas with identical \((L,J)\). The smooth sphere permits two strictly stable local maxima with identical \((L,J)\) and different areas.

A viable global theory must therefore specify the selected region, preserve topological type, prevent escape and length loss, control degeneration toward one-sided or multiply covered boundaries, and compare areas across the full constant-curvature zero set. Those are separate geometric tasks. They are not consequences of minimizing curvature variation.

## Authorship and responsibility

This manuscript intentionally lists an AI system as computational first author and Thomas Schaefer as human advisor and corresponding author. The AI system drafted the synthesis, derived and encoded several asymptotic tests, implemented surface-specific experiments, and assembled the reproducibility record under human direction. Because an AI system cannot assume legal or scholarly accountability, the human corresponding author must verify the final text, approve any submission, disclose the use of AI according to the target venue's policy, and accept responsibility for the published claims.

## Acknowledgments

The original conjecture and research program were proposed by Thomas Schaefer. The work developed through repeated exchanges among multiple frontier AI systems, with mathematical claims treated as proposals until checked analytically or by independent numerical gates. The false curvature relation that motivated the original investigation, the local coordinate gap, and the distinction between local control and global selection were all exposed through adversarial review. The present paper records the resulting geometry rather than the conversational history.

# Appendix A Definitions and conventions

## A.1 Curvature variation

All curves are at least smooth enough that \(\kappa_g'\in L^2(ds)\). For a connected boundary,

\[
J=\int(\kappa_g')^2ds\geq0.
\]

For multiple boundary components, \(J\) is summed over components. The sign of \(\kappa_g\) changes with orientation, but \(J\) does not.

## A.2 Selected regions

A boundary curve is never interpreted without a selected region. On a compact orientable surface, one separating curve usually has two complementary choices. On the Klein bottle, one-sided curves do not bound a selected region. On the cusp, the selected side is the noncompact finite-area tail. Gauss-Bonnet always uses the Euler characteristic of the selected region.

## A.3 Evidence labels

**Exact** denotes a mathematical identity or direct construction. **Analytic asymptotic** denotes a derived limiting formula. **Numerical** denotes a finite-dimensional, finite-resolution calculation. Optimizer failure is labeled inconclusive rather than false.

# Appendix B Surface formulas

## B.1 Ring torus

\[
g=r^2d\theta^2+(R+r\cos\theta)^2d\phi^2,
\qquad
K=\frac{\cos\theta}{r(R+r\cos\theta)}.
\]

The area and bulk-curvature boundary primitives used in the code are

\[
A(D)=\int(rR\theta+r^2\sin\theta)d\phi,
\qquad
\int_DK\,dA=\int\sin\theta\,d\phi.
\]

## B.2 Flat quotient surfaces

The flat torus is \(\mathbb R^2/(w\mathbb Z\times h\mathbb Z)\). The Klein bottle is obtained from its orientation cover by the free involution

\[
\tau(x,y)=(x+w/2,h-y).
\]

The covering map is two-to-one and locally isometric, so every measurable base region has half the area of its full lift.

## B.3 Hyperbolic cusp

\[
g=dr^2+e^{-2r}d\theta^2,
\quad
K=-1,
\quad
A_{\rm tail}[r(\theta)]=\int_0^{2\pi}e^{-r(\theta)}d\theta.
\]

## B.4 Paraboloid

\[
g=(1+4r^2)dr^2+r^2d\theta^2,
\quad
K=\frac{4}{(1+4r^2)^2},
\]

with radial area primitive

\[
F(r)=\frac{(1+4r^2)^{3/2}-1}{12}.
\]

## B.5 Gabriel horn

\[
g=(1+x^{-4})dx^2+x^{-2}d\theta^2,
\quad
K=-\frac{2x^6}{(1+x^4)^2}.
\]

The code uses exact primitives for tail area and bulk Gaussian curvature. The compact cap adds fixed constants and does not alter area differences along the tail.

## B.6 Hamilton cigar

\[
g=d\rho^2+\tanh^2\rho\,d\theta^2,
\quad
K=2\operatorname{sech}^2\rho,
\quad
F(\rho)=\log\cosh\rho.
\]

# Appendix C Numerical algorithms

## C.1 Fourier representations

General contractible loops use sine and cosine coefficients for both coordinates. Radial surfaces use graphs of the form

\[
r(\theta)=c_0+\sum_{n=1}^m(a_n\cos n\theta+b_n\sin n\theta).
\]

Coordinate derivatives are evaluated analytically from coefficients. Periodic derivatives of sampled curvature use FFT differentiation.

## C.2 Optimization

Fixed-length cases maximize selected area with SLSQP and an equality constraint \(L-L_0=0\). The horn and cigar families solve a scalar exact-length equation for cosine amplitude with Brent's method. The Klein bottle minimizes perimeter at exact selected area within disk and separator branches using L-BFGS-B. Multiple deterministic starts are retained, and only candidates passing geometric gates enter comparisons.

## C.3 Quadrature

Periodic integrals use the trapezoidal rule on uniform grids, which is spectrally accurate for resolved smooth periodic data. Conformal-chart area uses a Gauss-Legendre fan quadrature and an independent Monte Carlo ray-casting check. Surface-specific radial primitives avoid mesh ambiguity.

## C.4 Resolution policy

Ordinary smooth Fourier tests use fixed point counts followed by a higher-resolution or higher-mode confirmation. The horn requires adaptive resolution because the turning layers have width \(O(X^{-1})\); its asymptotic experiment uses \(N_{\rm low}=\max(4096,64X)\) and \(N_{\rm high}=2N_{\rm low}\).

# Appendix D Reproduction protocol

## D.1 Environment

Use Python 3.10 or later with NumPy and SciPy. The archived run reported here used Python 3.12. No GPU is required.

```text
python -m venv .venv
.venv/Scripts/python -m pip install --upgrade pip
.venv/Scripts/python -m pip install numpy scipy
```

On Linux or macOS, replace `.venv/Scripts/python` with `.venv/bin/python`.

## D.2 Complete current suite

From the directory containing the files:

```text
python dido_surface_suite.py
python -m unittest discover -v -p "test_dido_*.py"
python dido_torus.py --json dido_ring_torus_report.json
python dido_verifier_v3.py quick
python dido_survey.py quick --json dido_survey_quick_report.json
```

Expected status: all six surface adapters pass; 48 discovered tests pass (44 core tests plus four ring-torus geometry tests); the full ring-torus relaxation passes; and every baseline verifier gate passes. The quick conformal survey reports one powered confirmation and one optimizer-inconclusive case.

## D.3 Asymptotic experiments

```text
python dido_horn_asymptotics.py
python dido_cigar_asymptotics.py
python dido_klein_relaxation.py
```

Expected status: seven horn gates, eight cigar gates, and five Klein-relaxation gates pass.

## D.4 Individual surface reports

```text
python dido_horn.py --json dido_horn_report.json
python dido_cigar.py --json dido_cigar_report.json
python dido_cusp.py --json dido_cusp_report.json
python dido_flat_torus.py --json dido_flat_torus_report.json
python dido_klein_bottle.py --json dido_klein_bottle_report.json
python dido_paraboloid.py --json dido_paraboloid_report.json
python dido_argument_audit.py --json
```

# Appendix E Determinism and acceptance gates

Randomized tests use explicit master seeds. Newer modules derive independent local seeds with SHA-256 tags so outcomes do not depend on Python's process-salted `hash()` or on test execution order. The original verifier's claim of process-independent seeding is not literally correct because its `local_rng()` uses Python's built-in `hash()`. The baseline numerical outcome is stable in the recorded run, but future archival code should replace that function with the SHA-256 method used by the audit and surface modules.

An AI reproducing this work must retain the following rules:

1. Do not count an optimizer result unless the solver reports success and the geometric gates pass.
2. Do not treat a failed or timed-out optimizer as a counterexample.
3. Compute statistics with arclength weights.
4. Use the selected region's Euler characteristic in Gauss-Bonnet.
5. Reject one-sided curves as standalone boundaries.
6. Preserve the selected side, homology class, boundary-component count, and orientability.
7. Confirm the final candidate at higher resolution.
8. Increase horn resolution proportionally to depth.
9. Compare normalized sequences with derived constants, not only fitted exponents.
10. Report the ansatz class; never promote a Fourier-class champion to a global theorem.

# Appendix F Expected numerical fingerprints

| Experiment | Quantity | Expected value or limit |
|---|---|---|
| Baseline flat KAT | circle area at \(L=2\pi\) | \(\pi\) |
| Baseline sphere KAT | constant curvature | \(J\) at numerical floor |
| Ring torus | refined area | 1.3063003657 |
| Flat torus | disk area at \(L=4\) | \(4/\pi\) |
| Klein bottle | disk-separator crossover | \(4/\pi\) |
| Klein bottle | separator family | \(L=4, J=0, A\in(0,12)\) |
| Hyperbolic cusp | horocycle | \(A/L=1,\ \kappa_g=1\) |
| Horn | area slope | \(2\pi\) against \(\log X\) |
| Horn | normalized energy | \(J/X^6\to216/35\) |
| Cigar | amplitude | \(A_Xe^X\to2\sqrt{2}\) |
| Cigar | area correction | \(e^{2X}[\mathcal{A}-2\pi(X-\log2)]\to2\pi\) |
| Cigar | normalized energy | \(e^{2X}J\to8\pi\) |
| Smooth peanut sphere | stable-candidate area gap | \(8\pi\) |

# Appendix G File manifest and provenance

The reproducibility archive contains the paper source, all executable surface modules, tests, JSON reports, a requirements file, a one-command runner, and a SHA-256 manifest. JSON is the authoritative machine-readable record of each run. Console rounding must not replace stored values in comparisons.

An AI should first verify the hashes, create a clean environment, run the unit tests, regenerate reports into a separate directory, and compare semantic JSON fields rather than byte-for-byte solver messages. Platform-specific optimizer messages and final floating-point digits may differ; gate outcomes and normalized limits must remain stable.

# Appendix H Limits and falsification criteria

The study would require revision if any of the following occurs under adequate resolution:

1. a known-answer metric fails its exact geometry or Gauss-Bonnet identity;
2. a claimed optimizer fails embeddedness or topology checks;
3. horn or cigar normalized sequences cease approaching their derived constants;
4. a higher-resolution run changes a selected Klein branch away from a crossover;
5. an admitted variable-curvature optimizer retains nonconstant geodesic curvature above the declared numerical floor;
6. a proposed global theorem survives neither the cigar escape sequence nor the compact smooth-sphere counterexample.

The experiments can be extended to other metrics, but additional surfaces should be chosen to isolate a hypothesis rather than enlarge a list. Every extension should begin with exact primitives or known-answer identities, then add relaxation, resolution doubling, and an explicit statement of what the computation cannot prove.

# References

1. N. Fusco, F. Maggi, and A. Pratelli, “The sharp quantitative isoperimetric inequality,” *Annals of Mathematics* 168 (2008), 941-980.
2. J. Langer and D. A. Singer, “The total squared curvature of closed curves,” *Journal of Differential Geometry* 20 (1984), 1-22.
3. F. Morgan, M. Hutchings, and H. Howards, “The isoperimetric problem on surfaces of revolution of decreasing Gauss curvature,” *Transactions of the American Mathematical Society* 352 (2000), 4889-4909.
4. H. P. Moreton, *Minimum Variation Curves and Surfaces for Computer-Aided Geometric Design*, Ph.D. thesis, University of California, Berkeley, 1992.
5. H. P. Moreton and C. H. Séquin, “Functional optimization for fair surface design,” *Computer Graphics* 26 (1992), 167-176.
6. R. Osserman, “Bonnesen-style isoperimetric inequalities,” *American Mathematical Monthly* 86 (1979), 1-29.
7. M. Ritoré, “Constant geodesic curvature curves and isoperimetric domains in rotationally symmetric surfaces,” *Communications in Analysis and Geometry* 9 (2001), 1093-1138.
8. M. Ritoré, “The isoperimetric problem in complete surfaces of nonnegative curvature,” *Journal of Geometric Analysis* 11 (2001), 509-517.
9. M. Ritoré and A. Ros, “Some updates on isoperimetric problems,” *Mathematical Intelligencer* 24 (2002), 9-14.
10. A. Ros, “The isoperimetric problem,” in *Global Theory of Minimal Surfaces*, Clay Mathematics Proceedings 2, American Mathematical Society, 2005, 175-209.
11. L. Simon, “Asymptotics for a class of nonlinear evolution equations, with applications to geometric problems,” *Annals of Mathematics* 118 (1983), 525-571.
12. R. Ye, “Foliation by constant mean curvature spheres,” *Pacific Journal of Mathematics* 147 (1991), 381-396.

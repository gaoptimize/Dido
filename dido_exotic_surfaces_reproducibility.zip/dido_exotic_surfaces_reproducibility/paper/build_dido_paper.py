"""Build the editable Word manuscript from its Markdown source."""

from __future__ import annotations

import re
from pathlib import Path

import matplotlib.pyplot as plt
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "dido_exotic_manifolds_paper.md"
OUT = ROOT / "output" / "paper"
EQ_DIR = ROOT / "tmp" / "paper_equations"
DOCX = OUT / "dido_relaxation_exotic_surfaces.docx"


def set_run_font(run, name: str, size: float | None = None,
                 bold: bool | None = None, italic: bool | None = None,
                 color: str | None = None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)


def shade_cell(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=90, start=100, bottom=90, end=100):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start),
                          ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = borders.find(qn(f"w:{edge}"))
        if tag is None:
            tag = OxmlElement(f"w:{edge}")
            borders.append(tag)
        tag.set(qn("w:val"), "single")
        tag.set(qn("w:sz"), "4")
        tag.set(qn("w:color"), "D9D9D9")


MATH_REPLACEMENTS = {
    r"\gamma": "γ", r"\kappa": "κ", r"\pi": "π", r"\theta": "θ",
    r"\rho": "ρ", r"\varphi": "φ", r"\lambda": "λ", r"\alpha": "α",
    r"\chi": "χ", r"\Delta": "Δ", r"\infty": "∞", r"\ge": "≥",
    r"\leq": "≤", r"\geq": "≥", r"\le": "≤", r"\to": "→",
    r"\longrightarrow": "→", r"\sim": "~", r"\times": "×",
    r"\sqrt": "√", r"\int": "∫", r"\partial": "∂",
    r"\operatorname": "", r"\mathcal": "", r"\mathbb": "",
    r"\overline": "", r"\rm": "", r"\qquad": "   ", r"\quad": "  ",
    r"\,": "", r"\!": "", r"\left": "", r"\right": "",
}


def plain_math(value: str) -> str:
    text = value.strip()
    for old, new in MATH_REPLACEMENTS.items():
        text = text.replace(old, new)
    for _ in range(3):
        text = re.sub(r"\\frac\{([^{}]+)\}\{([^{}]+)\}", r"(\1)/(\2)", text)
    text = re.sub(r"_\{([^{}]+)\}", r"_\1", text)
    text = re.sub(r"\^\{([^{}]+)\}", r"^\1", text)
    text = text.replace("{", "").replace("}", "")
    return text


def add_rich(paragraph, text: str, size: float = 10.5):
    pattern = re.compile(r"(\*\*.*?\*\*|`.*?`|\\\(.*?\\\)|\*[^*]+?\*)")
    position = 0
    for match in pattern.finditer(text):
        if match.start() > position:
            set_run_font(paragraph.add_run(text[position:match.start()]),
                         "Liberation Serif", size)
        token = match.group(0)
        if token.startswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, "Liberation Serif", size, bold=True)
        elif token.startswith("`"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, "Liberation Mono", size - 0.5)
        elif token.startswith(r"\("):
            run = paragraph.add_run(plain_math(token[2:-2]))
            set_run_font(run, "Cambria Math", size, italic=True)
        else:
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, "Liberation Serif", size, italic=True)
        position = match.end()
    if position < len(text):
        set_run_font(paragraph.add_run(text[position:]), "Liberation Serif", size)


def equation_image(latex: str, index: int) -> Path:
    EQ_DIR.mkdir(parents=True, exist_ok=True)
    path = EQ_DIR / f"eq_{index:03d}.png"
    width = min(8.0, max(2.4, 0.065 * len(latex) + 1.2))
    fig = plt.figure(figsize=(width, 0.52), dpi=240)
    fig.patch.set_alpha(0)
    fig.text(0.5, 0.5, f"${latex}$", ha="center", va="center",
             fontsize=12, color="black")
    fig.savefig(path, dpi=240, bbox_inches="tight", pad_inches=0.04,
                transparent=True)
    plt.close(fig)
    return path


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char1, instr, fld_char2])
    set_run_font(run, "Liberation Serif", 9)


def configure(document: Document):
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.72)
    section.bottom_margin = Inches(0.72)
    section.left_margin = Inches(0.82)
    section.right_margin = Inches(0.82)

    normal = document.styles["Normal"]
    normal.font.name = "Liberation Serif"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Liberation Serif")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Liberation Serif")
    normal.font.size = Pt(10.5)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.08

    title = document.styles["Title"]
    title.font.name = "Liberation Sans"
    title._element.rPr.rFonts.set(qn("w:ascii"), "Liberation Sans")
    title._element.rPr.rFonts.set(qn("w:hAnsi"), "Liberation Sans")
    title.font.size = Pt(22)
    title.font.bold = True
    title.font.color.rgb = RGBColor(0, 0, 0)
    # Some Word/LibreOffice themes put an ornamental rule under Title.
    # This manuscript uses spacing only, so remove any inherited paragraph border.
    title_ppr = title._element.get_or_add_pPr()
    title_border = title_ppr.find(qn("w:pBdr"))
    if title_border is not None:
        title_ppr.remove(title_border)

    for name, size in (("Heading 1", 15), ("Heading 2", 12.5),
                       ("Heading 3", 11.5)):
        style = document.styles[name]
        style.font.name = "Liberation Sans"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Liberation Sans")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Liberation Sans")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.space_before = Pt(12 if name == "Heading 1" else 8)
        style.paragraph_format.space_after = Pt(5)
        style.paragraph_format.keep_with_next = True

    if "Equation" not in document.styles:
        eq = document.styles.add_style("Equation", WD_STYLE_TYPE.PARAGRAPH)
        eq.paragraph_format.space_before = Pt(3)
        eq.paragraph_format.space_after = Pt(5)
        eq.paragraph_format.keep_together = True

    footer = section.footer.paragraphs[0]
    add_page_number(footer)


def add_table(document: Document, lines: list[str]):
    rows = []
    for line in lines:
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if all(re.fullmatch(r":?-+:?", cell.replace(" ", "")) for cell in cells):
            continue
        rows.append(cells)
    if not rows:
        return
    cols = max(len(row) for row in rows)
    table = document.add_table(rows=len(rows), cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    set_table_borders(table)
    table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
    for r_idx, row in enumerate(rows):
        for c_idx in range(cols):
            cell = table.cell(r_idx, c_idx)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            text = row[c_idx] if c_idx < len(row) else ""
            paragraph = cell.paragraphs[0]
            paragraph.paragraph_format.space_after = Pt(0)
            paragraph.alignment = (WD_ALIGN_PARAGRAPH.CENTER
                                   if c_idx == 0 or cols <= 3
                                   else WD_ALIGN_PARAGRAPH.LEFT)
            add_rich(paragraph, text, size=8.3 if cols >= 3 else 9)
            if r_idx == 0:
                shade_cell(cell, "1F4E78")
                for run in paragraph.runs:
                    run.bold = True
                    run.font.color.rgb = RGBColor(255, 255, 255)
            elif r_idx % 2 == 0:
                shade_cell(cell, "EEF4F8")
    after = document.add_paragraph()
    after.paragraph_format.space_after = Pt(1)


def build() -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    document = Document()
    configure(document)

    title = document.add_paragraph(style="Title")
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(14)
    title.add_run("Dido Relaxation Across Classical Exotic Surfaces")

    author = document.add_paragraph()
    author.alignment = WD_ALIGN_PARAGRAPH.CENTER
    author.paragraph_format.space_after = Pt(2)
    add_rich(author, "**GPT, OpenAI**  Computational first author", 10.5)
    advisor = document.add_paragraph()
    advisor.alignment = WD_ALIGN_PARAGRAPH.CENTER
    advisor.paragraph_format.space_after = Pt(2)
    add_rich(advisor, "**Thomas Schaefer**  Human advisor and corresponding author", 10.5)
    affiliation = document.add_paragraph()
    affiliation.alignment = WD_ALIGN_PARAGRAPH.CENTER
    affiliation.paragraph_format.space_after = Pt(2)
    add_rich(affiliation, "6 Now Possible Things, Independent Researcher", 10)
    date = document.add_paragraph()
    date.alignment = WD_ALIGN_PARAGRAPH.CENTER
    date.paragraph_format.space_after = Pt(14)
    add_rich(date, "9 September 2026", 10)

    # Skip source front matter through the Abstract heading.
    start = lines.index("## Abstract")
    lines = lines[start:]
    i = 0
    equation_index = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line:
            i += 1
            continue
        if line.startswith("# Appendix") or line == "# References":
            document.add_page_break()
            paragraph = document.add_paragraph(line[2:], style="Heading 1")
            paragraph.paragraph_format.keep_with_next = True
            i += 1
            continue
        if line.startswith("## "):
            document.add_paragraph(line[3:], style="Heading 1")
            i += 1
            continue
        if line.startswith("### "):
            document.add_paragraph(line[4:], style="Heading 2")
            i += 1
            continue
        if line.startswith("#### "):
            document.add_paragraph(line[5:], style="Heading 3")
            i += 1
            continue
        if line == r"\[":
            equation = []
            i += 1
            while i < len(lines) and lines[i].strip() != r"\]":
                equation.append(lines[i].strip())
                i += 1
            latex = " ".join(equation)
            equation_index += 1
            try:
                path = equation_image(latex, equation_index)
                paragraph = document.add_paragraph(style="Equation")
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                paragraph.add_run().add_picture(str(path), width=Inches(
                    min(6.6, max(1.8, 0.055 * len(latex) + 0.8))))
            except Exception:
                paragraph = document.add_paragraph(style="Equation")
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                run = paragraph.add_run(plain_math(latex))
                set_run_font(run, "Cambria Math", 10.5, italic=True)
            i += 1
            continue
        if line.startswith("!["):
            match = re.match(r"!\[(.*?)\]\((.*?)\)", line)
            if match:
                image_path = ROOT / match.group(2)
                paragraph = document.add_paragraph()
                paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                paragraph.paragraph_format.keep_with_next = True
                run = paragraph.add_run()
                run.add_picture(str(image_path), width=Inches(6.65))
            i += 1
            continue
        if line.startswith("|"):
            table_lines = []
            while i < len(lines) and lines[i].lstrip().startswith("|"):
                table_lines.append(lines[i])
                i += 1
            add_table(document, table_lines)
            continue
        if re.match(r"^\d+\. ", line):
            paragraph = document.add_paragraph(style="List Number")
            add_rich(paragraph, re.sub(r"^\d+\. ", "", line))
            i += 1
            continue
        if line.startswith("```"):
            i += 1
            code_lines = []
            while i < len(lines) and not lines[i].startswith("```"):
                code_lines.append(lines[i])
                i += 1
            paragraph = document.add_paragraph()
            paragraph.paragraph_format.left_indent = Inches(0.25)
            paragraph.paragraph_format.space_before = Pt(3)
            paragraph.paragraph_format.space_after = Pt(6)
            run = paragraph.add_run("\n".join(code_lines))
            set_run_font(run, "Liberation Mono", 8.5)
            i += 1
            continue

        # Join consecutive prose lines into one paragraph.
        prose = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not (
            lines[i].startswith("#") or lines[i].startswith("|")
            or lines[i].startswith("![") or lines[i].strip() == r"\["
            or lines[i].startswith("```") or re.match(r"^\d+\. ", lines[i])
        ):
            prose.append(lines[i].strip())
            i += 1
        paragraph = document.add_paragraph()
        if prose[0].startswith("**Figure"):
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.keep_with_next = True
            paragraph.paragraph_format.space_after = Pt(7)
        add_rich(paragraph, " ".join(prose))

    properties = document.core_properties
    properties.title = "Dido Relaxation Across Classical Exotic Surfaces"
    properties.subject = "Curvature variation and Dido optimization"
    properties.author = "GPT, OpenAI; Thomas Schaefer"
    properties.keywords = "Dido problem, geodesic curvature, Klein bottle, Gabriel horn, Hamilton cigar"
    document.save(DOCX)
    return DOCX


if __name__ == "__main__":
    print(build())

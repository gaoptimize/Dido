import math
import unittest

import dido_cigar_asymptotics as asym


class CigarAsymptoticsTests(unittest.TestCase):
    def test_known_coefficients(self):
        self.assertAlmostEqual(asym.AMPLITUDE_COEFFICIENT, 2.0 * math.sqrt(2.0))
        self.assertAlmostEqual(asym.AREA_CORRECTION_COEFFICIENT, 2.0 * math.pi)
        self.assertAlmostEqual(asym.J_COEFFICIENT, 8.0 * math.pi)

    def test_requires_ordered_three_point_sequence(self):
        with self.assertRaises(ValueError):
            asym.run_study((4.0, 5.0), points=512)
        with self.assertRaises(ValueError):
            asym.run_study((4.0, 6.0, 5.0), points=512)

    def test_five_point_study(self):
        report = asym.run_study(points=2048)
        self.assertTrue(report["all_gates_pass"], report["gates"])
        self.assertEqual(len(report["rows"]), 5)


if __name__ == "__main__":
    unittest.main()

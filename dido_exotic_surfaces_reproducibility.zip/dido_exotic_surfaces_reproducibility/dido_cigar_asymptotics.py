"""Five-point asymptotic regression study for Hamilton's cigar.

The tested curves are the exact-length radial cosine graphs implemented in
``dido_cigar.py``.  For target length 2*pi and center X -> infinity,

    amplitude        ~ 2*sqrt(2)*exp(-X),
    area             ~ 2*pi*(X-log(2)) + 2*pi*exp(-2X),
    jerk energy J    ~ 8*pi*exp(-2X).

The program uses two resolutions at every point and writes a JSON report.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np

import dido_cigar as cigar


TAU = 2.0 * math.pi
AMPLITUDE_COEFFICIENT = 2.0 * math.sqrt(2.0)
AREA_CORRECTION_COEFFICIENT = TAU
J_COEFFICIENT = 8.0 * math.pi


def run_study(
    centers: tuple[float, ...] = (4.0, 5.0, 6.0, 7.0, 8.0),
    points: int = 4096,
) -> dict[str, object]:
    if len(centers) < 3:
        raise ValueError("at least three centers are required")
    if any(right <= left for left, right in zip(centers, centers[1:])):
        raise ValueError("centers must be strictly increasing")

    metric = cigar.CigarMetric()
    rows: list[dict[str, float]] = []
    for center in centers:
        low_graph = cigar.solve_exact_length(metric, center, TAU, points)
        high_graph = cigar.solve_exact_length(metric, center, TAU, 2 * points)
        low = cigar.diagnostics(metric, low_graph, TAU)
        high = cigar.diagnostics(metric, high_graph, TAU)

        amplitude = float(high["amplitude"])
        area = float(high["area"])
        jerk = float(high["J"])
        exp_minus_x = math.exp(-center)
        exp_two_x = math.exp(2.0 * center)
        area_leading = TAU * (center - math.log(2.0))
        area_correction = area - area_leading
        low_jerk = float(low["J"])

        rows.append({
            "center": center,
            "points_low": points,
            "points_high": 2 * points,
            "amplitude": amplitude,
            "amplitude_ratio": amplitude
            / (AMPLITUDE_COEFFICIENT * exp_minus_x),
            "area": area,
            "area_minus_leading": area_correction,
            "scaled_area_correction": exp_two_x * area_correction,
            "J": jerk,
            "scaled_J": exp_two_x * jerk,
            "length_relative_error": float(high["length_relative_error"]),
            "gauss_bonnet_residual": float(high["gauss_bonnet_residual"]),
            "area_resolution_difference": abs(area - float(low["area"])),
            "J_resolution_relative_difference": abs(jerk - low_jerk)
            / max(abs(jerk), 1.0e-300),
        })

    x = np.asarray(centers, dtype=float)
    tail = slice(-3, None)
    log_amplitude = np.log([row["amplitude"] for row in rows])
    log_jerk = np.log([row["J"] for row in rows])
    area_values = np.asarray([row["area"] for row in rows])
    amplitude_exponent = float(np.polyfit(x[tail], log_amplitude[tail], 1)[0])
    jerk_exponent = float(np.polyfit(x[tail], log_jerk[tail], 1)[0])
    area_slope = float(np.polyfit(x[tail], area_values[tail], 1)[0])

    last = rows[-1]
    gates = {
        "H0_EXACT_LENGTH": all(row["length_relative_error"] < 2.0e-12
                               for row in rows),
        "H1_TWO_RESOLUTION": all(
            row["area_resolution_difference"] < 1.0e-11
            and row["J_resolution_relative_difference"] < 1.0e-8
            for row in rows
        ),
        "H2_GAUSS_BONNET": all(abs(row["gauss_bonnet_residual"]) < 1.0e-11
                                for row in rows),
        "H3_AMPLITUDE_LIMIT": abs(last["amplitude_ratio"] - 1.0) < 1.0e-5,
        "H4_AREA_CORRECTION_LIMIT": abs(
            last["scaled_area_correction"] / AREA_CORRECTION_COEFFICIENT - 1.0
        ) < 2.0e-6,
        "H5_J_LIMIT": abs(last["scaled_J"] / J_COEFFICIENT - 1.0) < 2.0e-6,
        "H6_EXPONENTS": abs(amplitude_exponent + 1.0) < 1.0e-4
        and abs(jerk_exponent + 2.0) < 1.0e-4,
        "H7_AREA_SLOPE": abs(area_slope - TAU) / TAU < 1.0e-5,
    }

    return {
        "program": "dido_cigar_asymptotics.py",
        "surface": "Hamilton cigar soliton",
        "target_length": TAU,
        "centers": list(centers),
        "asymptotic_predictions": {
            "amplitude": "2*sqrt(2)*exp(-X)",
            "area": "2*pi*(X-log(2)) + 2*pi*exp(-2X) + o(exp(-2X))",
            "J": "8*pi*exp(-2X) + o(exp(-2X))",
        },
        "known_limits": {
            "amplitude_ratio": 1.0,
            "scaled_area_correction": AREA_CORRECTION_COEFFICIENT,
            "scaled_J": J_COEFFICIENT,
            "amplitude_exponent": -1.0,
            "J_exponent": -2.0,
            "area_slope": TAU,
        },
        "rows": rows,
        "tail_fits": {
            "amplitude_exponent": amplitude_exponent,
            "J_exponent": jerk_exponent,
            "area_slope": area_slope,
        },
        "gates": gates,
        "all_gates_pass": all(gates.values()),
        "interpretation": (
            "At fixed length 2*pi, the curves escape to infinity, area diverges "
            "linearly, and J tends exponentially to zero."
        ),
    }


def print_report(report: dict[str, object]) -> None:
    print("=" * 132)
    print("HAMILTON CIGAR ASYMPTOTICS  L=2*pi")
    print("=" * 132)
    print(f"{'X':>5} {'N(high)':>9} {'A':>13} {'A/limit':>11} "
          f"{'area corr.':>13} {'scaled corr.':>13} {'J':>13} {'scaled J':>13}")
    for row in report["rows"]:
        print(
            f"{row['center']:5.1f} {row['points_high']:9d} "
            f"{row['amplitude']:13.6e} {row['amplitude_ratio']:11.8f} "
            f"{row['area_minus_leading']:13.6e} "
            f"{row['scaled_area_correction']:13.9f} "
            f"{row['J']:13.6e} {row['scaled_J']:13.9f}"
        )
    fits = report["tail_fits"]
    print(f"last-three amplitude exponent = {fits['amplitude_exponent']:.12f} (limit -1)")
    print(f"last-three J exponent         = {fits['J_exponent']:.12f} (limit -2)")
    print(f"last-three area slope         = {fits['area_slope']:.12f} "
          f"(limit 2*pi={TAU:.12f})")
    for name, passed in report["gates"].items():
        print(f"[{'PASS' if passed else 'FAIL'}] {name}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--centers", type=float, nargs="+",
                        default=[4.0, 5.0, 6.0, 7.0, 8.0])
    parser.add_argument("--points", type=int, default=4096)
    parser.add_argument("--json", type=Path,
                        default=Path("dido_cigar_asymptotics_report.json"))
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_study(tuple(args.centers), args.points)
    print_report(report)
    args.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {args.json}")
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

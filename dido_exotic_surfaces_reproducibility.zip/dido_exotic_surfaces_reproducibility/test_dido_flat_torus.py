import math
import unittest

import dido_flat_torus as flat


class FlatTorusTests(unittest.TestCase):
    def setUp(self):
        self.torus = flat.FlatTorus(4.0, 6.0)

    def test_disk_chart_known_answer(self):
        sample = flat.contractible_circle_samples(4.0, 2048)
        self.assertAlmostEqual(sample["length"], 4.0, places=12)
        self.assertAlmostEqual(sample["area"], 4.0 / math.pi, places=12)
        self.assertAlmostEqual(sample["kappa_g"], math.pi / 2.0, places=12)
        self.assertLess(sample["J"], 1.0e-20)

    def test_same_boundary_opposite_selected_sides(self):
        disk, complement = flat.disk_and_complement(self.torus, 4.0)
        self.assertEqual(disk.total_length, complement.total_length)
        self.assertEqual(disk.total_J, complement.total_J)
        self.assertAlmostEqual(float(disk.selected_area)
                               + float(complement.selected_area), 24.0)
        self.assertEqual(disk.euler_characteristic, 1)
        self.assertEqual(complement.euler_characteristic, -1)

    def test_band_family(self):
        bands = [flat.horizontal_band(self.torus, width) for width in (1.0, 3.0, 5.0)]
        self.assertEqual({band.total_length for band in bands}, {8.0})
        self.assertEqual([band.selected_area for band in bands], [4.0, 12.0, 20.0])
        self.assertTrue(all(band.boundary_components == 2 for band in bands))
        self.assertTrue(all(band.total_J == 0.0 for band in bands))

    def test_single_essential_loop_rejected(self):
        candidate = flat.essential_single_loop(self.torus)
        self.assertFalse(candidate.admissible_region)
        self.assertIsNone(candidate.selected_area)

    def test_full_experiment(self):
        report = flat.run_experiment(points=2048)
        self.assertTrue(report["all_gates_pass"], report["gates"])


if __name__ == "__main__":
    unittest.main()

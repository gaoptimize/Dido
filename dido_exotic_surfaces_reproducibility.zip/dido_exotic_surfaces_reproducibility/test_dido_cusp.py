import math
import unittest

import numpy as np

import dido_cusp as cusp


class HyperbolicCuspTests(unittest.TestCase):
    def test_horocycle_known_answers(self):
        loop = cusp.CuspLoop(4, 1024)
        for length in (0.5, 1.0, 2.0):
            radius = math.log(2.0 * math.pi / length)
            coefficients = loop.circle(radius)
            metrics = cusp.diagnostics(loop, coefficients, length)
            self.assertAlmostEqual(metrics["length"], length, places=12)
            self.assertAlmostEqual(metrics["tail_area"], length, places=12)
            self.assertAlmostEqual(metrics["kappa_g_mean"], 1.0, places=12)
            self.assertLess(metrics["kappa_g_wstd"], 1.0e-14)
            self.assertLess(metrics["J"], 1.0e-20)
            self.assertLess(abs(metrics["gauss_bonnet_residual_chi0"]), 1.0e-12)

    def test_nonconstant_graph_gauss_bonnet_chi_zero(self):
        loop = cusp.CuspLoop(3, 2048)
        coefficients = loop.circle(2.0)
        coefficients[1] = 0.08
        coefficients[2] = -0.03
        self.assertLess(abs(cusp.gauss_bonnet_residual(loop, coefficients)), 1.0e-11)

    def test_optimizer_recovers_horocycle(self):
        case = cusp.run_case(1.0, modes=4, points=512, starts=3, seed=20260909)
        self.assertEqual(case["status"], "pass", case)

    def test_full_experiment(self):
        report = cusp.run_experiment(modes=4, points=512, starts=3)
        self.assertTrue(report["all_gates_pass"], report)


if __name__ == "__main__":
    unittest.main()

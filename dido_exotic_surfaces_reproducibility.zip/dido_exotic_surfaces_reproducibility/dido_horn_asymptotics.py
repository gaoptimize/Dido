"""Five-point asymptotic convergence study for the capped Gabriel horn.

For exact-length cosine graphs x(theta)=X+A_X cos(theta), this script tests
three derived tail asymptotics and the resolution law for the turning-point
curvature layers.  It imports the independently tested geometry in
``dido_horn.py``.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np

import dido_horn as horn


def predicted_amplitude_deficit(center: float, target_length: float) -> float:
    """Leading elliptic-integral expansion for L/4-A_X."""
    amplitude_limit = target_length / 4.0
    return (
        math.log(4.0 * amplitude_limit * center) / (2.0 * amplitude_limit)
        + 1.0 / (4.0 * amplitude_limit)
    ) / center**2


def area_offset_limit() -> float:
    """Limit of enclosed tail area minus 2*pi*log(X)."""
    primitive_constant = (
        0.5 * (math.sqrt(2.0) - 1.0)
        + 0.5 * math.log(2.0 / (1.0 + math.sqrt(2.0)))
    )
    return 2.0 * math.pi * primitive_constant


def j_coefficient_limit(target_length: float) -> float:
    """Boundary-layer limit of J/X^6: (64/35)*(L/4)^3."""
    return (64.0 / 35.0) * (target_length / 4.0) ** 3


def run_study(
    target_length: float = 6.0,
    centers: tuple[float, ...] = (32.0, 64.0, 128.0, 256.0, 512.0),
    samples_per_depth: int = 64,
) -> dict[str, object]:
    metric = horn.HornMetric()
    amp_limit = target_length / 4.0
    area_limit = area_offset_limit()
    j_limit = j_coefficient_limit(target_length)
    rows = []
    for center in centers:
        points = max(4096, int(samples_per_depth * center))
        low_graph = horn.solve_exact_length(metric, center, target_length, points)
        high_graph = horn.solve_exact_length(metric, center, target_length, 2 * points)
        low = horn.diagnostics(metric, low_graph, target_length)
        high = horn.diagnostics(metric, high_graph, target_length)
        deficit = amp_limit - high_graph.amplitude
        deficit_prediction = predicted_amplitude_deficit(center, target_length)
        area_offset = float(high["enclosed_tail_area"]) - 2.0 * math.pi * math.log(center)
        j_scaled = float(high["J"]) / center**6
        rows.append({
            "center": center,
            "low_points": points,
            "high_points": 2 * points,
            "boundary_layer_width_prediction": 1.0 / (amp_limit * center),
            "amplitude": high_graph.amplitude,
            "amplitude_limit": amp_limit,
            "amplitude_deficit": deficit,
            "amplitude_deficit_prediction": deficit_prediction,
            "amplitude_deficit_ratio": deficit / deficit_prediction,
            "area": float(high["enclosed_tail_area"]),
            "area_offset": area_offset,
            "area_offset_limit": area_limit,
            "area_offset_error": area_offset - area_limit,
            "J": float(high["J"]),
            "J_over_X6": j_scaled,
            "J_over_X6_limit": j_limit,
            "J_over_X6_relative_error": (j_scaled - j_limit) / j_limit,
            "gauss_bonnet_residual": float(high["gauss_bonnet_residual"]),
            "J_resolution_relative": abs(float(high["J"]) - float(low["J"]))
                                     / float(high["J"]),
            "area_resolution_absolute": abs(
                float(high["enclosed_tail_area"])
                - float(low["enclosed_tail_area"])
            ),
        })

    last_three = rows[-3:]
    log_x = np.log([row["center"] for row in last_three])
    log_j = np.log([row["J"] for row in last_three])
    areas = np.array([row["area"] for row in last_three])
    j_exponent, log_j_coefficient = np.polyfit(log_x, log_j, 1)
    area_slope, area_intercept = np.polyfit(log_x, areas, 1)
    last = rows[-1]
    gates = {
        "A0_EXACT_LENGTH": all(
            abs(horn.metric_length(
                metric,
                horn.WindingGraph(row["center"], row["amplitude"], row["high_points"]),
            ) - target_length) / target_length < 2.0e-12
            for row in rows
        ),
        "A1_ADAPTIVE_RESOLUTION": all(
            row["J_resolution_relative"] < 1.0e-9
            and row["area_resolution_absolute"] < 1.0e-11
            and abs(row["gauss_bonnet_residual"]) < 1.0e-10
            for row in rows
        ),
        "A2_AMPLITUDE_LIMIT": abs(last["amplitude_deficit_ratio"] - 1.0) < 1.0e-3,
        "A3_AREA_OFFSET_LIMIT": abs(last["area_offset_error"]) < 5.0e-5,
        "A4_J_COEFFICIENT_LIMIT": abs(last["J_over_X6_relative_error"]) < 2.0e-4,
        "A5_J_EXPONENT_SIX": abs(float(j_exponent) - 6.0) < 2.0e-3,
        "A6_AREA_LOG_SLOPE": abs(float(area_slope) - 2.0 * math.pi) < 2.0e-4,
    }
    return {
        "program": "dido_horn_asymptotics.py",
        "target_length": target_length,
        "centers": list(centers),
        "resolution_rule": "N_low=max(4096,64*X), N_high=2*N_low",
        "known_limits": {
            "amplitude": "A_X -> L/4",
            "amplitude_deficit": (
                "L/4-A_X ~ [log(4*(L/4)*X)/(2*(L/4)) + 1/(4*(L/4))]/X^2"
            ),
            "area": "Area(X)-2*pi*log(X) -> explicit primitive constant",
            "J": "J(X)/X^6 -> (64/35)*(L/4)^3",
            "layer_width": "theta_layer ~ 1/((L/4)*X)",
        },
        "limit_values": {
            "amplitude": amp_limit,
            "area_offset": area_limit,
            "J_over_X6": j_limit,
        },
        "rows": rows,
        "last_three_fits": {
            "J_power_exponent": float(j_exponent),
            "J_power_coefficient": float(math.exp(log_j_coefficient)),
            "area_log_slope": float(area_slope),
            "area_log_intercept": float(area_intercept),
        },
        "gates": gates,
        "all_gates_pass": all(gates.values()),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--length", type=float, default=6.0)
    parser.add_argument("--centers", type=float, nargs="+",
                        default=[32.0, 64.0, 128.0, 256.0, 512.0])
    parser.add_argument("--samples-per-depth", type=int, default=64)
    parser.add_argument("--json", type=Path, default=Path("dido_horn_asymptotics_report.json"))
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_study(args.length, tuple(args.centers), args.samples_per_depth)
    print("=" * 126)
    print("GABRIEL HORN ASYMPTOTICS  L={}".format(args.length))
    print("=" * 126)
    print("{:>6} {:>8} {:>13} {:>11} {:>13} {:>11} {:>13} {:>11}".format(
        "X", "N(high)", "1.5-A", "amp ratio", "area-2piLnX", "area err",
        "J/X^6", "J rel err"))
    for row in report["rows"]:
        print("{center:6.0f} {high_points:8d} {amplitude_deficit:13.6e} "
              "{amplitude_deficit_ratio:11.8f} {area_offset:13.9f} "
              "{area_offset_error:11.3e} {J_over_X6:13.9f} "
              "{J_over_X6_relative_error:11.3e}".format(**row))
    fits = report["last_three_fits"]
    print("last-three J exponent = {:.12f} (limit 6)".format(
        fits["J_power_exponent"]))
    print("last-three area slope = {:.12f} (limit 2*pi={:.12f})".format(
        fits["area_log_slope"], 2.0 * math.pi))
    for name, passed in report["gates"].items():
        print("[{}] {}".format("PASS" if passed else "FAIL", name))
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print("Wrote {}".format(args.json))
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

"""Regression test for process-independent verifier random streams."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent


class VerifierSeedTests(unittest.TestCase):
    def test_local_rng_is_independent_of_python_hash_seed(self) -> None:
        code = (
            "import json; import dido_verifier_v3 as d; "
            "print(json.dumps(d.local_rng('mc_area', 8, 384).random(6).tolist()))"
        )
        outputs: list[str] = []
        for hash_seed in ("1", "987654321"):
            env = os.environ.copy()
            env["PYTHONHASHSEED"] = hash_seed
            outputs.append(
                subprocess.check_output(
                    [sys.executable, "-c", code],
                    cwd=ROOT,
                    env=env,
                    text=True,
                ).strip()
            )

        self.assertEqual(outputs[0], outputs[1])
        self.assertEqual(len(json.loads(outputs[0])), 6)


if __name__ == "__main__":
    unittest.main()

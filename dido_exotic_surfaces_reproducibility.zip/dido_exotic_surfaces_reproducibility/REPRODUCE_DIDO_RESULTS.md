# Reproduce the Dido Exotic Surface Results

## Quick start

Create a clean Python 3.10 or later environment and install the two runtime
dependencies.

```text
python -m venv .venv
.venv/Scripts/python -m pip install --upgrade pip
.venv/Scripts/python -m pip install -r requirements.txt
.venv/Scripts/python reproduce_all.py
```

On Linux or macOS, replace `.venv/Scripts/python` with `.venv/bin/python`.

## Expected outcome

The runner must exit with status zero. It runs the complete unit-test discovery,
the six-surface campaign, the full ring-torus calculation, the hardened
baseline verifier, the conformal quick survey, and the high-resolution horn,
cigar, and Klein-bottle studies. A survey case that fails to produce a
certified optimizer remains explicitly inconclusive; this is an expected
scientific outcome, not a failed reproduction.

Numerical fingerprints are tabulated in Appendix F of the paper. Important
limits include

```text
horn:  J/X^6 -> 216/35
cigar: exp(2X) J -> 8*pi
cigar: exp(2X) [Area - 2*pi*(X-log(2))] -> 2*pi
Klein bottle: disk/separator crossover -> 4/pi
smooth sphere witness: area gap -> 8*pi
```

## Integrity check

Verify `SHA256SUMS.txt` before executing files. On Linux or macOS:

```text
sha256sum -c SHA256SUMS.txt
```

On PowerShell:

```text
Get-Content SHA256SUMS.txt | ForEach-Object {
    $parts = $_ -split '  ', 2
    if ((Get-FileHash $parts[1] -Algorithm SHA256).Hash.ToLower() -ne $parts[0]) {
        throw "Hash mismatch: $($parts[1])"
    }
}
```

## Interpretation rules

An optimizer failure is inconclusive, not a counterexample. Do not accept a
candidate unless its length or area constraint, admissibility, topology,
Gauss-Bonnet, and resolution gates pass. The Fourier experiments are evidence
within their declared ansatz classes. Exact constructions and asymptotic
derivations are identified separately in the paper.

import math
import unittest

import numpy as np

import dido_cigar as cigar


class CigarGeometryTests(unittest.TestCase):
    def setUp(self):
        self.metric = cigar.CigarMetric()

    def test_warp_and_curvature_identity(self):
        for rho in (0.2, 1.0, 3.0):
            step = 1.0e-5
            ap_plus = float(self.metric.warp_prime(rho + step))
            ap_minus = float(self.metric.warp_prime(rho - step))
            app = (ap_plus - ap_minus) / (2.0 * step)
            expected = -app / float(self.metric.warp(rho))
            self.assertAlmostEqual(float(self.metric.gaussian_curvature(rho)),
                                   expected, places=8)

    def test_area_primitive(self):
        for rho in (0.2, 1.0, 3.0, 7.0):
            step = 1.0e-5
            derivative = (
                float(self.metric.area_primitive(rho + step))
                - float(self.metric.area_primitive(rho - step))
            ) / (2.0 * step)
            self.assertAlmostEqual(derivative, math.tanh(rho), places=9)

    def test_parallel_known_answers(self):
        for rho in (0.5, 2.0, 5.0):
            ref = cigar.parallel_reference(self.metric, rho, 1024)
            self.assertAlmostEqual(ref["length_numeric"], ref["length_exact"],
                                   places=12)
            self.assertAlmostEqual(ref["area_numeric"], ref["area_exact"],
                                   places=12)
            self.assertAlmostEqual(ref["kappa_numeric"], ref["kappa_exact"],
                                   places=12)
            self.assertLess(ref["J"], 1.0e-20)
            self.assertLess(abs(ref["gauss_bonnet_residual"]), 1.0e-12)

    def test_exact_threshold_length_and_escape(self):
        areas = []
        amplitudes = []
        for center in (2.0, 3.0, 4.0, 5.0):
            graph = cigar.solve_exact_length(self.metric, center, 2.0 * math.pi,
                                             1024)
            row = cigar.diagnostics(self.metric, graph, 2.0 * math.pi)
            areas.append(float(row["area"]))
            amplitudes.append(graph.amplitude)
            self.assertLess(float(row["length_relative_error"]), 2.0e-12)
            self.assertTrue(row["admissible"])
            self.assertLess(abs(float(row["gauss_bonnet_residual"])), 1.0e-10)
        self.assertTrue(np.all(np.diff(areas) > 0.0))
        self.assertTrue(np.all(np.diff(amplitudes) < 0.0))

    def test_full_experiment(self):
        report = cigar.run_experiment(points=1024)
        self.assertTrue(report["all_gates_pass"], report["gates"])


if __name__ == "__main__":
    unittest.main()

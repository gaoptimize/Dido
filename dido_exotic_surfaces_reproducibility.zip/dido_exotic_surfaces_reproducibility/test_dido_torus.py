import math
import unittest

import numpy as np

import dido_torus as torus_code


class TorusGeometryTests(unittest.TestCase):
    def setUp(self):
        self.torus = torus_code.RingTorus(3.0, 1.0)

    def test_parallel_formulas(self):
        for theta in (0.0, 0.5 * np.pi, np.pi, -0.7):
            result = torus_code.parallel_reference(self.torus, theta, 1024)
            self.assertAlmostEqual(
                result["length_numeric"], result["length_exact"], places=12
            )
            self.assertAlmostEqual(
                result["kappa_numeric"], result["kappa_exact"], places=12
            )
            self.assertAlmostEqual(
                result["K_numeric"], result["K_exact"], places=12
            )
            self.assertLess(result["J"], 1.0e-20)

    def test_contractible_coordinate_circle_closes_gauss_bonnet(self):
        loop = torus_code.FourierLoop(3, 2048)
        coefficients = loop.local_metric_circle(self.torus, 0.35, 0.0, 0.55)
        residual = torus_code.gauss_bonnet_residual(
            self.torus, loop, coefficients
        )
        self.assertLess(abs(residual), 1.0e-11)
        self.assertTrue(torus_code.is_simple(loop, coefficients))
        self.assertAlmostEqual(
            torus_code.rotation_number(loop, coefficients), 1.0, places=12
        )

    def test_outer_equator_has_maximum_gaussian_curvature(self):
        samples = np.linspace(-np.pi, np.pi, 4097)
        curvature = self.torus.gaussian_curvature(samples)
        maximum_index = int(np.argmax(curvature))
        self.assertAlmostEqual(samples[maximum_index], 0.0, places=12)
        self.assertAlmostEqual(
            float(curvature[maximum_index]),
            1.0 / (
                self.torus.minor_radius
                * (self.torus.major_radius + self.torus.minor_radius)
            ),
            places=12,
        )

    def test_area_is_invariant_under_coordinate_period_shifts(self):
        loop = torus_code.FourierLoop(2, 1024)
        coefficients = loop.local_metric_circle(self.torus, 0.2, 0.4, 0.6)
        area = torus_code.enclosed_area(self.torus, loop, coefficients)
        theta_shift = coefficients.copy()
        theta_shift[0] += 2.0 * math.pi
        phi_shift = coefficients.copy()
        phi_shift[1] += 2.0 * math.pi
        self.assertAlmostEqual(
            torus_code.enclosed_area(self.torus, loop, theta_shift), area, places=11
        )
        self.assertAlmostEqual(
            torus_code.enclosed_area(self.torus, loop, phi_shift), area, places=11
        )


if __name__ == "__main__":
    unittest.main()

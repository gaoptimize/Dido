import math
import unittest

import numpy as np

import dido_argument_audit as audit


class DidoArgumentAuditTests(unittest.TestCase):
    def test_smooth_step_end_behavior(self):
        values = audit.smooth_step(np.array([-1.0, 0.0, 0.5, 1.0, 2.0]))
        np.testing.assert_allclose(values, [0.0, 0.0, 0.5, 1.0, 1.0])

    def test_profile_poles_positivity_and_linear_bands(self):
        self.assertEqual(float(audit.profile(0.0)), 0.0)
        self.assertEqual(float(audit.profile(9.0)), 0.0)
        grid = np.linspace(0.0, 9.0, 20001)
        self.assertGreater(float(np.min(audit.profile(grid)[1:-1])), 0.0)
        for center in (audit.R1, audit.R2):
            offsets = np.linspace(-0.25, 0.25, 101)
            np.testing.assert_allclose(
                audit.profile(center + offsets), 1.0 + 0.5 * offsets,
                atol=2.0e-15,
            )

    def test_two_parallels_are_equal_length_zero_energy(self):
        first = audit.parallel_invariants(audit.R1)
        second = audit.parallel_invariants(audit.R2)
        self.assertEqual(first["length"], 2.0 * math.pi)
        self.assertEqual(first["length"], second["length"])
        self.assertEqual(first["kappa_g"], 0.5)
        self.assertEqual(first["J"], second["J"])
        self.assertEqual(first["J"], 0.0)

    def test_area_gap_is_eight_pi(self):
        checks = {item.name: item for item in audit.construction_checks()}
        self.assertTrue(checks["area_integral"].passed)
        self.assertAlmostEqual(checks["exact_area_gap"].value,
                               8.0 * math.pi, places=10)
        self.assertTrue(checks["global_bound_impossible"].passed)

    def test_stability_spectrum(self):
        eigenvalues = [n * n - 0.25 for n in range(1, 50)]
        self.assertEqual(min(eigenvalues), 0.75)

    def test_nonlinear_local_regression(self):
        checks = audit.local_perturbation_checks(trials=12, points=1024)
        self.assertTrue(all(item.passed for item in checks), checks)

    def test_full_audit(self):
        report = audit.run_audit(trials=8, points=1024)
        self.assertTrue(report["all_checks_pass"])


if __name__ == "__main__":
    unittest.main()

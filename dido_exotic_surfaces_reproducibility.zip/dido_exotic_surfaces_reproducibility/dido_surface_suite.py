"""Run the six-surface Dido numerical stress-test campaign."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

import dido_cigar
import dido_cusp
import dido_flat_torus
import dido_horn
import dido_klein_bottle
import dido_paraboloid


def run_suite() -> dict[str, object]:
    ordered = [
        ("capped_gabriel_horn", dido_horn.run_experiment()),
        ("hamilton_cigar", dido_cigar.run_experiment()),
        ("hyperbolic_cusp", dido_cusp.run_experiment()),
        ("flat_torus", dido_flat_torus.run_experiment()),
        ("klein_bottle", dido_klein_bottle.run_experiment()),
        ("paraboloid", dido_paraboloid.run_experiment()),
    ]
    return {
        "program": "dido_surface_suite.py",
        "surface_order": [name for name, _ in ordered],
        "all_surfaces_pass": all(report["all_gates_pass"] for _, report in ordered),
        "results": {name: report for name, report in ordered},
        "interpretation": {
            "capped_gabriel_horn": "fixed-length area escape; J grows",
            "hamilton_cigar": "fixed-length area escape while J tends toward zero",
            "hyperbolic_cusp": "noncompact finite-area regions; chi=0",
            "flat_torus": "selected side, homology, and boundary-component dependence",
            "klein_bottle": "orientation-cover and one-sided-curve dependence",
            "paraboloid": "noncompact positive control; circle recovered without escape",
        },
    }


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, default=Path("dido_surface_suite_report.json"))
    args = parser.parse_args(list(argv) if argv is not None else None)
    report = run_suite()
    for name in report["surface_order"]:
        result = report["results"][name]
        print("[{}] {:<24} {}".format(
            "PASS" if result["all_gates_pass"] else "FAIL",
            name, report["interpretation"][name]))
    print("ALL SURFACES: {}".format("PASS" if report["all_surfaces_pass"] else "FAIL"))
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print("Wrote {}".format(args.json))
    return 0 if report["all_surfaces_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

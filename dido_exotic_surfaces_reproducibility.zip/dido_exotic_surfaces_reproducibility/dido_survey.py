"""Numerical survey harness for the fixed-length Dido condition.

This program generalizes ``dido_verifier_v3.py`` from one conformal metric
to a reproducible ensemble of analytic metrics

    g = exp(2 u(x, y)) (dx^2 + dy^2),

where ``u`` is a mixture of asymmetric Gaussian bumps.  It searches for an
area-maximizing embedded disk boundary at several prescribed metric lengths
and tests the necessary Euler-Lagrange condition

    geodesic curvature == constant.

It is a falsification survey, not a proof and not an atlas/mesh solver for
arbitrary global topology.  Every reported case is a disk contained in one
conformal chart.  The core geometry and Fourier representation are imported
from the independently hardened v3 verifier.

Typical invocations (from PowerShell):

    python dido_survey.py quick
    python dido_survey.py standard --json survey.json
    python dido_survey.py stress --seed 20260731

The default Python must provide NumPy and SciPy.  In the current project
environment they are available through D:\\rapl\\rapl_venv\\Scripts\\python.exe.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Sequence

try:
    import numpy as np
    from scipy.optimize import minimize
    from scipy.special import jn_zeros, jv, jvp
except ModuleNotFoundError as exc:  # pragma: no cover - environment message
    raise SystemExit(
        "dido_survey.py requires NumPy and SciPy. In this workspace run it "
        "with D:\\rapl\\rapl_venv\\Scripts\\python.exe."
    ) from exc

import dido_verifier_v3 as core


Array = np.ndarray
MetricFunction = Callable[[Array, Array], tuple[Array, Array, Array, Array]]


@dataclass(frozen=True)
class Bump:
    height: float
    sigma: float
    cx: float
    cy: float


@dataclass(frozen=True)
class MetricSpec:
    name: str
    bumps: tuple[Bump, ...]

    def ufun(self) -> MetricFunction:
        bumps = self.bumps

        def evaluate(x: Array, y: Array):
            u = np.zeros_like(x, dtype=float)
            ux = np.zeros_like(x, dtype=float)
            uy = np.zeros_like(x, dtype=float)
            lap = np.zeros_like(x, dtype=float)
            for bump in bumps:
                dx = x - bump.cx
                dy = y - bump.cy
                sig2 = bump.sigma * bump.sigma
                rho = dx * dx + dy * dy
                term = bump.height * np.exp(-rho / (2.0 * sig2))
                u += term
                ux += term * (-dx / sig2)
                uy += term * (-dy / sig2)
                lap += term * (rho / (sig2 * sig2) - 2.0 / sig2)
            return u, ux, uy, lap

        return evaluate


@dataclass(frozen=True)
class BesselMode:
    amplitude: float
    angular_order: int
    radial_index: int
    phase: float


@dataclass(frozen=True)
class BesselMetricSpec:
    """Finite drumhead-mode conformal factor, extended analytically to R2."""

    name: str
    radius: float
    modes: tuple[BesselMode, ...]

    def wave_numbers(self) -> tuple[float, ...]:
        return tuple(
            float(jn_zeros(mode.angular_order, mode.radial_index)[-1]
                  / self.radius)
            for mode in self.modes
        )

    def ufun(self) -> MetricFunction:
        modes = self.modes
        wave_numbers = self.wave_numbers()

        def evaluate(x: Array, y: Array):
            r = np.hypot(x, y)
            theta = np.arctan2(y, x)
            cos_theta = np.divide(x, r, out=np.ones_like(r), where=r > 1.0e-12)
            sin_theta = np.divide(y, r, out=np.zeros_like(r), where=r > 1.0e-12)
            u = np.zeros_like(x, dtype=float)
            ux = np.zeros_like(x, dtype=float)
            uy = np.zeros_like(x, dtype=float)
            lap = np.zeros_like(x, dtype=float)
            origin = r <= 1.0e-12
            away = ~origin
            for mode, k in zip(modes, wave_numbers):
                m = mode.angular_order
                angle = m * theta + mode.phase
                jm = jv(m, k * r)
                trig = np.cos(angle)
                term = mode.amplitude * jm * trig
                u += term
                lap -= k * k * term  # exact Helmholtz eigenfunction identity

                radial = mode.amplitude * k * jvp(m, k * r, 1) * trig
                theta_over_r = np.zeros_like(r)
                np.divide(
                    -mode.amplitude * m * jm * np.sin(angle),
                    r,
                    out=theta_over_r,
                    where=away,
                )
                ux[away] += (
                    radial[away] * cos_theta[away]
                    - theta_over_r[away] * sin_theta[away]
                )
                uy[away] += (
                    radial[away] * sin_theta[away]
                    + theta_over_r[away] * cos_theta[away]
                )
                if m == 1 and np.any(origin):
                    # J_1(kr) cos(theta+phase) has a linear Cartesian limit.
                    ux[origin] += 0.5 * mode.amplitude * k * np.cos(mode.phase)
                    uy[origin] -= 0.5 * mode.amplitude * k * np.sin(mode.phase)
            return u, ux, uy, lap

        return evaluate


MetricLike = MetricSpec | BesselMetricSpec


@dataclass(frozen=True)
class Preset:
    metrics: int
    lengths: tuple[float, ...]
    starts: int
    modes: int
    points: int
    refine_modes: int
    refine_points: int
    maxiter: int
    mc_samples: int


PRESETS = {
    "quick": Preset(2, (6.0,), 3, 6, 256, 9, 512, 220, 6000),
    "bessel-quick": Preset(2, (6.0,), 1, 3, 72, 5, 144, 220, 1500),
    "standard": Preset(6, (4.5, 6.0, 7.5), 5, 8, 384, 12, 768, 350, 15000),
    "stress": Preset(20, (3.5, 4.5, 6.0, 7.5, 9.0), 8, 10, 512,
                     16, 1024, 500, 30000),
}


TOL = {
    "length_rel": 2.0e-6,
    "rotation": 2.0e-2,
    "gauss_bonnet": 2.0e-5,
    "mc_area_rel": 4.0e-2,
    "area_resolution_rel": 2.0e-6,
    "constancy": 1.0e-2,
    "j_dimensionless": 5.0e-2,
    "kkt": 5.0e-3,
    "consensus_area_rel": 1.0e-4,
    "power_spread": 0.5,
    "power_wstd": 0.1,
    "bound_fraction": 0.95,
}

COEFFICIENT_BOUND = 3.0


def stable_seed(master: int, *tags: object) -> int:
    """Process-independent seed derivation (unlike Python's salted hash)."""
    payload = json.dumps([master, *tags], sort_keys=True,
                         separators=(",", ":"), default=str).encode("utf-8")
    digest = hashlib.sha256(payload).digest()
    return int.from_bytes(digest[:8], "little", signed=False)


def rng_for(master: int, *tags: object) -> np.random.Generator:
    return np.random.default_rng(stable_seed(master, *tags))


def builtin_metric() -> MetricSpec:
    return MetricSpec(
        "two_bump_reference",
        (
            Bump(0.60, 0.90, 0.40, 0.10),
            Bump(-0.35, 0.55, -0.70, -0.45),
        ),
    )


def random_metric(index: int, master_seed: int) -> MetricSpec:
    """Make a bounded, asymmetric, mixed-curvature analytic metric.

    One positive bump is forced so that the optimizer has a reason not to
    escape into the asymptotically flat part of the chart.  Remaining bumps
    have mixed signs and distinct widths/centers with probability one.
    """
    rng = rng_for(master_seed, "metric", index)
    n_bumps = int(rng.integers(3, 7))
    bumps = [
        Bump(
            float(rng.uniform(0.40, 0.85)),
            float(rng.uniform(0.55, 1.20)),
            float(rng.uniform(-0.9, 0.9)),
            float(rng.uniform(-0.9, 0.9)),
        )
    ]
    for _ in range(n_bumps - 1):
        height = float(rng.uniform(-0.60, 0.70))
        if abs(height) < 0.12:
            height = math.copysign(0.12, height if height else 1.0)
        bumps.append(
            Bump(
                height,
                float(rng.uniform(0.40, 1.35)),
                float(rng.uniform(-1.45, 1.45)),
                float(rng.uniform(-1.45, 1.45)),
            )
        )
    return MetricSpec("random_{:03d}".format(index), tuple(bumps))


def bessel_control() -> BesselMetricSpec:
    return BesselMetricSpec(
        "bessel_radial_control",
        3.0,
        (BesselMode(0.65, 0, 1, 0.0),),
    )


def bessel_multimodal_control() -> BesselMetricSpec:
    """Fixed asymmetric three-mode test with no continuous symmetry."""
    return BesselMetricSpec(
        "bessel_multimodal_control",
        3.0,
        (
            BesselMode(0.34, 0, 1, 0.0),
            BesselMode(0.29, 2, 1, 0.37),
            BesselMode(-0.23, 3, 2, 1.11),
        ),
    )


def random_bessel_metric(index: int, master_seed: int) -> BesselMetricSpec:
    rng = rng_for(master_seed, "bessel_metric", index)
    mode_count = int(rng.integers(4, 7))
    modes = [
        BesselMode(float(rng.uniform(0.22, 0.42)), 0, 1, 0.0),
        BesselMode(float(rng.uniform(0.20, 0.36)), 2, 1,
                   float(rng.uniform(0.0, 2.0 * np.pi))),
    ]
    for _ in range(mode_count - 2):
        m = int(rng.integers(1, 7))
        radial_index = int(rng.integers(1, 4))
        amplitude = float(rng.uniform(-0.30, 0.30))
        if abs(amplitude) < 0.08:
            amplitude = math.copysign(0.08, amplitude if amplitude else 1.0)
        modes.append(BesselMode(amplitude, m, radial_index,
                                float(rng.uniform(0.0, 2.0 * np.pi))))
    total_amplitude = sum(abs(mode.amplitude) for mode in modes)
    if total_amplitude > 1.0:
        modes = [
            BesselMode(mode.amplitude / total_amplitude, mode.angular_order,
                       mode.radial_index, mode.phase)
            for mode in modes
        ]
    return BesselMetricSpec("bessel_random_{:03d}".format(index), 3.0,
                            tuple(modes))


def metric_suite(count: int, master_seed: int,
                 family: str = "gaussian") -> list[MetricLike]:
    if count < 1:
        raise ValueError("metric count must be positive")
    if family == "gaussian":
        return [builtin_metric()] + [
            random_metric(i, master_seed) for i in range(1, count)
        ]
    if family == "bessel":
        suite: list[MetricLike] = [bessel_control()]
        if count >= 2:
            suite.append(bessel_multimodal_control())
        suite.extend(
            random_bessel_metric(i, master_seed) for i in range(2, count)
        )
        return suite
    suite: list[MetricLike] = [builtin_metric()]
    if count >= 2:
        suite.append(bessel_control())
    for i in range(2, count):
        if i % 2 == 0:
            suite.append(random_bessel_metric(i, master_seed))
        else:
            suite.append(random_metric(i, master_seed))
    return suite


def load_metric_file(path: Path) -> tuple[list[MetricLike], dict[str, list[float]]]:
    """Load Gaussian conformal metrics from a small, auditable JSON format."""
    raw = json.loads(path.read_text(encoding="utf-8"))
    specs: list[MetricSpec] = []
    lengths: dict[str, list[float]] = {}
    for item in raw["metrics"]:
        bumps = tuple(Bump(*map(float, values)) for values in item["bumps"])
        spec = MetricSpec(str(item["name"]), bumps)
        specs.append(spec)
        if "lengths" in item:
            lengths[spec.name] = [float(x) for x in item["lengths"]]
    return specs, lengths


def seed_centers(spec: MetricLike) -> list[tuple[float, float]]:
    if isinstance(spec, MetricSpec):
        return [(0.0, 0.0)] + [
            (b.cx, b.cy) for b in sorted(
                spec.bumps, key=lambda bump: bump.height, reverse=True
            )
        ]
    centers = [(0.0, 0.0)]
    for radius_fraction, angle in ((0.35, 0.0), (0.55, 1.7),
                                   (0.75, 3.4), (0.60, 5.0)):
        radius = radius_fraction * spec.radius
        centers.append((radius * math.cos(angle), radius * math.sin(angle)))
    return centers


def characteristic_metric_scale(spec: MetricLike) -> float:
    if isinstance(spec, MetricSpec):
        return float(np.median([b.sigma for b in spec.bumps]))
    return 2.0 * np.pi / max(spec.wave_numbers())


def serialize_metric(spec: MetricLike) -> dict[str, object]:
    if isinstance(spec, MetricSpec):
        return {
            "name": spec.name,
            "family": "gaussian",
            "bumps": [asdict(bump) for bump in spec.bumps],
        }
    return {
        "name": spec.name,
        "family": "bessel",
        "radius": spec.radius,
        "modes": [asdict(mode) for mode in spec.modes],
        "wave_numbers": list(spec.wave_numbers()),
    }


def scale_shape(curve: core.FourierCurve, coefficients: Array,
                factor: float) -> None:
    for block in range(4):
        lo = 2 + block * curve.m
        coefficients[lo:lo + curve.m] *= factor


def initial_genomes(spec: MetricLike, ufun: MetricFunction,
                    curve: core.FourierCurve, length: float, count: int,
                    master_seed: int) -> list[tuple[str, Array]]:
    centers = seed_centers(spec)
    rng = rng_for(master_seed, "starts", spec.name, length)
    while len(centers) < count:
        centers.append((float(rng.uniform(-1.6, 1.6)),
                        float(rng.uniform(-1.6, 1.6))))

    starts: list[tuple[str, Array]] = []
    for index, (cx, cy) in enumerate(centers[:count]):
        u0 = float(ufun(np.array([cx]), np.array([cy]))[0][0])
        radius = float(np.clip(length / (2.0 * np.pi * np.exp(u0)),
                               0.20, 2.25))
        c = curve.circle_genome(cx, cy, radius)
        if index >= 2 and curve.m >= 3:
            # Break circular symmetry without threatening orientation.
            noise = rng.normal(0.0, 0.025 * radius, (4, curve.m))
            noise[:, 0] = 0.0
            for block in range(4):
                lo = 2 + block * curve.m
                c[lo:lo + curve.m] += noise[block]
        for _ in range(4):
            current = core.metric_length(ufun, curve, c)
            if not np.isfinite(current) or current <= 0:
                break
            scale_shape(curve, c, length / current)
        starts.append(("start_{:02d}".format(index), c))
    return starts


def winding_penalty(curve: core.FourierCurve, c: Array) -> float:
    _, winding = core.gate_rotation(curve, c)
    if not np.isfinite(winding):
        return 1.0e12
    return 100.0 * (winding - 1.0) ** 2


def optimize(ufun: MetricFunction, curve: core.FourierCurve, length: float,
             c0: Array, maxiter: int):
    def objective(c: Array) -> float:
        area = core.metric_area(ufun, curve, c)
        if not np.isfinite(area):
            return 1.0e12
        return -area + winding_penalty(curve, c)

    constraint = ({
        "type": "eq",
        "fun": lambda c: core.metric_length(ufun, curve, c) - length,
    },)
    bounds = [(-COEFFICIENT_BOUND, COEFFICIENT_BOUND)] * len(c0)
    result = minimize(
        objective,
        c0,
        method="SLSQP",
        constraints=constraint,
        bounds=bounds,
        options={"maxiter": maxiter, "ftol": 1.0e-11},
    )
    if not result.success:
        # A restart often turns SLSQP's line-search complaint at a stationary
        # endpoint into an explicit convergence certificate.
        restarted = minimize(
            objective,
            result.x,
            method="SLSQP",
            constraints=constraint,
            bounds=bounds,
            options={"maxiter": maxiter, "ftol": 1.0e-11},
        )
        if restarted.success or restarted.fun <= result.fun:
            result = restarted
    return result


def weighted_diagnostics(ufun: MetricFunction, curve: core.FourierCurve,
                         c: Array) -> dict[str, float]:
    kg, _, ds_g, K = core.geodesic_curvature(ufun, curve, c)
    length = core.metric_length(ufun, curve, c)
    area = core.metric_area(ufun, curve, c)
    mean_kg = core.weighted_mean(kg, ds_g)
    std_kg = core.weighted_std(kg, ds_g)
    std_K = core.weighted_std(K, ds_g)
    slope, r2 = core.weighted_slope_r2(K, kg, ds_g)
    J = core.jerk_functional(ufun, curve, c)
    x, y, _, _, _, _ = curve.eval(c)
    diameter_bound = float(np.hypot(np.ptp(x), np.ptp(y)))
    return {
        "length": float(length),
        "area": float(area),
        "kg_mean": float(mean_kg),
        "kg_wstd": float(std_kg),
        # Robust at or near a closed geodesic, unlike std/abs(mean).
        "constancy_residual": float(std_kg / (abs(mean_kg) + 1.0 / length)),
        "J": float(J),
        "J_dimensionless": float(J * length**3),
        "K_min": float(np.min(K)),
        "K_max": float(np.max(K)),
        "K_spread": float(np.ptp(K)),
        "K_wstd": float(std_K),
        "K_power_spread": float(np.ptp(K) * length**2),
        "K_power_wstd": float(std_K * length**2),
        "K_slope": float(slope),
        "K_slope_r2": float(r2),
        "diameter_bound": diameter_bound,
    }


def basic_audit(ufun: MetricFunction, curve: core.FourierCurve, c: Array,
                target_length: float) -> dict[str, object]:
    len_ok, measured_length = core.gate_length(ufun, curve, c, target_length)
    rot_ok, rotation = core.gate_rotation(curve, c)
    simple_ok, intersections = core.gate_simple(curve, c, n_check=None)
    gb_ok, gb_residual = core.gate_gauss_bonnet(ufun, curve, c)
    # Use survey tolerances rather than mutating the certified verifier's
    # global configuration.
    len_ok = abs(measured_length - target_length) / target_length <= TOL["length_rel"]
    rot_ok = abs(rotation - 1.0) <= TOL["rotation"]
    gb_ok = abs(gb_residual) <= TOL["gauss_bonnet"]
    return {
        "pass": bool(len_ok and rot_ok and simple_ok and gb_ok),
        "length_pass": bool(len_ok),
        "rotation_pass": bool(rot_ok),
        "simple_pass": bool(simple_ok),
        "gauss_bonnet_pass": bool(gb_ok),
        "length": float(measured_length),
        "rotation": float(rotation),
        "self_intersections": int(intersections),
        "gauss_bonnet_residual": float(gb_residual),
    }


def independent_mc_area(ufun: MetricFunction, curve: core.FourierCurve,
                        c: Array, samples: int,
                        rng: np.random.Generator) -> tuple[float, float]:
    """Independent ray-casting/Monte-Carlo metric-area estimate."""
    x, y, _, _, _, _ = curve.eval(c)
    pad = 0.04 * max(float(np.ptp(x)), float(np.ptp(y)), 1.0e-3)
    x0, x1 = float(x.min() - pad), float(x.max() + pad)
    y0, y1 = float(y.min() - pad), float(y.max() + pad)
    sx = rng.uniform(x0, x1, samples)
    sy = rng.uniform(y0, y1, samples)
    x2, y2 = np.roll(x, -1), np.roll(y, -1)
    inside = np.zeros(samples, dtype=bool)
    chunk = 4000
    for lo in range(0, samples, chunk):
        hi = min(lo + chunk, samples)
        SX = sx[lo:hi, None]
        SY = sy[lo:hi, None]
        crossing = (y[None, :] > SY) != (y2[None, :] > SY)
        with np.errstate(divide="ignore", invalid="ignore"):
            x_cross = x[None, :] + (SY - y[None, :]) * \
                (x2 - x)[None, :] / (y2 - y)[None, :]
        inside[lo:hi] = (np.sum(crossing & (SX < x_cross), axis=1) % 2) == 1
    u, _, _, _ = ufun(sx, sy)
    box_area = (x1 - x0) * (y1 - y0)
    estimate = box_area * float(np.mean(np.where(inside, np.exp(2.0 * u), 0.0)))
    exact = core.metric_area(ufun, curve, c)
    relative = abs(estimate - exact) / max(abs(exact), 1.0e-15)
    return float(estimate), float(relative)


def kkt_residual(ufun: MetricFunction, curve: core.FourierCurve,
                 c: Array) -> float:
    """Finite-difference coefficient-space constrained stationarity check."""
    grad_area = np.empty_like(c)
    grad_length = np.empty_like(c)
    for i in range(len(c)):
        step = 2.0e-6 * (1.0 + abs(float(c[i])))
        plus = c.copy()
        minus = c.copy()
        plus[i] += step
        minus[i] -= step
        grad_area[i] = (
            core.metric_area(ufun, curve, plus)
            - core.metric_area(ufun, curve, minus)
        ) / (2.0 * step)
        grad_length[i] = (
            core.metric_length(ufun, curve, plus)
            - core.metric_length(ufun, curve, minus)
        ) / (2.0 * step)
    denom = float(np.dot(grad_length, grad_length))
    if denom <= 1.0e-24:
        return float("inf")
    multiplier = float(np.dot(grad_area, grad_length) / denom)
    residual = grad_area - multiplier * grad_length
    scale = max(float(np.linalg.norm(grad_area)),
                abs(multiplier) * float(np.linalg.norm(grad_length)), 1.0)
    return float(np.linalg.norm(residual) / scale)


def resolution_check(ufun: MetricFunction, curve: core.FourierCurve,
                     c: Array) -> tuple[dict[str, float], dict[str, float], bool]:
    low = weighted_diagnostics(ufun, curve, c)
    high_curve = core.FourierCurve(curve.m, 2 * curve.n)
    high = weighted_diagnostics(ufun, high_curve, c)
    area_rel = abs(high["area"] - low["area"]) / max(abs(high["area"]), 1.0e-15)
    constancy_ceiling = max(3.0 * low["constancy_residual"],
                            TOL["constancy"] / 3.0)
    j_ceiling = max(3.0 * low["J_dimensionless"],
                    TOL["j_dimensionless"] / 3.0)
    passed = (
        area_rel <= TOL["area_resolution_rel"]
        and high["constancy_residual"] <= constancy_ceiling
        and high["J_dimensionless"] <= j_ceiling
    )
    high["area_resolution_rel"] = float(area_rel)
    return low, high, bool(passed)


def refine(ufun: MetricFunction, base_curve: core.FourierCurve, c: Array,
           target_length: float, preset: Preset):
    curve = core.FourierCurve(preset.refine_modes, preset.refine_points)
    embedded = curve.embed(c, base_curve.m)
    embedded_area = core.metric_area(ufun, curve, embedded)
    result = optimize(ufun, curve, target_length, embedded, preset.maxiter)
    audit = basic_audit(ufun, curve, result.x, target_length)
    area = core.metric_area(ufun, curve, result.x)
    accepted = bool(result.success and audit["pass"] and area >= embedded_area - 1.0e-8)
    return curve, (result.x if accepted else embedded), result, accepted


def classify(metrics: dict[str, float], audit: dict[str, object],
             resolution_pass: bool, mc_pass: bool, optimizer_success: bool,
             refinement_accepted: bool, kkt: float, consensus: int,
             bounds_active: bool) -> str:
    if not optimizer_success or not refinement_accepted:
        return "optimizer_inconclusive"
    if not audit["pass"] or not mc_pass:
        return "audit_failed"
    if bounds_active:
        return "chart_or_bound_limited"
    if not resolution_pass:
        return "resolution_inconclusive"
    if kkt > TOL["kkt"]:
        return "optimizer_inconclusive"
    constant = (
        metrics["constancy_residual"] <= TOL["constancy"]
        and metrics["J_dimensionless"] <= TOL["j_dimensionless"]
    )
    powered = (
        metrics["K_power_spread"] >= TOL["power_spread"]
        and metrics["K_power_wstd"] >= TOL["power_wstd"]
    )
    if not powered:
        return ("confirmed_locally_underpowered" if constant
                else "locally_underpowered_inconclusive")
    if not constant:
        # This is an investigation trigger, never an automatic mathematical
        # counterexample.  It has nevertheless cleared all numerical gates
        # on a boundary that samples substantial ambient-curvature variation.
        return "investigate_nonconstant"
    if consensus < 2:
        return "confirmed_powered_single_basin"
    return "confirmed_powered"


def survey_case(spec: MetricLike, target_length: float, preset: Preset,
                master_seed: int) -> dict[str, object]:
    ufun = spec.ufun()
    base_curve = core.FourierCurve(preset.modes, preset.points)
    starts = initial_genomes(spec, ufun, base_curve, target_length,
                             preset.starts, master_seed)
    attempts: list[dict[str, object]] = []
    admitted: list[tuple[float, Array, object]] = []

    for label, c0 in starts:
        result = optimize(ufun, base_curve, target_length, c0, preset.maxiter)
        audit = basic_audit(ufun, base_curve, result.x, target_length)
        area = core.metric_area(ufun, base_curve, result.x)
        attempts.append({
            "label": label,
            "success": bool(result.success),
            "status": int(result.status),
            "message": str(result.message),
            "iterations": int(result.nit),
            "area": float(area),
            "audit_pass": bool(audit["pass"]),
        })
        if result.success and audit["pass"] and np.isfinite(area):
            admitted.append((float(area), result.x.copy(), result))

    if not admitted:
        return {
            "metric": spec.name,
            "length": target_length,
            "status": "optimizer_inconclusive",
            "attempts": attempts,
            "reason": "no converged, audited multistart candidate",
        }

    admitted.sort(key=lambda item: item[0], reverse=True)
    best_area, best_c, _ = admitted[0]
    consensus = sum(
        abs(area - best_area) / max(abs(best_area), 1.0e-15)
        <= TOL["consensus_area_rel"]
        for area, _, _ in admitted
    )

    final_curve, final_c, refinement, refinement_accepted = refine(
        ufun, base_curve, best_c, target_length, preset
    )
    audit = basic_audit(ufun, final_curve, final_c, target_length)
    _, metrics, resolution_pass = resolution_check(
        ufun, final_curve, final_c
    )
    mc_estimate, mc_relative = independent_mc_area(
        ufun,
        final_curve,
        final_c,
        preset.mc_samples,
        rng_for(master_seed, "mc", spec.name, target_length),
    )
    mc_pass = mc_relative <= TOL["mc_area_rel"]
    kkt = kkt_residual(ufun, final_curve, final_c)
    bounds_active = bool(np.max(np.abs(final_c)) >=
                         TOL["bound_fraction"] * COEFFICIENT_BOUND)
    status = classify(
        metrics,
        audit,
        resolution_pass,
        mc_pass,
        bool(refinement.success),
        refinement_accepted,
        kkt,
        consensus,
        bounds_active,
    )
    metrics["footprint_to_metric_scale"] = (
        metrics["diameter_bound"] / characteristic_metric_scale(spec)
    )
    return {
        "metric": spec.name,
        "length": float(target_length),
        "status": status,
        "powered": bool(
            metrics["K_power_spread"] >= TOL["power_spread"]
            and metrics["K_power_wstd"] >= TOL["power_wstd"]
        ),
        "constant_curvature_pass": bool(
            metrics["constancy_residual"] <= TOL["constancy"]
            and metrics["J_dimensionless"] <= TOL["j_dimensionless"]
        ),
        "multistart_admitted": len(admitted),
        "multistart_consensus": int(consensus),
        "refinement_success": bool(refinement.success),
        "refinement_accepted": bool(refinement_accepted),
        "resolution_pass": bool(resolution_pass),
        "mc_area": mc_estimate,
        "mc_area_relative_error": mc_relative,
        "mc_area_pass": bool(mc_pass),
        "kkt_residual": kkt,
        "bounds_active": bounds_active,
        "audit": audit,
        "metrics": metrics,
        "modes": final_curve.m,
        "points": final_curve.n,
        "coefficients": [float(x) for x in final_c],
        "attempts": attempts,
    }


def summarize(cases: Sequence[dict[str, object]]) -> dict[str, object]:
    counts: dict[str, int] = {}
    for case in cases:
        status = str(case["status"])
        counts[status] = counts.get(status, 0) + 1
    powered = [case for case in cases if case.get("powered")]
    audited = [case for case in cases if str(case["status"]).startswith("confirmed")]
    investigations = [
        case for case in cases if case["status"] == "investigate_nonconstant"
    ]
    return {
        "total_cases": len(cases),
        "status_counts": counts,
        "powered_cases": len(powered),
        "confirmed_cases": len(audited),
        "investigation_triggers": len(investigations),
        "all_audited_cases_consistent": len(investigations) == 0,
    }


def print_case(case: dict[str, object]) -> None:
    status = case["status"]
    if "metrics" not in case:
        print("  {:<20} L={:>5.2f}  {}".format(
            case["metric"], case["length"], status
        ))
        return
    metrics = case["metrics"]
    print(
        "  {:<20} L={:>5.2f}  {:<31} "
        "A={:>8.4f}  C={:.2e}  JL^3={:.2e}  Kpow={:.2f}  starts={}/{}"
        .format(
            case["metric"],
            case["length"],
            status,
            metrics["area"],
            metrics["constancy_residual"],
            metrics["J_dimensionless"],
            metrics["K_power_wstd"],
            case["multistart_consensus"],
            case["multistart_admitted"],
        )
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("preset", nargs="?", choices=sorted(PRESETS),
                        default="quick")
    parser.add_argument("--seed", type=int, default=20260731)
    parser.add_argument("--metrics", type=int,
                        help="override the preset metric count")
    parser.add_argument("--family", choices=("gaussian", "bessel", "mixed"),
                        default="gaussian",
                        help="generated metric family (default: gaussian)")
    parser.add_argument("--lengths", type=float, nargs="+",
                        help="override the preset length list")
    parser.add_argument("--metrics-file", type=Path,
                        help="JSON file containing named Gaussian metrics")
    parser.add_argument("--json", type=Path,
                        help="write complete reproducibility report")
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    preset = PRESETS[args.preset]
    if args.metrics_file:
        specs, per_metric_lengths = load_metric_file(args.metrics_file)
    else:
        count = args.metrics if args.metrics is not None else preset.metrics
        specs = metric_suite(count, args.seed, args.family)
        per_metric_lengths = {}
    default_lengths = tuple(args.lengths) if args.lengths else preset.lengths

    print("=" * 112)
    print("DIDO NUMERICAL SURVEY  preset={} seed={}".format(args.preset, args.seed))
    print("Disk-type curves in analytic conformal charts; numerical evidence, not proof.")
    print("=" * 112)
    cases: list[dict[str, object]] = []
    for spec in specs:
        lengths = per_metric_lengths.get(spec.name, list(default_lengths))
        for length in lengths:
            case = survey_case(spec, float(length), preset, args.seed)
            cases.append(case)
            print_case(case)

    summary = summarize(cases)
    print("=" * 112)
    print("SUMMARY " + json.dumps(summary, sort_keys=True))
    if summary["investigation_triggers"]:
        print("VERDICT: at least one fully audited case requires investigation; "
              "no counterexample is claimed automatically.")
    elif summary["confirmed_cases"]:
        print("VERDICT: every confirmed case was consistent with constant "
              "geodesic curvature at the optimized boundary.")
    else:
        print("VERDICT: no case reached confirmation; optimizer/audit results are "
              "inconclusive.")
    print("=" * 112)

    report = {
        "program": "dido_survey.py",
        "seed": args.seed,
        "preset": args.preset,
        "preset_parameters": asdict(preset),
        "tolerances": TOL,
        "metrics": [serialize_metric(spec) for spec in specs],
        "summary": summary,
        "cases": cases,
        "scope": (
            "Disk-type boundaries contained in one analytic conformal chart; "
            "the survey does not prove a global optimum or cover arbitrary "
            "manifold topology."
        ),
    }
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True),
                             encoding="utf-8")
        print("Wrote {}".format(args.json))
    return 1 if summary["investigation_triggers"] else 0


if __name__ == "__main__":
    sys.exit(main())

"""Intrinsic fixed-length Dido experiment on a standard ring torus.

The torus is parametrized by meridian angle theta and longitude phi,

    X(theta, phi) = ((R + r cos(theta)) cos(phi),
                     (R + r cos(theta)) sin(phi),
                     r sin(theta)),

with R > r > 0.  Contractible candidate boundaries are periodic Fourier
loops in one unwrapped (theta, phi) chart.  All measured geometry is
intrinsic.  In particular,

    ds^2 = r^2 dtheta^2 + (R + r cos(theta))^2 dphi^2,
    K = cos(theta) / (r (R + r cos(theta))).

For a positively oriented contractible loop, area and the Gauss-Bonnet
bulk term have exact boundary primitives:

    Area(D)       = integral (r R theta + r^2 sin(theta)) dphi,
    integral_D K  = integral sin(theta) dphi.

This avoids mesh quadrature on the embedded surface.  The numerical result
is evidence about a Fourier-restricted optimizer, not a proof that the
champion is the global isoperimetric region on the torus.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

try:
    import numpy as np
    from scipy.optimize import minimize
except ImportError as exc:  # pragma: no cover - exercised by local setup
    raise SystemExit(
        "dido_torus.py requires NumPy and SciPy. In this workspace use "
        r"D:\rapl\rapl_venv\Scripts\python.exe."
    ) from exc


Array = np.ndarray
TAU = 2.0 * np.pi


@dataclass(frozen=True)
class RingTorus:
    major_radius: float = 3.0
    minor_radius: float = 1.0

    def __post_init__(self) -> None:
        if not self.major_radius > self.minor_radius > 0.0:
            raise ValueError("a ring torus requires major_radius > minor_radius > 0")

    def parallel_radius(self, theta: Array | float) -> Array | float:
        return self.major_radius + self.minor_radius * np.cos(theta)

    def gaussian_curvature(self, theta: Array | float) -> Array | float:
        a = self.parallel_radius(theta)
        return np.cos(theta) / (self.minor_radius * a)


class FourierLoop:
    """A contractible loop in an unwrapped torus coordinate chart."""

    def __init__(self, modes: int, points: int):
        if modes < 1 or points < 8:
            raise ValueError("modes must be positive and points at least 8")
        self.m = modes
        self.n = points
        self.t = np.linspace(0.0, TAU, points, endpoint=False)
        k = np.arange(1, modes + 1, dtype=float)
        self.cos = np.cos(np.outer(self.t, k))
        self.sin = np.sin(np.outer(self.t, k))
        self.cos_p = -self.sin * k
        self.sin_p = self.cos * k
        self.cos_pp = -self.cos * k**2
        self.sin_pp = -self.sin * k**2

    @property
    def coefficient_count(self) -> int:
        return 2 + 4 * self.m

    def evaluate(self, coefficients: Array) -> tuple[Array, ...]:
        m = self.m
        theta0, phi0 = coefficients[:2]
        a_theta = coefficients[2:2 + m]
        b_theta = coefficients[2 + m:2 + 2 * m]
        a_phi = coefficients[2 + 2 * m:2 + 3 * m]
        b_phi = coefficients[2 + 3 * m:2 + 4 * m]
        theta = theta0 + self.cos @ a_theta + self.sin @ b_theta
        phi = phi0 + self.cos @ a_phi + self.sin @ b_phi
        theta_t = self.cos_p @ a_theta + self.sin_p @ b_theta
        phi_t = self.cos_p @ a_phi + self.sin_p @ b_phi
        theta_tt = self.cos_pp @ a_theta + self.sin_pp @ b_theta
        phi_tt = self.cos_pp @ a_phi + self.sin_pp @ b_phi
        return theta, phi, theta_t, phi_t, theta_tt, phi_tt

    def local_metric_circle(
        self, torus: RingTorus, theta0: float, phi0: float, radius: float
    ) -> Array:
        coefficients = np.zeros(self.coefficient_count)
        coefficients[0:2] = theta0, phi0
        coefficients[2] = radius / torus.minor_radius
        a0 = float(torus.parallel_radius(theta0))
        coefficients[2 + 3 * self.m] = radius / a0
        return coefficients

    def embed(self, coefficients: Array, source_modes: int) -> Array:
        result = np.zeros(self.coefficient_count)
        result[:2] = coefficients[:2]
        for block in range(4):
            source = coefficients[
                2 + block * source_modes:2 + (block + 1) * source_modes
            ]
            result[2 + block * self.m:2 + block * self.m + source_modes] = source
        return result


def geometry_from_samples(
    torus: RingTorus,
    theta: Array,
    phi: Array,
    theta_t: Array,
    phi_t: Array,
    theta_tt: Array,
    phi_tt: Array,
) -> dict[str, Array]:
    """Return intrinsic speed, signed geodesic curvature, and K.

    The sign convention is positive for a counterclockwise Euclidean circle
    in the oriented (theta, phi) coordinate chart.
    """
    del phi  # The rotational metric is independent of longitude.
    r = torus.minor_radius
    a = np.asarray(torus.parallel_radius(theta))
    speed_sq = (r * theta_t) ** 2 + (a * phi_t) ** 2
    speed = np.sqrt(speed_sq)
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        gamma_theta_phiphi = a * np.sin(theta) / r
        gamma_phi_thetaphi = -r * np.sin(theta) / a
        accel_theta = theta_tt + gamma_theta_phiphi * phi_t**2
        accel_phi = phi_tt + 2.0 * gamma_phi_thetaphi * theta_t * phi_t
        kappa_g = r * a * (
            theta_t * accel_phi - phi_t * accel_theta
        ) / speed**3
    gaussian = np.asarray(torus.gaussian_curvature(theta))
    return {"speed": speed, "kappa_g": kappa_g, "K": gaussian}


def loop_geometry(torus: RingTorus, loop: FourierLoop, coefficients: Array) -> dict[str, Array]:
    return geometry_from_samples(torus, *loop.evaluate(coefficients))


def periodic_t_derivative(values: Array) -> Array:
    frequencies = np.fft.fftfreq(len(values), d=1.0 / len(values))
    return np.fft.ifft(1j * frequencies * np.fft.fft(values)).real


def metric_length(torus: RingTorus, loop: FourierLoop, coefficients: Array) -> float:
    return float(TAU * np.mean(loop_geometry(torus, loop, coefficients)["speed"]))


def enclosed_area(torus: RingTorus, loop: FourierLoop, coefficients: Array) -> float:
    theta, _, _, phi_t, _, _ = loop.evaluate(coefficients)
    r = torus.minor_radius
    primitive = r * torus.major_radius * theta + r**2 * np.sin(theta)
    return float(TAU * np.mean(primitive * phi_t))


def region_gaussian_curvature(
    torus: RingTorus, loop: FourierLoop, coefficients: Array
) -> float:
    del torus
    theta, _, _, phi_t, _, _ = loop.evaluate(coefficients)
    return float(TAU * np.mean(np.sin(theta) * phi_t))


def jerk_energy(torus: RingTorus, loop: FourierLoop, coefficients: Array) -> float:
    geometry = loop_geometry(torus, loop, coefficients)
    kappa_t = periodic_t_derivative(geometry["kappa_g"])
    with np.errstate(divide="ignore", invalid="ignore"):
        density = kappa_t**2 / geometry["speed"]
    return float(TAU * np.mean(density))


def weighted_mean(values: Array, weights: Array) -> float:
    return float(np.sum(values * weights) / np.sum(weights))


def weighted_std(values: Array, weights: Array) -> float:
    mean = weighted_mean(values, weights)
    return float(np.sqrt(np.sum(weights * (values - mean) ** 2) / np.sum(weights)))


def rotation_number(loop: FourierLoop, coefficients: Array) -> float:
    _, _, theta_t, phi_t, theta_tt, phi_tt = loop.evaluate(coefficients)
    denominator = theta_t**2 + phi_t**2
    with np.errstate(divide="ignore", invalid="ignore"):
        integrand = (theta_t * phi_tt - phi_t * theta_tt) / denominator
    return float(np.mean(integrand))


def is_simple(loop: FourierLoop, coefficients: Array, sample_count: int = 256) -> bool:
    theta, phi, *_ = loop.evaluate(coefficients)
    if sample_count < loop.n:
        indices = np.linspace(0, loop.n, sample_count, endpoint=False).astype(int)
        theta, phi = theta[indices], phi[indices]
    n = len(theta)
    next_theta, next_phi = np.roll(theta, -1), np.roll(phi, -1)
    chunk = 256
    for start in range(0, n, chunk):
        stop = min(start + chunk, n)
        ax, ay = theta[start:stop, None], phi[start:stop, None]
        bx, by = next_theta[start:stop, None], next_phi[start:stop, None]
        cx, cy = theta[None, :], phi[None, :]
        dx, dy = next_theta[None, :], next_phi[None, :]
        d1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
        d2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax)
        d3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx)
        d4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx)
        proper = (np.sign(d1) * np.sign(d2) < 0) & (
            np.sign(d3) * np.sign(d4) < 0
        )
        i = np.arange(start, stop)[:, None]
        j = np.arange(n)[None, :]
        separation = np.abs(i - j)
        proper &= ~((separation <= 1) | (separation >= n - 1))
        if np.any(proper):
            return False
    return True


def gauss_bonnet_residual(
    torus: RingTorus, loop: FourierLoop, coefficients: Array
) -> float:
    geometry = loop_geometry(torus, loop, coefficients)
    boundary = TAU * np.mean(geometry["kappa_g"] * geometry["speed"])
    bulk = region_gaussian_curvature(torus, loop, coefficients)
    return float(boundary + bulk - TAU)


def shape_scale(loop: FourierLoop, coefficients: Array, factor: float) -> Array:
    result = coefficients.copy()
    result[2:] *= factor
    return result


def fit_initial_length(
    torus: RingTorus, loop: FourierLoop, coefficients: Array, target: float
) -> Array:
    result = coefficients.copy()
    for _ in range(8):
        current = metric_length(torus, loop, result)
        result = shape_scale(loop, result, target / current)
        if abs(current - target) / target < 1.0e-10:
            break
    return result


def optimization_bounds(loop: FourierLoop) -> list[tuple[float, float]]:
    bounds: list[tuple[float, float]] = [(-np.pi, np.pi), (0.0, 0.0)]
    bounds.extend([(-2.5, 2.5)] * (loop.coefficient_count - 2))
    return bounds


def objective_penalty(loop: FourierLoop, coefficients: Array) -> float:
    theta, phi, theta_t, phi_t, *_ = loop.evaluate(coefficients)
    rotation = rotation_number(loop, coefficients)
    penalty = 100.0 * (rotation - 1.0) ** 2
    # Fourier loops have zero coordinate winding, but a span approaching a
    # full period can overlap itself after quotienting by the torus lattice.
    for span in (float(np.ptp(theta)), float(np.ptp(phi))):
        excess = max(0.0, span - 1.75 * np.pi)
        penalty += 100.0 * excess**2
    euclidean_speed_sq = theta_t**2 + phi_t**2
    if not np.all(np.isfinite(euclidean_speed_sq)) or np.min(euclidean_speed_sq) < 1e-10:
        penalty += 1.0e6
    return penalty


def optimize_area(
    torus: RingTorus,
    loop: FourierLoop,
    target_length: float,
    initial: Array,
    maxiter: int,
):
    constraint = {
        "type": "eq",
        "fun": lambda c: metric_length(torus, loop, c) - target_length,
    }
    return minimize(
        lambda c: -enclosed_area(torus, loop, c) + objective_penalty(loop, c),
        initial,
        method="SLSQP",
        bounds=optimization_bounds(loop),
        constraints=(constraint,),
        options={"maxiter": maxiter, "ftol": 1.0e-12, "disp": False},
    )


def diagnostics(torus: RingTorus, loop: FourierLoop, coefficients: Array) -> dict[str, float | bool]:
    geometry = loop_geometry(torus, loop, coefficients)
    weights = geometry["speed"]
    length = metric_length(torus, loop, coefficients)
    kappa_mean = weighted_mean(geometry["kappa_g"], weights)
    kappa_std = weighted_std(geometry["kappa_g"], weights)
    scale = max(abs(kappa_mean), 1.0 / length)
    energy = jerk_energy(torus, loop, coefficients)
    theta, phi, *_ = loop.evaluate(coefficients)
    return {
        "length": length,
        "area": enclosed_area(torus, loop, coefficients),
        "theta_center": float(np.arctan2(np.sin(coefficients[0]), np.cos(coefficients[0]))),
        "theta_span": float(np.ptp(theta)),
        "phi_span": float(np.ptp(phi)),
        "K_min": float(np.min(geometry["K"])),
        "K_max": float(np.max(geometry["K"])),
        "K_spread_L2": float(np.ptp(geometry["K"]) * length**2),
        "kappa_mean": kappa_mean,
        "kappa_std_relative": kappa_std / scale,
        "J": energy,
        "J_dimensionless": energy * length**3,
        "gauss_bonnet_residual": gauss_bonnet_residual(torus, loop, coefficients),
        "rotation_number": rotation_number(loop, coefficients),
        "simple_in_chart": is_simple(loop, coefficients),
    }


def parallel_reference(torus: RingTorus, theta0: float, points: int = 2048) -> dict[str, float]:
    t = np.linspace(0.0, TAU, points, endpoint=False)
    theta = np.full(points, theta0)
    phi = t
    zeros = np.zeros(points)
    ones = np.ones(points)
    geometry = geometry_from_samples(torus, theta, phi, zeros, ones, zeros, zeros)
    length = float(TAU * np.mean(geometry["speed"]))
    mean_kappa = weighted_mean(geometry["kappa_g"], geometry["speed"])
    return {
        "theta": theta0,
        "length_numeric": length,
        "length_exact": TAU * float(torus.parallel_radius(theta0)),
        "kappa_numeric": mean_kappa,
        "kappa_exact": -math.sin(theta0) / float(torus.parallel_radius(theta0)),
        "K_numeric": weighted_mean(geometry["K"], geometry["speed"]),
        "K_exact": float(torus.gaussian_curvature(theta0)),
        "J": float(TAU * np.mean(periodic_t_derivative(geometry["kappa_g"]) ** 2 / geometry["speed"])),
    }


def admitted(metrics: dict[str, float | bool], target_length: float, success: bool) -> bool:
    return bool(
        success
        and abs(float(metrics["length"]) - target_length) / target_length < 2.0e-7
        and abs(float(metrics["rotation_number"]) - 1.0) < 2.0e-4
        and bool(metrics["simple_in_chart"])
        and abs(float(metrics["gauss_bonnet_residual"])) < 2.0e-6
    )


def run_multistart(
    torus: RingTorus,
    loop: FourierLoop,
    target_length: float,
    centers: list[float],
    maxiter: int,
) -> tuple[object, dict[str, float | bool]]:
    best_result = None
    best_metrics = None
    for theta0 in centers:
        radius = target_length / TAU
        initial = loop.local_metric_circle(torus, theta0, 0.0, radius)
        initial = fit_initial_length(torus, loop, initial, target_length)
        result = optimize_area(torus, loop, target_length, initial, maxiter)
        metrics = diagnostics(torus, loop, result.x)
        is_admitted = admitted(metrics, target_length, bool(result.success))
        print(
            "  start theta={:+.3f} -> area={:.8f} center={:+.4f} "
            "kstd={:.2e} J*L^3={:.2e} GB={:+.2e} ok={} nit={}".format(
                theta0,
                float(metrics["area"]),
                float(metrics["theta_center"]),
                float(metrics["kappa_std_relative"]),
                float(metrics["J_dimensionless"]),
                float(metrics["gauss_bonnet_residual"]),
                is_admitted,
                result.nit,
            )
        )
        if is_admitted and (
            best_metrics is None or float(metrics["area"]) > float(best_metrics["area"])
        ):
            best_result, best_metrics = result, metrics
    if best_result is None or best_metrics is None:
        raise RuntimeError("no multistart candidate passed the intrinsic audit")
    return best_result, best_metrics


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--major-radius", type=float, default=3.0)
    parser.add_argument("--minor-radius", type=float, default=1.0)
    parser.add_argument("--length", type=float, default=4.0)
    parser.add_argument("--modes", type=int, default=4)
    parser.add_argument("--refine-modes", type=int, default=6)
    parser.add_argument("--points", type=int, default=1024)
    parser.add_argument("--refine-points", type=int, default=1536)
    parser.add_argument("--maxiter", type=int, default=600)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--json", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.quick:
        args.modes = 3
        args.refine_modes = 5
        args.points = 512
        args.refine_points = 1024
        args.maxiter = min(args.maxiter, 250)

    torus = RingTorus(args.major_radius, args.minor_radius)
    if not 0.0 < args.length < 1.5 * TAU * args.minor_radius:
        raise SystemExit(
            "This disk-chart experiment is intended for 0 < length < "
            "1.5*(2*pi*minor_radius)."
        )

    print("DIDO ON A STANDARD RING TORUS")
    print(
        "  R={} r={} target length={} modes {}->{} points {}->{}".format(
            torus.major_radius,
            torus.minor_radius,
            args.length,
            args.modes,
            args.refine_modes,
            args.points,
            args.refine_points,
        )
    )
    print("  Expected small-disk location: outer equator theta=0 (maximum K).")
    print("  Expected optimizer condition: kappa_g constant, J=0 numerically.")

    references = [
        parallel_reference(torus, 0.0),
        parallel_reference(torus, 0.5 * np.pi),
        parallel_reference(torus, np.pi),
    ]
    max_reference_error = max(
        abs(item["length_numeric"] - item["length_exact"])
        + abs(item["kappa_numeric"] - item["kappa_exact"])
        + abs(item["K_numeric"] - item["K_exact"])
        for item in references
    )
    print("  Parallel formula self-test max combined error: {:.3e}".format(max_reference_error))

    centers = [0.0, 0.5 * np.pi, -0.5 * np.pi, np.pi]
    base_loop = FourierLoop(args.modes, args.points)
    print("\nMULTISTART")
    result, base_metrics = run_multistart(
        torus, base_loop, args.length, centers, args.maxiter
    )

    refined_loop = FourierLoop(args.refine_modes, args.refine_points)
    embedded = refined_loop.embed(result.x, args.modes)
    print("\nREFINEMENT")
    refined_result = optimize_area(
        torus, refined_loop, args.length, embedded, args.maxiter
    )
    refined_metrics = diagnostics(torus, refined_loop, refined_result.x)
    refined_ok = admitted(refined_metrics, args.length, bool(refined_result.success))
    area_change = abs(float(refined_metrics["area"]) - float(base_metrics["area"])) / abs(
        float(base_metrics["area"])
    )
    print(
        "  area={:.10f} rel_change={:.2e} center theta={:+.6f}".format(
            float(refined_metrics["area"]),
            area_change,
            float(refined_metrics["theta_center"]),
        )
    )
    print(
        "  kappa mean={:+.8f} relative std={:.3e} J*L^3={:.3e}".format(
            float(refined_metrics["kappa_mean"]),
            float(refined_metrics["kappa_std_relative"]),
            float(refined_metrics["J_dimensionless"]),
        )
    )
    print(
        "  K=[{:+.6f},{:+.6f}] spread*L^2={:.3f} GB residual={:+.3e}".format(
            float(refined_metrics["K_min"]),
            float(refined_metrics["K_max"]),
            float(refined_metrics["K_spread_L2"]),
            float(refined_metrics["gauss_bonnet_residual"]),
        )
    )
    print(
        "  simple={} rotation={:.8f} optimizer_success={} admitted={}".format(
            refined_metrics["simple_in_chart"],
            float(refined_metrics["rotation_number"]),
            refined_result.success,
            refined_ok,
        )
    )

    constancy_pass = (
        float(refined_metrics["kappa_std_relative"]) < 2.0e-4
        and float(refined_metrics["J_dimensionless"]) < 2.0e-3
    )
    location_pass = abs(float(refined_metrics["theta_center"])) < 0.15
    resolution_pass = area_change < 5.0e-5
    overall = bool(
        max_reference_error < 1.0e-10
        and refined_ok
        and constancy_pass
        and location_pass
        and resolution_pass
    )
    print("\nVERDICT")
    print(
        "  {}: audited Fourier champion {} constant geodesic curvature; "
        "outer-equator location {}; refinement {}.".format(
            "PASS" if overall else "INCONCLUSIVE",
            "has" if constancy_pass else "does not yet have",
            "matches expectation" if location_pass else "is unexpected",
            "is stable" if resolution_pass else "needs more modes",
        )
    )
    print("  This is a numerical restricted-class result, not global certification.")

    payload = {
        "torus": asdict(torus),
        "target_length": args.length,
        "parallel_references": references,
        "base_metrics": base_metrics,
        "refined_metrics": refined_metrics,
        "area_relative_change": area_change,
        "optimizer_message": str(refined_result.message),
        "checks": {
            "parallel_reference": max_reference_error < 1.0e-10,
            "admitted": refined_ok,
            "constancy": constancy_pass,
            "outer_equator_location": location_pass,
            "resolution": resolution_pass,
            "overall": overall,
        },
        "scope": (
            "Contractible disk boundary in one unwrapped torus chart; "
            "Fourier multistart champion, not a proof of global optimality."
        ),
    }
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print("  JSON written to {}".format(args.json))
    return 0 if overall else 2


if __name__ == "__main__":
    raise SystemExit(main())

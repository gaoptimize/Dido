"""Dido relaxation on a standard hyperbolic cusp.

The cusp is [0,infinity) x S1 with

    g = dr^2 + exp(-2r) dtheta^2,    K = -1.

The selected region is the noncompact tail {r >= graph(theta)}, whose area is
finite.  Its Euler characteristic is zero.  Horocycles have kappa_g=+1 with
the tail-side convention, J=0, and tail area equal to boundary length.

The optimizer maximizes tail area at fixed boundary length within periodic
radial Fourier graphs.  This is numerical evidence in that restricted class.

Python 3.10+. Dependencies: NumPy and SciPy.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.optimize import minimize


Array = np.ndarray
TAU = 2.0 * math.pi


class CuspLoop:
    def __init__(self, modes: int, points: int):
        self.modes = int(modes)
        self.points = int(points)
        self.theta = np.linspace(0.0, TAU, points, endpoint=False)
        k = np.arange(1, modes + 1, dtype=float)
        self.cos = np.cos(np.outer(self.theta, k))
        self.sin = np.sin(np.outer(self.theta, k))
        self.cos_p = -self.sin * k
        self.sin_p = self.cos * k
        self.cos_pp = -self.cos * k**2
        self.sin_pp = -self.sin * k**2

    @property
    def coefficient_count(self) -> int:
        return 1 + 2 * self.modes

    def circle(self, radius: float) -> Array:
        result = np.zeros(self.coefficient_count)
        result[0] = radius
        return result

    def evaluate(self, coefficients: Array) -> tuple[Array, Array, Array]:
        m = self.modes
        radius = (coefficients[0] + self.cos @ coefficients[1:1 + m]
                  + self.sin @ coefficients[1 + m:1 + 2 * m])
        radius_t = (self.cos_p @ coefficients[1:1 + m]
                    + self.sin_p @ coefficients[1 + m:1 + 2 * m])
        radius_tt = (self.cos_pp @ coefficients[1:1 + m]
                     + self.sin_pp @ coefficients[1 + m:1 + 2 * m])
        return radius, radius_t, radius_tt


def periodic_derivative(values: Array) -> Array:
    frequencies = np.fft.fftfreq(len(values), d=1.0 / len(values))
    return np.fft.ifft(1j * frequencies * np.fft.fft(values)).real


def geometry(loop: CuspLoop, coefficients: Array) -> dict[str, Array]:
    radius, radius_t, radius_tt = loop.evaluate(coefficients)
    a = np.exp(-radius)
    speed = np.sqrt(radius_t**2 + a**2)
    accel_radius = radius_tt + a**2
    accel_theta = -2.0 * radius_t
    # Negative of the compact-core signed curvature: the selected side is
    # the noncompact cusp tail. A horocycle therefore has kappa_g=+1.
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        kappa_tail = -a * (
            radius_t * accel_theta - accel_radius
        ) / speed**3
    return {"radius": radius, "radius_t": radius_t, "speed": speed,
            "kappa_g": kappa_tail, "K": -np.ones_like(radius)}


def metric_length(loop: CuspLoop, coefficients: Array) -> float:
    return TAU * float(np.mean(geometry(loop, coefficients)["speed"]))


def tail_area(loop: CuspLoop, coefficients: Array) -> float:
    radius, _, _ = loop.evaluate(coefficients)
    return TAU * float(np.mean(np.exp(-radius)))


def jerk_energy(loop: CuspLoop, coefficients: Array) -> float:
    data = geometry(loop, coefficients)
    kappa_t = periodic_derivative(data["kappa_g"])
    return TAU * float(np.mean(kappa_t * kappa_t / data["speed"]))


def gauss_bonnet_residual(loop: CuspLoop, coefficients: Array) -> float:
    data = geometry(loop, coefficients)
    boundary = TAU * float(np.mean(data["kappa_g"] * data["speed"]))
    bulk = -tail_area(loop, coefficients)
    return boundary + bulk  # 2*pi*chi(cusp tail), chi=0


def weighted_mean(values: Array, weights: Array) -> float:
    return float(np.sum(values * weights) / np.sum(weights))


def weighted_std(values: Array, weights: Array) -> float:
    mean = weighted_mean(values, weights)
    return float(np.sqrt(np.sum(weights * (values - mean) ** 2)
                         / np.sum(weights)))


def optimize_tail(loop: CuspLoop, target_length: float, initial: Array,
                  maxiter: int = 500):
    def objective(c: Array) -> float:
        radius, _, _ = loop.evaluate(c)
        penalty = 0.0
        if np.min(radius) < 0.05:
            penalty += 1.0e5 * (0.05 - float(np.min(radius))) ** 2
        return -tail_area(loop, c) + penalty

    constraint = {"type": "eq",
                  "fun": lambda c: metric_length(loop, c) - target_length}
    bounds = [(0.05, 8.0)] + [(-0.75, 0.75)] * (2 * loop.modes)
    return minimize(objective, initial, method="SLSQP", bounds=bounds,
                    constraints=(constraint,),
                    options={"maxiter": maxiter, "ftol": 1.0e-13})


def diagnostics(loop: CuspLoop, coefficients: Array,
                target_length: float) -> dict[str, float | bool]:
    data = geometry(loop, coefficients)
    length = metric_length(loop, coefficients)
    area = tail_area(loop, coefficients)
    return {
        "length": length,
        "length_relative_error": abs(length - target_length) / target_length,
        "tail_area": area,
        "area_over_length": area / length,
        "kappa_g_mean": weighted_mean(data["kappa_g"], data["speed"]),
        "kappa_g_wstd": weighted_std(data["kappa_g"], data["speed"]),
        "J": jerk_energy(loop, coefficients),
        "gauss_bonnet_residual_chi0": gauss_bonnet_residual(loop, coefficients),
        "minimum_radius": float(np.min(data["radius"])),
        "maximum_radius": float(np.max(data["radius"])),
        "noncompact_region": True,
    }


def run_case(target_length: float, modes: int, points: int,
             starts: int, seed: int) -> dict[str, object]:
    loop = CuspLoop(modes, points)
    exact_radius = math.log(TAU / target_length)
    exact = loop.circle(exact_radius)
    exact_metrics = diagnostics(loop, exact, target_length)
    rng = np.random.default_rng(seed + int(round(1000.0 * target_length)))
    attempts = []
    candidates = []
    for index in range(starts):
        initial = exact.copy()
        if index:
            perturb = rng.normal(0.0, 0.025, 2 * modes)
            perturb /= np.arange(1, 2 * modes + 1)
            initial[1:] = perturb
            # Raise the mean radius until the perturbed curve is close to the
            # target length before constrained optimization.
            for _ in range(8):
                initial[0] += math.log(metric_length(loop, initial) / target_length)
        result = optimize_tail(loop, target_length, initial)
        metrics = diagnostics(loop, result.x, target_length)
        admitted = bool(
            result.success
            and metrics["length_relative_error"] < 2.0e-8
            and metrics["minimum_radius"] > 0.0
            and abs(metrics["gauss_bonnet_residual_chi0"]) < 2.0e-8
        )
        attempts.append({"index": index, "success": bool(result.success),
                         "iterations": int(result.nit), "admitted": admitted,
                         "metrics": metrics})
        if admitted:
            candidates.append((float(metrics["tail_area"]), result.x.copy(), metrics))
    candidates.sort(key=lambda item: item[0], reverse=True)
    best = candidates[0] if candidates else None
    if best is None:
        return {"target_length": target_length, "status": "optimizer_inconclusive",
                "attempts": attempts}
    coefficients = best[1]
    nonconstant_norm = float(np.linalg.norm(coefficients[1:]))
    metrics = best[2]
    gates = {
        "U0_OPTIMIZER": len(candidates) > 0,
        "U1_EXACT_LENGTH": metrics["length_relative_error"] < 2.0e-8,
        "U2_NONCOMPACT_FINITE_AREA": bool(metrics["noncompact_region"]
                                            and np.isfinite(metrics["tail_area"])),
        "U3_GAUSS_BONNET_CHI0": abs(metrics["gauss_bonnet_residual_chi0"]) < 2.0e-8,
        "U4_HOROCYCLE_RECOVERY": nonconstant_norm < 2.0e-5,
        "U5_AREA_EQUALS_LENGTH": abs(metrics["area_over_length"] - 1.0) < 2.0e-8,
        "U6_ZERO_J": metrics["J"] < 2.0e-7,
    }
    return {"target_length": target_length, "status": "pass" if all(gates.values())
            else "fail", "exact_radius": exact_radius,
            "exact_reference": exact_metrics, "best_metrics": metrics,
            "nonconstant_coefficient_norm": nonconstant_norm,
            "gates": gates, "attempts": attempts}


def run_experiment(lengths: tuple[float, ...] = (0.5, 1.0, 2.0),
                   modes: int = 6, points: int = 1024, starts: int = 4,
                   seed: int = 20260909) -> dict[str, object]:
    cases = [run_case(length, modes, points, starts, seed) for length in lengths]
    all_pass = all(case.get("status") == "pass" for case in cases)
    return {"program": "dido_cusp.py", "surface": "standard hyperbolic cusp",
            "scope": "noncompact cusp-tail regions bounded by winding-one Fourier graphs",
            "euler_characteristic": 0, "cases": cases,
            "all_gates_pass": all_pass,
            "verdict": (
                "The relaxation recovers horocycles. Each selected region is "
                "noncompact but finite-area, with A=L, constant kappa_g=1, J=0, "
                "and Gauss-Bonnet closing at chi=0."
            )}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lengths", type=float, nargs="+", default=[0.5, 1.0, 2.0])
    parser.add_argument("--modes", type=int, default=6)
    parser.add_argument("--points", type=int, default=1024)
    parser.add_argument("--starts", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20260909)
    parser.add_argument("--json", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_experiment(tuple(args.lengths), args.modes, args.points,
                            args.starts, args.seed)
    print("=" * 100)
    print("HYPERBOLIC CUSP  noncompact finite-area tail regions")
    print("=" * 100)
    for case in report["cases"]:
        if case["status"] == "optimizer_inconclusive":
            print("L={:.3f} optimizer inconclusive".format(case["target_length"]))
            continue
        m = case["best_metrics"]
        print("L={:.3f} A={:.9f} A/L={:.9f} kg={:.9f} J={:.3e} "
              "GB(chi=0)={:+.2e} coeff={:.2e}".format(
                  case["target_length"], m["tail_area"], m["area_over_length"],
                  m["kappa_g_mean"], m["J"], m["gauss_bonnet_residual_chi0"],
                  case["nonconstant_coefficient_norm"]))
        for name, passed in case["gates"].items():
            print("  [{}] {}".format("PASS" if passed else "FAIL", name))
    print("VERDICT: " + report["verdict"])
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True),
                             encoding="utf-8")
        print("Wrote {}".format(args.json))
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

"""Fixed-length Dido relaxation on the paraboloid z=x^2+y^2.

In polar coordinates (r,theta),

    g = (1+4r^2) dr^2 + r^2 dtheta^2,
    K = 4/(1+4r^2)^2.

The program maximizes intrinsic disk area at fixed boundary length within
winding-one radial Fourier graphs.  Rotational circles are the known-answer
positive control on a complete noncompact surface.

Python 3.10+. Dependencies: NumPy and SciPy.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.optimize import minimize


Array = np.ndarray
TAU = 2.0 * math.pi


class RadialLoop:
    def __init__(self, modes: int, points: int):
        self.modes = int(modes)
        self.points = int(points)
        self.theta = np.linspace(0.0, TAU, points, endpoint=False)
        k = np.arange(1, modes + 1, dtype=float)
        self.cos = np.cos(np.outer(self.theta, k))
        self.sin = np.sin(np.outer(self.theta, k))
        self.cos_p = -self.sin * k
        self.sin_p = self.cos * k
        self.cos_pp = -self.cos * k**2
        self.sin_pp = -self.sin * k**2

    @property
    def coefficient_count(self) -> int:
        return 1 + 2 * self.modes

    def circle(self, radius: float) -> Array:
        result = np.zeros(self.coefficient_count)
        result[0] = radius
        return result

    def evaluate(self, coefficients: Array) -> tuple[Array, Array, Array]:
        m = self.modes
        radius = (coefficients[0] + self.cos @ coefficients[1:1 + m]
                  + self.sin @ coefficients[1 + m:1 + 2 * m])
        radius_t = (self.cos_p @ coefficients[1:1 + m]
                    + self.sin_p @ coefficients[1 + m:1 + 2 * m])
        radius_tt = (self.cos_pp @ coefficients[1:1 + m]
                     + self.sin_pp @ coefficients[1 + m:1 + 2 * m])
        return radius, radius_t, radius_tt


def area_primitive(radius: Array | float) -> Array:
    r = np.asarray(radius, dtype=float)
    return ((1.0 + 4.0 * r * r) ** 1.5 - 1.0) / 12.0


def gaussian_curvature(radius: Array | float) -> Array:
    r = np.asarray(radius, dtype=float)
    return 4.0 / (1.0 + 4.0 * r * r) ** 2


def bulk_curvature_primitive(radius: Array | float) -> Array:
    r = np.asarray(radius, dtype=float)
    return 1.0 - 1.0 / np.sqrt(1.0 + 4.0 * r * r)


def periodic_derivative(values: Array) -> Array:
    frequencies = np.fft.fftfreq(len(values), d=1.0 / len(values))
    return np.fft.ifft(1j * frequencies * np.fft.fft(values)).real


def geometry(loop: RadialLoop, coefficients: Array) -> dict[str, Array]:
    radius, radius_t, radius_tt = loop.evaluate(coefficients)
    E = 1.0 + 4.0 * radius * radius
    speed = np.sqrt(E * radius_t**2 + radius**2)
    accel_radius = radius_tt + (4.0 * radius / E) * radius_t**2 - radius / E
    accel_theta = 2.0 * radius_t / radius
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        kappa_g = radius * np.sqrt(E) * (
            radius_t * accel_theta - accel_radius
        ) / speed**3
    return {"radius": radius, "radius_t": radius_t, "speed": speed,
            "kappa_g": kappa_g, "K": gaussian_curvature(radius)}


def metric_length(loop: RadialLoop, coefficients: Array) -> float:
    return TAU * float(np.mean(geometry(loop, coefficients)["speed"]))


def enclosed_area(loop: RadialLoop, coefficients: Array) -> float:
    radius, _, _ = loop.evaluate(coefficients)
    return TAU * float(np.mean(area_primitive(radius)))


def region_curvature_integral(loop: RadialLoop, coefficients: Array) -> float:
    radius, _, _ = loop.evaluate(coefficients)
    return TAU * float(np.mean(bulk_curvature_primitive(radius)))


def jerk_energy(loop: RadialLoop, coefficients: Array) -> float:
    data = geometry(loop, coefficients)
    derivative = periodic_derivative(data["kappa_g"])
    return TAU * float(np.mean(derivative * derivative / data["speed"]))


def gauss_bonnet_residual(loop: RadialLoop, coefficients: Array) -> float:
    data = geometry(loop, coefficients)
    boundary = TAU * float(np.mean(data["kappa_g"] * data["speed"]))
    return boundary + region_curvature_integral(loop, coefficients) - TAU


def weighted_mean(values: Array, weights: Array) -> float:
    return float(np.sum(values * weights) / np.sum(weights))


def weighted_std(values: Array, weights: Array) -> float:
    mean = weighted_mean(values, weights)
    return float(np.sqrt(np.sum(weights * (values - mean) ** 2)
                         / np.sum(weights)))


def optimize_area(loop: RadialLoop, target_length: float, initial: Array,
                  maxiter: int = 600):
    def objective(c: Array) -> float:
        radius, _, _ = loop.evaluate(c)
        penalty = 0.0
        if np.min(radius) < 0.03:
            penalty += 1.0e6 * (0.03 - float(np.min(radius))) ** 2
        return -enclosed_area(loop, c) + penalty

    constraint = {"type": "eq",
                  "fun": lambda c: metric_length(loop, c) - target_length}
    bounds = [(0.03, 4.0)] + [(-0.75, 0.75)] * (2 * loop.modes)
    return minimize(objective, initial, method="SLSQP", bounds=bounds,
                    constraints=(constraint,),
                    options={"maxiter": maxiter, "ftol": 1.0e-13})


def diagnostics(loop: RadialLoop, coefficients: Array,
                target_length: float) -> dict[str, float]:
    data = geometry(loop, coefficients)
    length = metric_length(loop, coefficients)
    kmean = weighted_mean(data["kappa_g"], data["speed"])
    kstd = weighted_std(data["kappa_g"], data["speed"])
    return {"length": length,
            "length_relative_error": abs(length - target_length) / target_length,
            "area": enclosed_area(loop, coefficients),
            "kappa_g_mean": kmean, "kappa_g_wstd": kstd,
            "kappa_constancy_relative": kstd / max(abs(kmean), 1.0e-15),
            "K_min": float(np.min(data["K"])),
            "K_max": float(np.max(data["K"])),
            "J": jerk_energy(loop, coefficients),
            "gauss_bonnet_residual": gauss_bonnet_residual(loop, coefficients),
            "minimum_radius": float(np.min(data["radius"])),
            "maximum_radius": float(np.max(data["radius"]))}


def circle_reference(length: float, modes: int = 4,
                     points: int = 2048) -> dict[str, float]:
    loop = RadialLoop(modes, points)
    radius = length / TAU
    coefficients = loop.circle(radius)
    metrics = diagnostics(loop, coefficients, length)
    E = 1.0 + 4.0 * radius**2
    metrics.update({"radius_exact": radius,
                    "area_exact": TAU * float(area_primitive(radius)),
                    "kappa_exact": 1.0 / (radius * math.sqrt(E)),
                    "K_exact": 4.0 / E**2})
    return metrics


def run_case(length: float, modes: int, points: int,
             starts: int, seed: int) -> dict[str, object]:
    loop = RadialLoop(modes, points)
    radius = length / TAU
    exact = loop.circle(radius)
    reference = circle_reference(length, modes, points)
    rng = np.random.default_rng(seed + int(round(length * 1000.0)))
    attempts = []
    admitted = []
    for index in range(starts):
        initial = exact.copy()
        if index:
            noise = rng.normal(0.0, 0.018 * radius, 2 * modes)
            noise /= np.tile(np.arange(1, modes + 1), 2) ** 2
            initial[1:] = noise
            initial[0] = radius
        result = optimize_area(loop, length, initial)
        metrics = diagnostics(loop, result.x, length)
        ok = bool(result.success
                  and metrics["length_relative_error"] < 2.0e-8
                  and metrics["minimum_radius"] > 0.0
                  and abs(metrics["gauss_bonnet_residual"]) < 2.0e-8)
        attempts.append({"index": index, "success": bool(result.success),
                         "iterations": int(result.nit), "admitted": ok,
                         "metrics": metrics})
        if ok:
            admitted.append((metrics["area"], result.x.copy(), metrics))
    admitted.sort(key=lambda item: item[0], reverse=True)
    if not admitted:
        return {"length": length, "status": "optimizer_inconclusive",
                "reference": reference, "attempts": attempts}
    _, coefficients, metrics = admitted[0]
    shape_norm = float(np.linalg.norm(coefficients[1:]))
    gates = {
        "P0_OPTIMIZER": True,
        "P1_EXACT_LENGTH": metrics["length_relative_error"] < 2.0e-8,
        "P2_GAUSS_BONNET": abs(metrics["gauss_bonnet_residual"]) < 2.0e-8,
        "P3_CIRCLE_RECOVERY": shape_norm < 2.0e-5,
        "P4_AREA_KAT": abs(metrics["area"] - reference["area_exact"])
                       / reference["area_exact"] < 2.0e-8,
        "P5_CONSTANT_KAPPA": metrics["kappa_constancy_relative"] < 2.0e-5,
        "P6_ZERO_J": metrics["J"] < 2.0e-6,
        "P7_NO_ESCAPE": metrics["maximum_radius"] < 1.1 * radius,
    }
    return {"length": length, "status": "pass" if all(gates.values()) else "fail",
            "reference": reference, "best_metrics": metrics,
            "nonconstant_coefficient_norm": shape_norm,
            "gates": gates, "attempts": attempts}


def run_experiment(lengths: tuple[float, ...] = (3.0, 6.0, 9.0),
                   modes: int = 6, points: int = 1024,
                   starts: int = 4, seed: int = 20260909) -> dict[str, object]:
    cases = [run_case(length, modes, points, starts, seed) for length in lengths]
    return {"program": "dido_paraboloid.py", "surface": "z=x^2+y^2 paraboloid",
            "scope": "embedded winding-one radial Fourier graphs",
            "cases": cases,
            "all_gates_pass": all(case.get("status") == "pass" for case in cases),
            "verdict": (
                "Unlike the horn and cigar, this complete noncompact surface "
                "retains the optimizer in a compact radial range. The relaxation "
                "recovers rotational circles with constant geodesic curvature and J=0."
            )}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lengths", type=float, nargs="+", default=[3.0, 6.0, 9.0])
    parser.add_argument("--modes", type=int, default=6)
    parser.add_argument("--points", type=int, default=1024)
    parser.add_argument("--starts", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20260909)
    parser.add_argument("--json", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_experiment(tuple(args.lengths), args.modes, args.points,
                            args.starts, args.seed)
    print("=" * 100)
    print("PARABOLOID z=x^2+y^2  complete noncompact positive control")
    print("=" * 100)
    for case in report["cases"]:
        if case["status"] == "optimizer_inconclusive":
            print("L={} optimizer inconclusive".format(case["length"]))
            continue
        metrics = case["best_metrics"]
        print("L={:.3f} A={:.9f} kg={:.9f} relstd={:.2e} J={:.3e} "
              "GB={:+.2e} coeff={:.2e}".format(
                  case["length"], metrics["area"], metrics["kappa_g_mean"],
                  metrics["kappa_constancy_relative"], metrics["J"],
                  metrics["gauss_bonnet_residual"],
                  case["nonconstant_coefficient_norm"]))
        for name, passed in case["gates"].items():
            print("  [{}] {}".format("PASS" if passed else "FAIL", name))
    print("VERDICT: " + report["verdict"])
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print("Wrote {}".format(args.json))
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

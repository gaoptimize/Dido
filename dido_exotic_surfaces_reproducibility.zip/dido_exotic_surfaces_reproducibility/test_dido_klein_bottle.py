import unittest

import numpy as np

import dido_klein_bottle as klein


class KleinBottleTests(unittest.TestCase):
    def setUp(self):
        self.surface = klein.FlatKleinBottle(4.0, 6.0)

    def test_orientation_cover_involution(self):
        points = np.array([[0.2, 0.7], [1.1, 2.3], [3.8, 5.9]])
        np.testing.assert_allclose(
            self.surface.deck(self.surface.deck(points)), points, atol=1.0e-14)
        self.assertEqual(self.surface.cover_area, 2.0 * self.surface.area)

    def test_candidate_topologies(self):
        disk, complement, side_a, side_b, one_sided = klein.candidates(
            self.surface, 2.0)
        self.assertTrue(disk.orientable_region)
        self.assertFalse(complement.orientable_region)
        self.assertEqual(disk.euler_characteristic, 1)
        self.assertEqual(complement.euler_characteristic, -1)
        self.assertEqual(side_a.euler_characteristic, 0)
        self.assertEqual(side_b.euler_characteristic, 0)
        self.assertFalse(one_sided.admissible_region)

    def test_cover_area_accounting(self):
        for row in klein.candidates(self.surface, 2.0):
            if row.selected_area is not None:
                self.assertAlmostEqual(float(row.lifted_area),
                                       2.0 * float(row.selected_area))

    def test_full_experiment(self):
        report = klein.run_experiment(self.surface, points=2048)
        self.assertTrue(report["all_gates_pass"], report["gates"])


if __name__ == "__main__":
    unittest.main()

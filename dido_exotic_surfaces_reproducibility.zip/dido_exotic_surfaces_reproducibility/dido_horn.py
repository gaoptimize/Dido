"""Fixed-length Dido stress test on a smoothly capped Gabriel horn.

The horn tail is the surface of revolution of y=1/x, x >= 1:

    g = (1 + x^-4) dx^2 + x^-2 dtheta^2.

The unspecified compact cap contributes additive constants to area and total
Gaussian curvature.  Those constants are fixed by smooth pole closure and do
not affect optimization or area differences.  Candidate boundaries are
star-shaped winding-one graphs x(theta).  This is a numerical stress test, not
a proof over all embedded curves.

The main experiment solves the length constraint exactly for

    x(theta) = X + A cos(theta)

at successively larger X.  The enclosed area grows without bound while length
remains fixed, exposing failure of compactness/attainment on this ambient
surface.

Python 3.10+. Dependencies: NumPy and SciPy.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.optimize import brentq


Array = np.ndarray
TAU = 2.0 * math.pi


@dataclass(frozen=True)
class HornMetric:
    join_x: float = 1.0

    def __post_init__(self) -> None:
        if self.join_x != 1.0:
            raise ValueError("the certified cap constants currently require join_x=1")

    @staticmethod
    def E(x: Array | float) -> Array:
        value = np.asarray(x, dtype=float)
        return 1.0 + value**-4

    @staticmethod
    def G(x: Array | float) -> Array:
        value = np.asarray(x, dtype=float)
        return value**-2

    @staticmethod
    def gaussian_curvature(x: Array | float) -> Array:
        value = np.asarray(x, dtype=float)
        return -2.0 * value**6 / (1.0 + value**4) ** 2

    @staticmethod
    def area_density(x: Array | float) -> Array:
        value = np.asarray(x, dtype=float)
        return np.sqrt(1.0 + value**-4) / value

    @staticmethod
    def tail_area_primitive(x: Array | float) -> Array:
        """Integral of area density from x=1 to x, evaluated stably."""
        value = np.asarray(x, dtype=float)
        u = value**-2
        root = np.sqrt(1.0 + u * u)
        raw = -0.5 * (root + np.log(u / (1.0 + root)))
        root1 = math.sqrt(2.0)
        at_one = -0.5 * (root1 + math.log(1.0 / (1.0 + root1)))
        return raw - at_one

    @staticmethod
    def bulk_curvature_primitive(x: Array | float) -> Array:
        """Total K dA per unit theta from the cap pole through tail point x.

        Smooth pole closure gives the cap contribution 1+1/sqrt(2).  Adding
        the tail integral leaves 1+1/sqrt(x^4+1).
        """
        value = np.asarray(x, dtype=float)
        return 1.0 + 1.0 / np.sqrt(value**4 + 1.0)


class WindingGraph:
    """A winding-one radial graph sampled uniformly in theta."""

    def __init__(self, center: float, cosine_amplitude: float, points: int):
        if points < 64 or points % 2:
            raise ValueError("points must be an even integer >= 64")
        self.center = float(center)
        self.amplitude = float(cosine_amplitude)
        self.points = int(points)
        self.theta = np.linspace(0.0, TAU, points, endpoint=False)

    def samples(self) -> tuple[Array, Array, Array]:
        x = self.center + self.amplitude * np.cos(self.theta)
        x_t = -self.amplitude * np.sin(self.theta)
        x_tt = -self.amplitude * np.cos(self.theta)
        return x, x_t, x_tt


def periodic_derivative(values: Array) -> Array:
    frequencies = np.fft.fftfreq(len(values), d=1.0 / len(values))
    return np.fft.ifft(1j * frequencies * np.fft.fft(values)).real


def geometry(metric: HornMetric, graph: WindingGraph) -> dict[str, Array]:
    x, x_t, x_tt = graph.samples()
    theta_t = np.ones_like(x)
    theta_tt = np.zeros_like(x)
    E = metric.E(x)
    G = metric.G(x)
    speed = np.sqrt(E * x_t * x_t + G * theta_t * theta_t)

    # Christoffel symbols for diag(E(x), G(x)).
    gamma_x_xx = -2.0 / (x * (x**4 + 1.0))
    gamma_x_tt = x / (x**4 + 1.0)
    gamma_t_xt = -1.0 / x
    accel_x = x_tt + gamma_x_xx * x_t**2 + gamma_x_tt * theta_t**2
    accel_t = theta_tt + 2.0 * gamma_t_xt * x_t * theta_t
    signed_area_density = np.sqrt(E * G)
    with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
        kappa_g = signed_area_density * (
            x_t * accel_t - theta_t * accel_x
        ) / speed**3
    return {
        "x": x,
        "x_t": x_t,
        "speed": speed,
        "kappa_g": kappa_g,
        "K": metric.gaussian_curvature(x),
    }


def metric_length(metric: HornMetric, graph: WindingGraph) -> float:
    return TAU * float(np.mean(geometry(metric, graph)["speed"]))


def enclosed_tail_area(metric: HornMetric, graph: WindingGraph) -> float:
    x, _, _ = graph.samples()
    return TAU * float(np.mean(metric.tail_area_primitive(x)))


def region_curvature_integral(metric: HornMetric, graph: WindingGraph) -> float:
    x, _, _ = graph.samples()
    return TAU * float(np.mean(metric.bulk_curvature_primitive(x)))


def jerk_energy(metric: HornMetric, graph: WindingGraph) -> float:
    data = geometry(metric, graph)
    kappa_t = periodic_derivative(data["kappa_g"])
    return TAU * float(np.mean(kappa_t * kappa_t / data["speed"]))


def gauss_bonnet_residual(metric: HornMetric, graph: WindingGraph) -> float:
    data = geometry(metric, graph)
    boundary = TAU * float(np.mean(data["kappa_g"] * data["speed"]))
    return boundary + region_curvature_integral(metric, graph) - TAU


def weighted_mean(values: Array, weights: Array) -> float:
    return float(np.sum(values * weights) / np.sum(weights))


def weighted_std(values: Array, weights: Array) -> float:
    mean = weighted_mean(values, weights)
    return float(np.sqrt(np.sum(weights * (values - mean) ** 2)
                         / np.sum(weights)))


def parallel_reference(metric: HornMetric, x: float,
                       points: int = 2048) -> dict[str, float]:
    graph = WindingGraph(x, 0.0, points)
    data = geometry(metric, graph)
    exact_kappa = -x / math.sqrt(x**4 + 1.0)
    exact_K = -2.0 * x**6 / (1.0 + x**4) ** 2
    return {
        "x": float(x),
        "length_numeric": metric_length(metric, graph),
        "length_exact": TAU / x,
        "kappa_numeric": weighted_mean(data["kappa_g"], data["speed"]),
        "kappa_exact": exact_kappa,
        "K_numeric": weighted_mean(data["K"], data["speed"]),
        "K_exact": exact_K,
        "J": jerk_energy(metric, graph),
        "gauss_bonnet_residual": gauss_bonnet_residual(metric, graph),
    }


def solve_exact_length(metric: HornMetric, center: float, target_length: float,
                       points: int) -> WindingGraph:
    """Solve for A in x=center+A cos(theta) with exact target length."""
    if TAU / center >= target_length:
        raise ValueError("center must have parallel length below target")

    def residual(amplitude: float) -> float:
        return metric_length(metric, WindingGraph(center, amplitude, points)) \
            - target_length

    low = 0.0
    high = 0.25 * target_length
    while residual(high) <= 0.0:
        high *= 1.5
    if center - high <= metric.join_x:
        raise ValueError("center too small for an admissible exact-length graph")
    amplitude = brentq(residual, low, high, xtol=2.0e-14, rtol=1.0e-14)
    return WindingGraph(center, amplitude, points)


def diagnostics(metric: HornMetric, graph: WindingGraph,
                target_length: float) -> dict[str, float | bool]:
    data = geometry(metric, graph)
    length = metric_length(metric, graph)
    area = enclosed_tail_area(metric, graph)
    J = jerk_energy(metric, graph)
    gb = gauss_bonnet_residual(metric, graph)
    return {
        "center": graph.center,
        "amplitude": graph.amplitude,
        "minimum_x": float(np.min(data["x"])),
        "maximum_x": float(np.max(data["x"])),
        "length": length,
        "length_relative_error": abs(length - target_length) / target_length,
        "enclosed_tail_area": area,
        "kappa_g_mean": weighted_mean(data["kappa_g"], data["speed"]),
        "kappa_g_wstd": weighted_std(data["kappa_g"], data["speed"]),
        "K_min": float(np.min(data["K"])),
        "K_max": float(np.max(data["K"])),
        "J": J,
        "gauss_bonnet_residual": gb,
        "admissible": bool(np.min(data["x"]) > metric.join_x),
    }


def resolution_pair(metric: HornMetric, center: float, target_length: float,
                    points: int) -> tuple[dict[str, float | bool],
                                          dict[str, float | bool]]:
    low_graph = solve_exact_length(metric, center, target_length, points)
    high_graph = solve_exact_length(metric, center, target_length, 2 * points)
    return (diagnostics(metric, low_graph, target_length),
            diagnostics(metric, high_graph, target_length))


def run_experiment(target_length: float = 6.0,
                   centers: tuple[float, ...] = (8.0, 16.0, 32.0, 64.0, 128.0),
                   points: int = 2048) -> dict[str, object]:
    metric = HornMetric()
    references = [parallel_reference(metric, x, points) for x in (1.0, 2.0, 8.0)]
    rows: list[dict[str, float | bool]] = []
    resolution_rows: list[dict[str, float]] = []
    for center in centers:
        low, high = resolution_pair(metric, center, target_length, points)
        rows.append(high)
        resolution_rows.append({
            "center": center,
            "area_absolute_difference": abs(
                float(high["enclosed_tail_area"])
                - float(low["enclosed_tail_area"])
            ),
            "J_relative_difference": abs(float(high["J"]) - float(low["J"]))
            / max(abs(float(high["J"])), 1.0e-30),
            "gb_high": abs(float(high["gauss_bonnet_residual"])),
        })

    areas = np.array([float(row["enclosed_tail_area"]) for row in rows])
    log_centers = np.log(np.asarray(centers, dtype=float))
    slope, intercept = np.polyfit(log_centers, areas, 1)
    all_lengths = all(float(row["length_relative_error"]) <= 2.0e-12 for row in rows)
    all_admissible = all(bool(row["admissible"]) for row in rows)
    all_gb = all(abs(float(row["gauss_bonnet_residual"])) <= 1.0e-8 for row in rows)
    resolution_ok = all(
        row["area_absolute_difference"] <= 1.0e-9
        and row["J_relative_difference"] <= 1.0e-2
        and row["gb_high"] <= 1.0e-8
        for row in resolution_rows
    )
    monotone_area = bool(np.all(np.diff(areas) > 0.0))
    parallel_ok = all(
        abs(ref["length_numeric"] - ref["length_exact"]) <= 1.0e-12
        and abs(ref["kappa_numeric"] - ref["kappa_exact"]) <= 1.0e-12
        and abs(ref["K_numeric"] - ref["K_exact"]) <= 1.0e-12
        and ref["J"] <= 1.0e-20
        and abs(ref["gauss_bonnet_residual"]) <= 1.0e-12
        for ref in references
    )
    # Area should grow as 2*pi*log(center) plus bounded corrections.
    asymptotic_ok = abs(float(slope) - TAU) / TAU <= 0.03
    gates = {
        "H0_PARALLEL_KAT": parallel_ok,
        "H1_EXACT_LENGTH": all_lengths,
        "H2_ADMISSIBLE_GRAPH": all_admissible,
        "H3_GAUSS_BONNET": all_gb,
        "H4_AREA_STRICTLY_GROWS": monotone_area,
        "H5_LOG_AREA_SLOPE": asymptotic_ok,
        "H6_RESOLUTION": resolution_ok,
    }
    return {
        "program": "dido_horn.py",
        "surface": "smoothly capped Gabriel horn with tail y=1/x",
        "scope": "winding-one star-shaped Fourier graphs; numerical stress test",
        "target_length": target_length,
        "points_reported": 2 * points,
        "centers": list(centers),
        "parallel_references": references,
        "escape_sequence": rows,
        "resolution": resolution_rows,
        "area_fit": {
            "model": "area = slope*log(center)+intercept",
            "slope": float(slope),
            "expected_slope": TAU,
            "intercept": float(intercept),
        },
        "gates": gates,
        "all_gates_pass": all(gates.values()),
        "verdict": (
            "Fixed-length admissible boundaries escape down the horn while "
            "enclosed area grows logarithmically. The numerical problem has no "
            "finite global champion in this tested family."
        ),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--length", type=float, default=6.0)
    parser.add_argument("--centers", type=float, nargs="+",
                        default=[8.0, 16.0, 32.0, 64.0, 128.0])
    parser.add_argument("--points", type=int, default=2048)
    parser.add_argument("--json", type=Path, help="write full JSON report")
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    report = run_experiment(args.length, tuple(args.centers), args.points)
    print("=" * 92)
    print("CAPPED GABRIEL HORN  fixed length = {:.6g}".format(args.length))
    print("=" * 92)
    for row in report["escape_sequence"]:
        print("X={center:>7.1f} A={amplitude:.9f} L={length:.12f} "
              "area_tail={enclosed_tail_area:.9f} J={J:.4e} "
              "GB={gauss_bonnet_residual:+.2e}".format(**row))
    print("area/log(X) fitted slope = {:.9f}; expected 2*pi = {:.9f}".format(
        report["area_fit"]["slope"], TAU))
    for name, passed in report["gates"].items():
        print("[{}] {}".format("PASS" if passed else "FAIL", name))
    print("VERDICT: " + report["verdict"])
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True),
                             encoding="utf-8")
        print("Wrote {}".format(args.json))
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

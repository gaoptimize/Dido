"""Orientation-cover and region-topology audit for a flat Klein bottle.

Use the flat torus R2/(a Z x b Z) as the orientation double cover and quotient
by the free orientation-reversing involution

    tau(x,y) = (x + a/2, b - y).

The experiment checks contractible disks and complements, a separating
two-sided geodesic whose sides are Moebius bands, and a one-sided geodesic that
cannot be the boundary of a selected region.

Python 3.10+. Dependency: NumPy.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


TAU = 2.0 * math.pi


@dataclass(frozen=True)
class FlatKleinBottle:
    cover_width: float = 4.0
    cover_height: float = 6.0

    def __post_init__(self) -> None:
        if not self.cover_width > 0.0 or not self.cover_height > 0.0:
            raise ValueError("cover periods must be positive")

    @property
    def cover_area(self) -> float:
        return self.cover_width * self.cover_height

    @property
    def area(self) -> float:
        return 0.5 * self.cover_area

    @property
    def shortest_closed_geodesic(self) -> float:
        return min(0.5 * self.cover_width, self.cover_height)

    @property
    def injectivity_radius(self) -> float:
        return 0.5 * self.shortest_closed_geodesic

    def deck(self, points: np.ndarray) -> np.ndarray:
        result = np.empty_like(points, dtype=float)
        result[..., 0] = np.mod(points[..., 0] + 0.5 * self.cover_width,
                                self.cover_width)
        result[..., 1] = np.mod(self.cover_height - points[..., 1],
                                self.cover_height)
        return result


@dataclass(frozen=True)
class Candidate:
    name: str
    selected_region: str
    orientable_region: bool | None
    boundary_sidedness: str
    boundary_components: int
    euler_characteristic: int | None
    boundary_length: float
    selected_area: float | None
    lifted_area: float | None
    lifted_boundary_components: int | None
    J: float
    gauss_bonnet_residual: float | None
    admissible_region: bool
    note: str


def circle_sample(length: float, points: int = 4096) -> dict[str, float]:
    radius = length / TAU
    theta = np.linspace(0.0, TAU, points, endpoint=False)
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    xp = -radius * np.sin(theta)
    yp = radius * np.cos(theta)
    xpp = -radius * np.cos(theta)
    ypp = -radius * np.sin(theta)
    speed = np.hypot(xp, yp)
    curvature = (xp * ypp - yp * xpp) / speed**3
    derivative = np.fft.ifft(
        1j * np.fft.fftfreq(points, d=1.0 / points) * np.fft.fft(curvature)
    ).real
    return {"length": TAU * float(np.mean(speed)),
            "area": 0.5 * TAU * float(np.mean(x * yp - y * xp)),
            "kappa_g": float(np.mean(curvature)),
            "J": TAU * float(np.mean(derivative * derivative / speed))}


def candidates(surface: FlatKleinBottle, disk_length: float) -> list[Candidate]:
    radius = disk_length / TAU
    if radius >= surface.injectivity_radius:
        raise ValueError("disk exceeds the injectivity-radius chart")
    disk_area = math.pi * radius**2
    disk = Candidate(
        "contractible_disk", "disk", True, "two-sided", 1, 1,
        disk_length, disk_area, 2.0 * disk_area, 2, 0.0, 0.0, True,
        "The disk has two disjoint lifts to the orientation cover.")
    complement = Candidate(
        "disk_complement", "punctured Klein bottle", False, "two-sided", 1, -1,
        disk_length, surface.area - disk_area,
        2.0 * (surface.area - disk_area), 2, 0.0, 0.0, True,
        "Same boundary, opposite selected side; the region is nonorientable.")
    moebius_a = Candidate(
        "moebius_side_A", "Moebius band", False, "two-sided", 1, 0,
        surface.cover_width, 0.5 * surface.area, surface.area, 2,
        0.0, 0.0, True,
        "A separating geodesic cuts the Klein bottle into two Moebius bands.")
    moebius_b = Candidate(
        "moebius_side_B", "Moebius band", False, "two-sided", 1, 0,
        surface.cover_width, 0.5 * surface.area, surface.area, 2,
        0.0, 0.0, True,
        "The other selected side of the same geodesic.")
    one_sided = Candidate(
        "one_sided_core", "no selected region", None, "one-sided", 1, None,
        0.5 * surface.cover_width, None, None, 1, 0.0, None, False,
        "The normal reverses after one circuit; this curve is not a region boundary.")
    return [disk, complement, moebius_a, moebius_b, one_sided]


def run_experiment(surface: FlatKleinBottle = FlatKleinBottle(),
                   disk_length: float = 2.0,
                   points: int = 4096) -> dict[str, object]:
    rows = candidates(surface, disk_length)
    disk, complement, side_a, side_b, one_sided = rows
    sample = circle_sample(disk_length, points)
    probe = np.array([[0.2, 0.7], [1.1, 2.3], [3.8, 5.9]])
    twice = surface.deck(surface.deck(probe))
    deck_order_two = bool(np.allclose(twice, np.mod(
        probe, [surface.cover_width, surface.cover_height]), atol=1.0e-14))
    gates = {
        "K0_DECK_INVOLUTION": deck_order_two,
        "K1_DECK_REVERSES_ORIENTATION": True,  # derivative diag(1,-1), det=-1
        "K2_COVER_AREA_FACTOR": surface.cover_area == 2.0 * surface.area,
        "K3_DISK_NUMERIC_KAT": (
            abs(sample["length"] - disk_length) < 1.0e-12
            and abs(sample["area"] - float(disk.selected_area)) < 1.0e-12
            and sample["J"] < 1.0e-20
        ),
        "K4_LIFT_AREA_FACTOR": all(
            row.lifted_area is None
            or abs(row.lifted_area - 2.0 * float(row.selected_area)) < 1.0e-12
            for row in rows
        ),
        "K5_SAME_BOUNDARY_DIFFERENT_TOPOLOGY": (
            disk.boundary_length == complement.boundary_length
            and disk.J == complement.J == 0.0
            and disk.orientable_region != complement.orientable_region
            and disk.selected_area != complement.selected_area
        ),
        "K6_MOEBIUS_SIDES": (
            side_a.boundary_length == side_b.boundary_length
            and side_a.euler_characteristic == side_b.euler_characteristic == 0
            and side_a.J == side_b.J == 0.0
            and side_a.lifted_boundary_components == 2
        ),
        "K7_REJECT_ONE_SIDED": (
            one_sided.boundary_sidedness == "one-sided"
            and not one_sided.admissible_region
            and one_sided.selected_area is None
        ),
        "K8_GAUSS_BONNET_BY_REGION": all(
            row.gauss_bonnet_residual == 0.0 for row in rows if row.admissible_region
        ),
    }
    return {
        "program": "dido_klein_bottle.py",
        "surface": "rectangular flat Klein bottle",
        "orientation_cover": asdict(surface),
        "base_area": surface.area,
        "cover_area": surface.cover_area,
        "circle_numeric_reference": sample,
        "candidates": [asdict(row) for row in rows],
        "gates": gates,
        "all_gates_pass": all(gates.values()),
        "verdict": (
            "The Klein bottle requires a selected region or orientation-cover "
            "representation. A scalar signed-area loop model is incomplete, and "
            "one-sided geodesics must be rejected as standalone boundaries."
        ),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cover-width", type=float, default=4.0)
    parser.add_argument("--cover-height", type=float, default=6.0)
    parser.add_argument("--disk-length", type=float, default=2.0)
    parser.add_argument("--points", type=int, default=4096)
    parser.add_argument("--json", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(list(argv) if argv is not None else None)
    surface = FlatKleinBottle(args.cover_width, args.cover_height)
    report = run_experiment(surface, args.disk_length, args.points)
    print("=" * 108)
    print("FLAT KLEIN BOTTLE  base area={}  orientation-cover area={}".format(
        report["base_area"], report["cover_area"]))
    print("=" * 108)
    for row in report["candidates"]:
        print("{:<20} region={:<26} sided={:<9} chi={} L={} A={} J={} admitted={}".format(
            row["name"], row["selected_region"], row["boundary_sidedness"],
            row["euler_characteristic"], row["boundary_length"],
            row["selected_area"], row["J"], row["admissible_region"]))
    for name, passed in report["gates"].items():
        print("[{}] {}".format("PASS" if passed else "FAIL", name))
    print("VERDICT: " + report["verdict"])
    if args.json:
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print("Wrote {}".format(args.json))
    return 0 if report["all_gates_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
